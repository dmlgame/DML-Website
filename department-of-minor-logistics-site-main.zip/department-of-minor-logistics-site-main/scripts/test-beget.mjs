import assert from "node:assert/strict";
import { test } from "node:test";
import { mkdtemp, mkdir, writeFile, readFile, symlink } from "node:fs/promises";
import { request as httpRequest } from "node:http";
import { once } from "node:events";
import { gunzipSync } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync, spawn } from "node:child_process";
import { createServer } from "node:net";
import { DatabaseSync } from "node:sqlite";
import { openDatabase, migrate } from "../server/database.mjs";
import { assets } from "../server/assets.mjs";
import { createAppServer, clientAddress } from "../server/http.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const worker = (await import(new URL("../dist/server/index.js", import.meta.url))).default;
const origin = "https://dml.test";
const valid = { firstName: "Ann", lastName: "O'Connor", email: "ann@example.com", consent: true, locale: "en" };
await mkdir(path.join(root, ".sites-runtime/beget-tests"), { recursive: true });
const directory = await mkdtemp(path.join(root, ".sites-runtime/beget-tests/run-"));

function call(server, pathname, { method = "GET", headers = {}, body } = {}) {
  return new Promise((resolve, reject) => {
    const req = httpRequest({ hostname: "127.0.0.1", port: server.address().port, path: pathname, method, headers, agent: false }, res => {
      const chunks = [];
      res.on("data", chunk => chunks.push(chunk));
      res.on("end", () => {
        const bytes = Buffer.concat(chunks);
        resolve({ status: res.statusCode, headers: res.headers, bytes, text: bytes.toString("utf8") });
      });
      res.on("error", reject);
    });
    req.on("error", reject);
    req.setTimeout(10000, () => req.destroy(new Error("HTTP test timed out")));
    req.end(body);
  });
}

async function fixture(t, enabled = false, trustProxy = false) {
  const { sqlite, DB } = openDatabase(":memory:");
  migrate(sqlite, path.join(root, "drizzle"));
  const env = { DB, ASSETS: await assets(path.join(root, "dist/client")), PUBLIC_SITE_ORIGIN: origin,
    EARLY_ACCESS_ENABLED: String(enabled), OTP_SECRET: "test-only-private-secret-at-least-32-characters",
    RESEND_API_KEY: enabled ? "test-only-key" : "", EMAIL_FROM: enabled ? "signup@dml.test" : "" };
  const server = createAppServer(worker, env, { trustProxy });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  t.after(async () => {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    sqlite.close();
  });
  return { sqlite, DB, server };
}

test("migrations are repeatable, registrations persist and edited migrations fail closed", async () => {
  const filename = path.join(directory, "persist.sqlite");
  let db = openDatabase(filename);
  assert.equal(migrate(db.sqlite, path.join(root, "drizzle")), 1);
  assert.equal(migrate(db.sqlite, path.join(root, "drizzle")), 0);
  db.sqlite.prepare(`INSERT INTO early_access_registrations
    (email, id, first_name, last_name, verified_at, consent_at, consent_version) VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run("persist@example.com", "unique-test-id", "Ann", "Test", 1, 1, "test");
  db.sqlite.close();
  db = openDatabase(filename);
  try {
    assert.equal(migrate(db.sqlite, path.join(root, "drizzle")), 0);
    assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS n FROM early_access_registrations").get().n, 1);
    const migrations = path.join(directory, "changed-migrations");
    await mkdir(path.join(migrations, "meta"), { recursive: true });
    await writeFile(path.join(migrations, "meta/_journal.json"), await readFile(path.join(root, "drizzle/meta/_journal.json")));
    await writeFile(path.join(migrations, "0000_far_gravity.sql"), "CREATE TABLE incorrect (id TEXT);");
    assert.throws(() => migrate(db.sqlite, migrations), /changed or removed/);
    assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS n FROM early_access_registrations").get().n, 1);
  } finally { db.sqlite.close(); }
});

test("the production database adapter binds values and rolls back the whole batch", async () => {
  const { sqlite, DB } = openDatabase(":memory:");
  try {
    sqlite.exec("CREATE TABLE test (id TEXT PRIMARY KEY, value TEXT NOT NULL)");
    const payload = "'); DROP TABLE test; --";
    await DB.prepare("INSERT INTO test VALUES (?, ?)").bind("one", payload).run();
    assert.equal((await DB.prepare("SELECT value FROM test WHERE id = ?").bind("one").first()).value, payload);
    assert.throws(() => DB.prepare("SELECT 1; DROP TABLE test"), /one prepared statement/);
    await assert.rejects(DB.batch([
      DB.prepare("INSERT INTO test VALUES (?, ?)").bind("two", "valid"),
      DB.prepare("INSERT INTO test VALUES (?, ?)").bind("one", "duplicate"),
    ]), /UNIQUE/);
    assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM test").get().n, 1);
  } finally { sqlite.close(); }
});

test("database backup includes committed WAL data and can be restored", async () => {
  const filename = path.join(directory, "persist.sqlite");
  const db = openDatabase(filename);
  try {
    db.sqlite.prepare("UPDATE early_access_registrations SET first_name = ?").run("BackedUp");
    const backups = path.join(directory, "backups");
    const result = execFileSync(process.execPath, ["server/backup.mjs"], {
      cwd: root, env: { ...process.env, DATABASE_PATH: filename, BACKUP_DIRECTORY: backups }, encoding: "utf8",
    });
    const restored = new DatabaseSync(result.trim().replace(/^Backup saved: /, ""), { readOnly: true });
    try { assert.equal(restored.prepare("SELECT first_name FROM early_access_registrations").get().first_name, "BackedUp"); }
    finally { restored.close(); }
  } finally { db.sqlite.close(); }
});

test("static files are confined to the public root, including junctions and encoded paths", async () => {
  const publicRoot = path.join(directory, "public");
  const outside = path.join(directory, "outside");
  await mkdir(publicRoot); await mkdir(outside);
  await writeFile(path.join(publicRoot, "index.html"), "<h1>Public</h1>");
  await writeFile(path.join(outside, "private.txt"), "not-public");
  await symlink(outside, path.join(publicRoot, "escape"), process.platform === "win32" ? "junction" : "dir");
  const asset = await assets(publicRoot);
  for (const pathname of ["/.env", "/%2e%2e%5cprivate.txt", "/%00", "/escape/private.txt", "/C:%5cprivate.txt"]) {
    assert.equal((await asset.fetch(new Request(`${origin}${pathname}`))).status, 404, pathname);
  }
  assert.equal((await asset.fetch(new Request(`${origin}/%ZZ`))).status, 400);
  assert.equal(await (await asset.fetch(new Request(origin))).text(), "<h1>Public</h1>");
  assert.equal((await asset.fetch(new Request(origin, { method: "POST", body: "test" }))).status, 405);
});

test("HTTP adapter preserves CSP, Godot gzip, HEAD, health and disabled registration", async t => {
  const { server } = await fixture(t);
  const page = await call(server, "/", { headers: { Host: "evil.test" } });
  assert.equal(page.status, 200);
  assert.match(page.headers["content-security-policy"], /wasm-unsafe-eval/);
  assert.match(page.headers["content-security-policy"], /sha256-/);
  assert.doesNotMatch(page.headers["content-security-policy"], /script-src[^;]*'unsafe-inline'/);
  assert.equal(page.headers["x-content-type-options"], "nosniff");
  const engine = await call(server, "/demo/index.wasm");
  assert.equal(engine.status, 200);
  assert.equal(engine.headers["content-encoding"], "gzip");
  assert.equal(engine.headers["content-type"], "application/wasm");
  assert.equal(engine.bytes.length, Number(engine.headers["content-length"]));
  assert.deepEqual(gunzipSync(engine.bytes).subarray(0, 4), Buffer.from([0, 97, 115, 109]));
  const head = await call(server, "/demo/index.wasm", { method: "HEAD" });
  assert.equal(head.bytes.length, 0);
  assert.equal(head.headers["content-length"], engine.headers["content-length"]);
  assert.equal((await call(server, "/healthz")).text, "ok");
  assert.deepEqual(JSON.parse((await call(server, "/api/early-access/status")).text), { available: false });
  const disabled = await call(server, "/api/early-access/request", { method: "POST", headers: { Origin: origin, "Content-Type": "application/json" }, body: JSON.stringify(valid) });
  assert.equal(disabled.status, 503);
});

test("HTTP registration uses the production database, secure cookies and atomic confirmation", async t => {
  const { server, sqlite } = await fixture(t, true);
  const realFetch = globalThis.fetch;
  const messages = [];
  globalThis.fetch = async (url, options) => {
    assert.equal(url, "https://api.resend.com/emails");
    messages.push(JSON.parse(options.body));
    return Response.json({ id: "test-mail" });
  };
  t.after(() => { globalThis.fetch = realFetch; });
  const headers = { Origin: origin, "Content-Type": "application/json" };
  const sent = await call(server, "/api/early-access/request", { method: "POST", headers, body: JSON.stringify(valid) });
  assert.equal(sent.status, 200);
  const cookie = sent.headers["set-cookie"][0];
  assert.match(cookie, /Secure; HttpOnly; SameSite=Strict/);
  const code = messages.at(-1).text.match(/\b\d{6}\b/)[0];
  const body = JSON.stringify({ challengeId: JSON.parse(sent.text).challengeId, code });
  const replies = await Promise.all(Array.from({ length: 5 }, () => call(server, "/api/early-access/verify", {
    method: "POST", headers: { ...headers, Cookie: cookie.split(";")[0] }, body,
  })));
  assert.equal(replies.filter(reply => reply.status === 200).length, 1);
  assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM early_access_registrations").get().n, 1);
  assert.equal(sqlite.prepare("SELECT bonus_status FROM early_access_registrations").get().bonus_status, "reserved");
});

test("fake edge headers cannot bypass HTTP rate limits; Caddy identity is opt-in", async t => {
  assert.equal(clientAddress({ headers: { "x-dml-client-ip": "192.0.2.1" }, socket: { remoteAddress: "::ffff:127.0.0.1" } }, false), "127.0.0.1");
  assert.equal(clientAddress({ headers: { "x-dml-client-ip": "192.0.2.1" }, socket: {} }, true), "192.0.2.1");
  assert.equal(clientAddress({ headers: { "x-dml-client-ip": "fake, 192.0.2.1" }, socket: {} }, true), "unknown");
  const { server } = await fixture(t, true);
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => Response.json({ id: "test-mail" });
  t.after(() => { globalThis.fetch = realFetch; });
  for (let index = 0; index < 6; index++) {
    const response = await call(server, "/api/early-access/request", {
      method: "POST", headers: { Origin: origin, "Content-Type": "application/json",
        "CF-Connecting-IP": `192.0.2.${index}`, "X-Forwarded-For": `192.0.2.${index}`,
        "X-DML-Client-IP": `192.0.2.${index}`, "OAI-Authenticated-User-ID": `fake-${index}` },
      body: JSON.stringify({ ...valid, email: `user${index}@example.com` }),
    });
    assert.equal(response.status, index < 5 ? 200 : 429);
  }
});

test("HTTP rejects cross-site writes, oversized and malformed streamed bodies", async t => {
  const { server } = await fixture(t);
  const headers = { Origin: origin, "Content-Type": "application/json" };
  const send = (body, overrides = {}) => call(server, "/api/early-access/request", { method: "POST", headers: { ...headers, ...overrides }, body });
  assert.equal((await send(JSON.stringify(valid), { Origin: "https://evil.test" })).status, 403);
  assert.equal((await send("{" )).status, 400);
  assert.equal((await send("x".repeat(4097))).status, 413);
  assert.equal((await send("x".repeat(4097), { "Transfer-Encoding": "chunked" })).status, 413);
  assert.equal((await send("x".repeat(256000), { "Transfer-Encoding": "chunked" })).status, 413);
  assert.equal((await send("x".repeat(4097), { "Content-Length": "4097" })).status, 413);
  assert.equal((await call(server, "/api/early-access/request")).status, 405);
  assert.equal((await call(server, "//evil.test/")).status, 400);
});

test("a stalled streamed body gets a bounded timeout response", async t => {
  const { server } = await fixture(t);
  const response = await new Promise((resolve, reject) => {
    const req = httpRequest({ hostname: "127.0.0.1", port: server.address().port, method: "POST",
      path: "/api/early-access/request", headers: { Origin: origin, "Content-Type": "application/json", "Transfer-Encoding": "chunked" },
    }, res => { res.resume(); res.on("end", () => { req.destroy(); resolve(res.statusCode); }); });
    req.on("error", reject);
    req.setTimeout(8000, () => req.destroy(new Error("Timeout response was not sent")));
    req.write("{");
  });
  assert.equal(response, 408);
});

test("the production start command validates configuration and starts with registration disabled", async t => {
  const secret = "test-only-private-startup-secret-of-32-characters";
  const baseEnv = { ...process.env, PUBLIC_SITE_ORIGIN: origin, OTP_SECRET: secret, EARLY_ACCESS_ENABLED: "false",
    DATABASE_PATH: path.join(directory, "startup.sqlite"), HOST: "127.0.0.1", TRUST_CADDY: "false", RESEND_API_KEY: "", EMAIL_FROM: "" };
  for (const override of [{ PUBLIC_SITE_ORIGIN: "http://dml.test" }, { OTP_SECRET: "short" }, { EARLY_ACCESS_ENABLED: "true" }]) {
    const child = spawn(process.execPath, ["server/start.mjs"], { cwd: root, env: { ...baseEnv, ...override }, windowsHide: true });
    const exited = once(child, "exit");
    const output = [];
    child.stderr.on("data", data => output.push(data.toString()));
    child.stdout.resume();
    assert.equal((await exited)[0], 1);
    assert.equal(output.join("").includes(secret), false);
  }
  const socket = createServer();
  socket.listen(0, "127.0.0.1");
  await once(socket, "listening");
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  const child = spawn(process.execPath, ["server/start.mjs"], { cwd: root, env: { ...baseEnv, PORT: String(port) }, windowsHide: true });
  const exited = once(child, "exit");
  t.after(async () => { if (child.exitCode === null) child.kill(); await exited; });
  child.stderr.resume();
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Production server did not start")), 10000);
    child.once("exit", () => { clearTimeout(timer); reject(new Error("Production server exited early")); });
    child.stdout.on("data", data => {
      if (data.toString().includes("DML started")) { clearTimeout(timer); resolve(); }
    });
  });
  const server = { address: () => ({ port }) };
  assert.equal((await call(server, "/healthz")).status, 200);
  assert.deepEqual(JSON.parse((await call(server, "/api/early-access/status")).text), { available: false });
});
