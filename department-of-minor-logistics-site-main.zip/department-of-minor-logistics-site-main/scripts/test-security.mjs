import { build } from "esbuild";
import { mkdir, readFile, readdir } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { DatabaseSync } from "node:sqlite";
import assert from "node:assert/strict";
import { test, after } from "node:test";

await mkdir(".sites-runtime", { recursive: true });
await build({ entryPoints: ["worker/index.ts"], outfile: ".sites-runtime/security-worker.mjs", bundle: true,
  format: "esm", platform: "browser", define: { __INLINE_SCRIPT_HASHES__: "[]" } });
const worker = (await import(pathToFileURL(`${process.cwd()}/.sites-runtime/security-worker.mjs`))).default;
const migrations = await Promise.all((await readdir("drizzle")).filter(file => file.endsWith(".sql")).sort()
  .map(file => readFile(`drizzle/${file}`, "utf8")));
const origin = "https://dml.test";
const valid = { firstName: "Анна", lastName: "O'Connor", email: "anna@example.com", consent: true, locale: "ru" };
const realFetch = globalThis.fetch;
const realNow = Date.now;
let now = 1800000000000;
Date.now = () => now;
after(() => { globalThis.fetch = realFetch; Date.now = realNow; });

function fixture() {
  const sqlite = new DatabaseSync(":memory:");
  for (const migration of migrations) sqlite.exec(migration);
  class Statement {
    constructor(sql, values = []) { this.sql = sql; this.values = values; }
    bind(...values) { return new Statement(this.sql, values); }
    execute() {
      const query = sqlite.prepare(this.sql);
      const results = /\bRETURNING\b|^SELECT\b/i.test(this.sql.trim()) ? query.all(...this.values) : [];
      if (!/\bRETURNING\b|^SELECT\b/i.test(this.sql.trim())) query.run(...this.values);
      return { results, meta: { changes: sqlite.prepare("SELECT changes() AS changes").get().changes } };
    }
    async first() { return this.execute().results[0] ?? null; }
    async all() { return this.execute(); }
    async run() { return this.execute(); }
  }
  const DB = {
    prepare(sql) { assert.equal(sql.trim().replace(/;$/, "").includes(";"), false, "One SQL statement per prepare"); return new Statement(sql); },
    async batch(statements) {
      sqlite.exec("BEGIN");
      try { const result = statements.map(statement => statement.execute()); sqlite.exec("COMMIT"); return result; }
      catch (error) { sqlite.exec("ROLLBACK"); throw error; }
    },
  };
  const env = { DB, PUBLIC_SITE_ORIGIN: origin, EARLY_ACCESS_ENABLED: "true", OTP_SECRET: "test-only-private-key-with-at-least-32-characters",
    RESEND_API_KEY: "test-only-mail-key", EMAIL_FROM: "signup@dml.test" };
  const messages = [];
  let delivery = "success";
  globalThis.fetch = async (url, options) => {
    assert.equal(url, "https://api.resend.com/emails");
    if (delivery === "throw") throw new Error("Private provider details");
    if (delivery === "fail") return new Response("Private provider details", { status: 503 });
    const message = JSON.parse(options.body);
    assert.equal("html" in message, false);
    messages.push(message);
    return Response.json({ id: "test-mail" });
  };
  async function call(path, input, options = {}) {
    const headers = { Origin: origin, "Content-Type": "application/json", "CF-Connecting-IP": "192.0.2.1", ...options.headers };
    const request = new Request(`${origin}/api/early-access/${path}`, { method: options.method ?? "POST", headers,
      ...((options.method ?? "POST") === "POST" ? { body: options.body ?? JSON.stringify(input) } : {}) });
    const response = await worker.fetch(request, options.env ?? env);
    return { response, data: await response.json() };
  }
  async function send(input = valid, options) {
    const result = await call("request", input, options);
    const cookie = result.response.headers.get("set-cookie")?.split(";")[0];
    const code = messages.at(-1)?.text.match(/\b\d{6}\b/)?.[0];
    return { ...result, cookie, code };
  }
  const verify = (challenge, code = challenge.code, options = {}) => call("verify", { challengeId: challenge.data.challengeId, code },
    { ...options, headers: { Cookie: challenge.cookie, ...options.headers } });
  const rows = (table) => sqlite.prepare(`SELECT * FROM ${table}`).all();
  return { call, send, verify, rows, env, sqlite, messages, delivery(value) { delivery = value; } };
}

test("confirmation is server-owned, canonicalized and reserves a future bonus exactly once", async () => {
  const f = fixture();
  const challenge = await f.send({ ...valid, email: "  ANNA@Example.COM  " });
  assert.equal(challenge.response.status, 200);
  assert.match(challenge.response.headers.get("set-cookie"), /Secure; HttpOnly; SameSite=Strict/);
  assert.equal(f.rows("early_access_registrations").length, 0);
  const pending = f.rows("early_access_challenges")[0];
  assert.equal(pending.email, valid.email);
  assert.notEqual(pending.code_hash, challenge.code);
  assert.match(pending.code_hash, /^[a-f0-9]{64}$/);
  assert.match(pending.session_hash, /^[a-f0-9]{64}$/);
  assert.equal(JSON.stringify(challenge.data).includes(challenge.code), false);
  const result = await f.verify(challenge);
  assert.equal(result.data.status, "confirmed");
  assert.match(result.response.headers.get("set-cookie"), /Max-Age=0/);
  const registration = f.rows("early_access_registrations")[0];
  assert.equal(registration.email, valid.email);
  assert.equal(registration.last_name, "O'Connor");
  assert.equal(registration.bonus_status, "reserved");
  assert.equal(registration.bonus_claimed_at, null);
  assert.equal((await f.verify(challenge)).response.status, 400);
  now += 61000;
  const duplicate = await f.send({ ...valid, firstName: "Другое", email: "Anna@example.com" });
  assert.equal((await f.verify(duplicate)).data.status, "already_confirmed");
  assert.equal(f.rows("early_access_registrations").length, 1);
  assert.equal(f.rows("early_access_registrations")[0].first_name, valid.firstName);
  assert.throws(() => f.sqlite.prepare("INSERT INTO early_access_registrations SELECT * FROM early_access_registrations").run(), /UNIQUE/);
});

test("server rejects malformed emails, HTML, SQL payloads, controls, oversized names and unknown fields", async () => {
  const f = fixture();
  const invalid = [
    ...["no-at", "a@b", "a@@example.com", "a@example..com", "<a@example.com>", "a@example.com\r\nBcc:x@example.com", "\" OR 1=1--@example.com"].map(email => ({ ...valid, email })),
    ...["<script>alert(1)</script>", "'); DROP TABLE users;--", "A\u0000B", "A\nB", "a".repeat(81)].map(firstName => ({ ...valid, firstName })),
    { ...valid, consent: false }, { ...valid, locale: "unknown" }, { ...valid, bonusStatus: "claimed" }, { ...valid, code: "000000" },
    { ...valid, firstName: [] }, { ...valid, email: null },
  ];
  for (const input of invalid) assert.equal((await f.call("request", input)).response.status, 400);
  assert.equal((await f.call("request", null, { body: '{"__proto__":{},"firstName":"Ann"}' })).response.status, 400);
  assert.equal(f.messages.length, 0);
  assert.equal(f.rows("early_access_registrations").length, 0);
});

test("origin, content type, request size and invalid JSON are enforced independently of the browser", async () => {
  const f = fixture();
  for (const headers of [{ Origin: "https://evil.test" }, { Origin: "" }, { "Sec-Fetch-Site": "cross-site" }]) {
    assert.equal((await f.call("request", valid, { headers })).response.status, 403);
  }
  assert.equal((await f.call("request", valid, { headers: { "Content-Type": "text/plain" } })).response.status, 415);
  assert.equal((await f.call("request", valid, { body: "x".repeat(4097) })).response.status, 413);
  assert.equal((await f.call("request", valid, { headers: { "Content-Length": "5000" } })).response.status, 413);
  assert.equal((await f.call("request", valid, { body: "{" })).response.status, 400);
  assert.equal((await f.call("request", valid, { body: new Uint8Array([0xff, 0xfe]) })).response.status, 400);
  assert.equal((await f.call("request", null, { method: "GET" })).response.status, 405);
  assert.equal((await f.call("missing", valid)).response.status, 404);
  assert.equal(f.messages.length, 0);
});

test("verification is browser-bound; five wrong attempts lock the challenge", async () => {
  const f = fixture();
  const challenge = await f.send();
  for (const Cookie of ["", "__Host-dml-early-access=bad", "__Host-dml-early-access=" + "a".repeat(32), `${challenge.cookie}; ${challenge.cookie}`]) {
    assert.equal((await f.verify(challenge, challenge.code, { headers: { Cookie } })).response.status, 400);
  }
  assert.equal(f.rows("early_access_challenges")[0].attempts, 5);
  const wrong = challenge.code === "000000" ? "111111" : "000000";
  const attempts = await Promise.all(Array.from({ length: 12 }, () => f.verify(challenge, wrong)));
  assert.ok(attempts.every(result => result.response.status === 400));
  assert.equal(f.rows("early_access_challenges")[0].attempts, 0);
  assert.equal((await f.verify(challenge)).response.status, 400);
  assert.equal(f.rows("early_access_registrations").length, 0);
});

test("codes expire and resends invalidate previous codes and browser sessions", async () => {
  const f = fixture();
  const old = await f.send();
  assert.equal((await f.send()).response.status, 429);
  now += 61000;
  const replacement = await f.send();
  assert.equal((await f.verify(old)).response.status, 400);
  assert.equal((await f.verify(replacement, replacement.code, { headers: { Cookie: old.cookie } })).response.status, 400);
  now += 600000;
  assert.equal((await f.verify(replacement)).response.status, 400);
  assert.equal(f.rows("early_access_registrations").length, 0);
});

test("simultaneous confirmations produce only one registration and one successful response", async () => {
  const f = fixture();
  const challenge = await f.send();
  const results = await Promise.all(Array.from({ length: 5 }, () => f.verify(challenge)));
  assert.equal(results.filter(result => result.response.status === 200).length, 1);
  assert.equal(f.rows("early_access_registrations").length, 1);
});

test("send limits are atomic per IP, per email, and globally; rate keys contain no raw identifiers", async () => {
  const f = fixture();
  const results = await Promise.all(Array.from({ length: 10 }, (_, index) => f.send({ ...valid, email: `user${index}@example.com` })));
  assert.equal(results.filter(result => result.response.status === 200).length, 5);
  assert.ok(results.some(result => result.response.headers.has("retry-after")));
  assert.ok(f.rows("early_access_rate_limits").every(row => /^[a-f0-9]{64}$/.test(row.key)));
  const g = fixture();
  for (let index = 0; index < 3; index++) {
    assert.equal((await g.send(valid, { headers: { "CF-Connecting-IP": `192.0.2.${index}` } })).response.status, 200);
    now += 61000;
  }
  assert.equal((await g.send(valid, { headers: { "CF-Connecting-IP": "192.0.2.100" } })).response.status, 429);
  const h = fixture();
  for (let index = 0; index < 121; index++) {
    const result = await h.send({ ...valid, email: `global${index}@example.com` }, { headers: { "CF-Connecting-IP": `ip-${index}` } });
    assert.equal(result.response.status, index < 120 ? 200 : 429);
  }
});

test("verify rate limit is independent of individual challenge ids", async () => {
  const f = fixture();
  for (let index = 0; index < 31; index++) {
    const result = await f.call("verify", { challengeId: "a".repeat(32), code: "123456" });
    assert.equal(result.response.status, index < 30 ? 400 : 429);
  }
});

test("mail/config/database failures fail closed and reveal no provider details or secrets", async () => {
  const f = fixture();
  for (const partial of [{ EARLY_ACCESS_ENABLED: "false" }, { OTP_SECRET: "short" }, { RESEND_API_KEY: undefined }, { DB: undefined }, { EMAIL_FROM: "bad" }]) {
    const env = { ...f.env, ...partial };
    assert.equal((await f.call("status", null, { method: "GET", env })).data.available, false);
    assert.equal((await f.call("request", valid, { env })).response.status, 503);
  }
  for (const delivery of ["fail", "throw"]) {
    f.delivery(delivery);
    const result = await f.send();
    assert.equal(result.response.status, 503);
    assert.deepEqual(result.data, { error: "unavailable" });
    assert.equal(result.response.headers.has("set-cookie"), false);
    assert.equal(f.rows("early_access_challenges").length, 0);
  }
  const env = { ...f.env, DB: { batch() { throw new Error("Private SQL details"); } } };
  assert.deepEqual((await f.call("request", valid, { env })).data, { error: "unavailable" });
  assert.equal(f.rows("early_access_registrations").length, 0);
});

test("API caching, static CSP and compressed Godot asset headers are preserved", async () => {
  const f = fixture();
  const status = await f.call("status", null, { method: "GET" });
  assert.equal(status.response.headers.get("cache-control"), "private, no-store");
  assert.equal(status.response.headers.get("access-control-allow-origin"), null);
  const html = await worker.fetch(new Request(origin), { ASSETS: { async fetch() { return new Response("<html></html>", { headers: { "Content-Type": "text/html" } }); } } });
  assert.match(html.headers.get("content-security-policy"), /object-src 'none'/);
  assert.doesNotMatch(html.headers.get("content-security-policy"), /script-src[^;]*'unsafe-inline'/);
  const wasm = await worker.fetch(new Request(`${origin}/demo/index.wasm`), { ASSETS: { async fetch() {
    return new Response("compressed", { headers: { "Content-Type": "application/wasm", "Content-Encoding": "gzip" } });
  } } });
  assert.equal(wasm.headers.get("content-encoding"), "gzip");
  assert.equal(wasm.headers.get("content-type"), "application/wasm");
});
