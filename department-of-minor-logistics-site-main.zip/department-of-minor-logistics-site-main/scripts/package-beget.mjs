import { cp, mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";

const root = fileURLToPath(new URL("../", import.meta.url));
const output = path.join(root, ".sites-runtime/beget");
await mkdir(output, { recursive: true });
const staging = await mkdtemp(path.join(output, "release-"));
const archive = path.join(output, "dmlgame-beget.tar.gz");
const included = ["Dockerfile", ".dockerignore", "compose.yaml", "Caddyfile", ".env.beget.example", "BEGET.md", "SECURITY.md",
  "server", "deploy", "dist/client", "dist/server/index.js", "drizzle/meta/_journal.json"];
const journal = JSON.parse(await readFile(path.join(root, "drizzle/meta/_journal.json"), "utf8"));
for (const entry of journal.entries) {
  if (!/^[a-zA-Z0-9_]+$/.test(entry.tag)) throw new Error("Invalid migration name");
  included.push(`drizzle/${entry.tag}.sql`);
}
try {
  for (const filename of included) {
    const target = path.join(staging, filename);
    await mkdir(path.dirname(target), { recursive: true });
    await cp(path.join(root, filename), target, { recursive: true, verbatimSymlinks: true });
  }
  const files = [];
  async function inventory(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const filename = path.join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error("Release must not contain symbolic links");
      if (entry.isDirectory()) await inventory(filename);
      else {
        const name = path.relative(staging, filename).split(path.sep).join("/");
        if (/\.sqlite(?:-|$)|(?:^|\/)\.env(?!\.beget\.example$)|(?:^|\/)\.git(?:\/|$)/.test(name)) {
          throw new Error("Release must not contain runtime data or secrets");
        }
        files.push({ name, sha256: createHash("sha256").update(await readFile(filename)).digest("hex") });
      }
    }
  }
  await inventory(staging);
  await writeFile(path.join(staging, "release.json"), JSON.stringify({ builtAt: new Date().toISOString(), files: files.sort((a, b) => a.name.localeCompare(b.name)) }, null, 2));
  execFileSync("tar", ["-czf", archive, "-C", staging, "."], { stdio: "inherit" });
  const checksum = createHash("sha256").update(await readFile(archive)).digest("hex");
  await writeFile(`${archive}.sha256`, `${checksum}  dmlgame-beget.tar.gz\n`);
  console.log(`Beget release: ${archive}\nSHA256: ${checksum}\nNo runtime secrets or registration database included.`);
} finally {
  const relative = path.relative(await realpath(output), await realpath(staging));
  if (!relative.startsWith("release-") || relative.includes(path.sep) || path.isAbsolute(relative)) {
    throw new Error("Refusing to remove an unexpected staging directory");
  }
  await rm(staging, { recursive: true });
}
