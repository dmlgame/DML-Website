import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { build } from "esbuild";
import { parse } from "parse5";

const root = process.cwd();
const hashes = new Set();
async function scan(directory) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isDirectory()) await scan(filename);
    else if (entry.name.endsWith(".html")) {
      const document = parse(await fs.readFile(filename, "utf8"));
      function visit(node) {
        if (node.tagName === "script" && !node.attrs.some(attr => attr.name === "src")) {
          const source = node.childNodes.map(child => child.value ?? "").join("");
          if (source) hashes.add(`'sha256-${crypto.createHash("sha256").update(source).digest("base64")}'`);
        }
        for (const child of node.childNodes ?? []) visit(child);
      }
      visit(document);
    }
  }
}
await scan(path.join(root, "out"));
await fs.mkdir("dist/server", { recursive: true });
const clientDirectory = path.resolve(root, "dist/client");
const existingClient = await fs.realpath(clientDirectory).catch(error => {
  if (error.code === "ENOENT") return null;
  throw error;
});
if (existingClient && existingClient !== path.join(await fs.realpath(root), "dist/client")) {
  throw new Error("Refusing to replace assets outside the build directory");
}
await fs.rm(clientDirectory, { recursive: true, force: true });
await fs.cp("out", "dist/client", { recursive: true });
await build({
  entryPoints: ["worker/index.ts"], outfile: "dist/server/index.js", bundle: true,
  format: "esm", platform: "browser", target: "es2022", minify: true,
  define: { __INLINE_SCRIPT_HASHES__: JSON.stringify([...hashes]) },
});
await fs.writeFile("dist/server/wrangler.json", JSON.stringify({
  name: "dml-early-access", main: "index.js", compatibility_date: "2026-10-07",
  assets: { directory: "../client", binding: "ASSETS", run_worker_first: true },
}, null, 2));
console.log(`Worker built with ${hashes.size} inline script hashes. Secrets are runtime-only.`);
