extends SceneTree

const SHOTS := [
	{"name": "gallery-stockroom", "position": Vector2(-540, -860), "center": Vector2(-515, -880), "zoom": 2.0},
	{"name": "gallery-facilities", "position": Vector2(-3520, -3280), "center": Vector2(-3600, -3280), "zoom": 2.0},
	{"name": "gallery-charging", "position": Vector2(590, -1590), "center": Vector2(565, -1545), "zoom": 2.0},
	{"name": "gallery-coworkers", "position": Vector2(2665, -2415), "center": Vector2(2690, -2470), "zoom": 2.0},
	{"name": "animation-floor", "position": Vector2(1200, -1750), "center": Vector2(1200, -1750), "zoom": 1.5, "floor_only": true},
]


func _initialize() -> void:
	call_deferred("_capture")


func _capture() -> void:
	var output_dir: String = get_script().resource_path.get_base_dir().get_base_dir().path_join("public/media")
	DirAccess.make_dir_recursive_absolute(output_dir)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1440, 810)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.disable_3d = true
	viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	root.add_child(viewport)

	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(world)
	var player: CharacterBody2D = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	player.get_node("Camera2D").enabled = false
	var sprite: AnimatedSprite2D = player.get_node("Visuals/OnFoot")
	sprite.stop()
	sprite.animation = "idle_down"
	var camera := Camera2D.new()
	world.add_child(camera)
	camera.make_current()

	for shot in SHOTS:
		player.global_position = shot.position
		world.get_node("YSortActors").visible = not shot.get("floor_only", false)
		world.get_node("WallLayer").visible = not shot.get("floor_only", false)
		world.get_node("FloorLayer2/NumbersLayer").visible = not shot.get("floor_only", false)
		camera.global_position = shot.center
		camera.zoom = Vector2.ONE * shot.zoom
		camera.reset_smoothing()
		for i in range(5):
			await process_frame
		await RenderingServer.frame_post_draw
		var path: String = "%s/%s.png" % [output_dir, shot.name]
		var error := viewport.get_texture().get_image().save_png(path)
		print("Captured %s (%s)" % [path, error])

	viewport.queue_free()
	await process_frame
	quit()
