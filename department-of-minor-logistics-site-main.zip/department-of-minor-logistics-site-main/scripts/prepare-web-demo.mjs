import { readFileSync, writeFileSync, statSync } from "node:fs";
import { gzipSync, gunzipSync } from "node:zlib";
import { fileURLToPath } from "node:url";

const wasm = fileURLToPath(new URL("../public/demo/index.wasm", import.meta.url));
const data = readFileSync(wasm);
const compressed = data[0] === 0x1f && data[1] === 0x8b;
const original = compressed ? gunzipSync(data) : data;
if (!original.subarray(0, 4).equals(Buffer.from([0, 97, 115, 109]))) {
  throw new Error("The demo does not contain a valid WebAssembly export.");
}
if (!compressed) writeFileSync(wasm, gzipSync(data, { level: 9 }));
if (statSync(wasm).size >= 25 * 1024 * 1024) {
  throw new Error("The compressed WebAssembly export exceeds the static asset limit.");
}
console.log(`Web demo engine: ${original.length} bytes, ${statSync(wasm).size} bytes transferred.`);
