import http from "node:http";
import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import worker from "../dist/server/index.js";

// Local production-output preview only. Mail delivery is intentionally disabled.
const port = Number(process.argv[2] ?? 3005);
const root = path.resolve("dist/client");
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json",
  ".wasm": "application/wasm", ".png": "image/png", ".jpeg": "image/jpeg", ".jpg": "image/jpeg", ".svg": "image/svg+xml",
  ".woff2": "font/woff2", ".ico": "image/x-icon", ".webp": "image/webp" };
const ASSETS = { async fetch(request) {
  let relative;
  try { relative = decodeURIComponent(new URL(request.url).pathname); } catch { return new Response("Bad path", { status: 400 }); }
  let filename = path.resolve(root, `.${relative}`);
  if (!filename.startsWith(root + path.sep) && filename !== root) return new Response("Forbidden", { status: 403 });
  try {
    if ((await fs.stat(filename)).isDirectory()) filename = path.join(filename, "index.html");
    const headers = { "Content-Type": types[path.extname(filename)] ?? "application/octet-stream" };
    if (relative === "/demo/index.wasm") headers["Content-Encoding"] = "gzip";
    return new Response(request.method === "HEAD" ? null : Readable.toWeb(createReadStream(filename)), { headers });
  } catch { return new Response("Not found", { status: 404 }); }
} };
http.createServer(async (incoming, outgoing) => {
  try {
    const origin = `http://127.0.0.1:${port}`;
    const request = new Request(new URL(incoming.url, origin), { method: incoming.method, headers: incoming.headers,
      ...(!["GET", "HEAD"].includes(incoming.method) ? { body: Readable.toWeb(incoming), duplex: "half" } : {}) });
    const response = await worker.fetch(request, { ASSETS, PUBLIC_SITE_ORIGIN: origin, EARLY_ACCESS_ENABLED: "false" });
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    if (response.body) Readable.fromWeb(response.body).pipe(outgoing); else outgoing.end();
  } catch { outgoing.writeHead(500); outgoing.end("Preview unavailable"); }
}).listen(port, "127.0.0.1", () => console.log(`Worker preview: http://127.0.0.1:${port}`));
