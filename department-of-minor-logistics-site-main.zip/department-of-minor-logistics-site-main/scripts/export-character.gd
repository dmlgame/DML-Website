extends SceneTree

const DIRECTIONS := {"down": Vector2.DOWN, "up": Vector2.UP, "left": Vector2.LEFT, "right": Vector2.RIGHT}
const MODES := {"foot": 0, "pallet-jack": 1, "transporter": 2}
const FRAME_SIZE := 256
const VEHICLE_SHEETS := {
	"Visuals/PalletJack/Horizontal": 2,
	"Visuals/PalletJack/Vertical": 2,
	"Visuals/Transporter/Sprite": 4,
}


func _initialize() -> void:
	call_deferred("_export")


func _export() -> void:
	var output_dir: String = get_script().resource_path.get_base_dir().get_base_dir().path_join("public/media")
	DirAccess.make_dir_recursive_absolute(output_dir)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(FRAME_SIZE, FRAME_SIZE)
	viewport.transparent_bg = true
	viewport.disable_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	root.add_child(viewport)
	var player: CharacterBody2D = load("res://character_body_2d.tscn").instantiate()
	viewport.add_child(player)
	player.position = Vector2.ONE * FRAME_SIZE / 2.0
	player.set_physics_process(false)
	player.get_node("Camera2D").enabled = false
	var sprite: AnimatedSprite2D = player.get_node("Visuals/OnFoot")
	sprite.stop()
	for mode in MODES:
		_restore_vehicle_sheets(player)
		player.set_move_mode(MODES[mode])
		for direction in DIRECTIONS:
			var animation_direction: String = "top" if direction == "up" else direction
			var strip := Image.create(FRAME_SIZE * 8, FRAME_SIZE, false, Image.FORMAT_RGBA8)
			strip.fill(Color.TRANSPARENT)
			for index in 8:
				if mode == "foot":
					player._set_on_foot_preview(DIRECTIONS[direction], index)
				else:
					_restore_vehicle_sheets(player)
					player._update_vehicle_frame(DIRECTIONS[direction], index)
					_clip_vehicle_frames(player)
				await process_frame
				await RenderingServer.frame_post_draw
				strip.blit_rect(viewport.get_texture().get_image(), Rect2i(0, 0, FRAME_SIZE, FRAME_SIZE), Vector2i(index * FRAME_SIZE, 0))
			var path: String = "%s/%s-move-%s.png" % [output_dir, mode, direction]
			print("Exported ", path, " (", strip.save_png(path), ")")
			if mode == "foot":
				var idle := Image.create(FRAME_SIZE * 2, FRAME_SIZE, false, Image.FORMAT_RGBA8)
				idle.fill(Color.TRANSPARENT)
				for index in 2:
					sprite.animation = "idle_%s" % animation_direction
					sprite.frame = index
					await process_frame
					await RenderingServer.frame_post_draw
					idle.blit_rect(viewport.get_texture().get_image(), Rect2i(0, 0, FRAME_SIZE, FRAME_SIZE), Vector2i(index * FRAME_SIZE, 0))
				var idle_path: String = "%s/foot-idle-%s.png" % [output_dir, direction]
				print("Exported ", idle_path, " (", idle.save_png(idle_path), ")")
	viewport.queue_free()
	await process_frame
	quit()


func _restore_vehicle_sheets(player: Node) -> void:
	for path in VEHICLE_SHEETS:
		var sprite: Sprite2D = player.get_node(path)
		sprite.region_enabled = false
		sprite.hframes = 8
		sprite.vframes = VEHICLE_SHEETS[path]


func _clip_vehicle_frames(player: Node) -> void:
	for path in VEHICLE_SHEETS:
		var sprite: Sprite2D = player.get_node(path)
		var frame_size := sprite.texture.get_size() / Vector2(sprite.hframes, sprite.vframes)
		var frame_origin := Vector2(sprite.frame_coords) * frame_size
		# Clip the selected atlas cell so half-scale rendering cannot sample its neighbor.
		sprite.hframes = 1
		sprite.vframes = 1
		sprite.region_enabled = true
		sprite.region_rect = Rect2(frame_origin, frame_size)
		sprite.region_filter_clip_enabled = true
