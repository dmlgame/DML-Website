import { once } from "node:events";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { openDatabase, migrate } from "../server/database.mjs";
import { assets } from "../server/assets.mjs";
import { createAppServer } from "../server/http.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const worker = (await import(new URL("../dist/server/index.js", import.meta.url))).default;
const { sqlite, DB } = openDatabase(":memory:");
migrate(sqlite, path.join(root, "drizzle"));
const env = { DB, ASSETS: await assets(path.join(root, "dist/client")), EARLY_ACCESS_ENABLED: "false", PUBLIC_SITE_ORIGIN: "http://127.0.0.1" };
const server = createAppServer(worker, env);
server.listen(0, "127.0.0.1");
await once(server, "listening");
env.PUBLIC_SITE_ORIGIN = `http://127.0.0.1:${server.address().port}`;
try {
  const args = process.argv.slice(2);
  const child = spawn(process.execPath, ["node_modules/@playwright/test/cli.js", "test",
    ...(args.length ? args : ["tests/online-demo.spec.ts", "tests/mobile-demo.spec.ts", "tests/locale.spec.ts", "tests/early-access.spec.ts"]), "--workers=1"], {
    cwd: root, env: { ...process.env, SITE_TEST_URL: env.PUBLIC_SITE_ORIGIN }, stdio: "inherit", windowsHide: true,
  });
  process.exitCode = (await once(child, "exit"))[0] ?? 1;
} finally {
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  sqlite.close();
}
