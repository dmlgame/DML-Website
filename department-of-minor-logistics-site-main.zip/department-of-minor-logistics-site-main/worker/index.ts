import { earlyAccess, type Env } from "./early-access";

declare const __INLINE_SCRIPT_HASHES__: string[];

const worker = {
  async fetch(request: Request, env: Env) {
    const pathname = new URL(request.url).pathname;
    if (pathname.startsWith("/api/")) return earlyAccess(request, env);
    const response = env.ASSETS ? await env.ASSETS.fetch(request) : new Response("Not found", { status: 404 });
    const result = new Response(response.body, response);
    result.headers.set("X-Content-Type-Options", "nosniff");
    result.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    result.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    if (response.headers.get("Content-Type")?.includes("text/html")) {
      result.headers.set("Content-Security-Policy", [
        "default-src 'self'", `script-src 'self' 'wasm-unsafe-eval' ${__INLINE_SCRIPT_HASHES__.join(" ")}`,
        "style-src 'self' 'unsafe-inline'", "img-src 'self' data: blob:", "worker-src 'self' blob:",
        "connect-src 'self'", "font-src 'self'", "object-src 'none'", "base-uri 'none'", "form-action 'self'",
        "frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com",
      ].join("; "));
    }
    return result;
  },
};

export default worker;
