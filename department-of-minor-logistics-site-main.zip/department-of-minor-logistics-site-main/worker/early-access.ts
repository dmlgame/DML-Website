import { emailAddress, registrationInput, verificationInput } from "../src/features/EarlyAccess/validation";
import { statement, type Database } from "./database";

export type Env = {
  DB?: Database;
  ASSETS?: { fetch(request: Request): Promise<Response> };
  EARLY_ACCESS_ENABLED?: string;
  PUBLIC_SITE_ORIGIN?: string;
  OTP_SECRET?: string;
  RESEND_API_KEY?: string;
  EMAIL_FROM?: string;
};

const cookieName = "__Host-dml-early-access";
const ttl = 600;
const consentVersion = "early-access-2026-10-07";
const encoder = new TextEncoder();

class Failure extends Error {
  constructor(public status: number, public code: string, public retryAfter?: number, public fields?: string[]) {
    super(code);
  }
}

function json(data: unknown, status = 200, headers: Record<string, string> = {}) {
  return Response.json(data, { status, headers: {
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'; base-uri 'none'",
    ...headers,
  } });
}

function configured(env: Env) {
  return env.EARLY_ACCESS_ENABLED === "true" && !!env.DB && !!env.RESEND_API_KEY
    && !!env.PUBLIC_SITE_ORIGIN && (env.OTP_SECRET?.length ?? 0) >= 32
    && emailAddress.safeParse(env.EMAIL_FROM).success;
}

async function readBody(request: Request) {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") {
    throw new Failure(415, "invalid_content_type");
  }
  if (Number(request.headers.get("content-length")) > 4096) throw new Failure(413, "request_too_large");
  const reader = request.body?.getReader();
  if (!reader) throw new Failure(400, "invalid_input");
  const chunks: Uint8Array[] = [];
  let size = 0;
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; void reader.cancel(); }, 5000);
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      size += next.value.length;
      if (size > 4096) {
        await reader.cancel();
        throw new Failure(413, "request_too_large");
      }
      chunks.push(next.value);
    }
  } finally { clearTimeout(timer); }
  if (timedOut) throw new Failure(408, "invalid_input");
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  try { return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); }
  catch { throw new Failure(400, "invalid_input"); }
}

function randomToken() {
  return Array.from(crypto.getRandomValues(new Uint8Array(16)), value => value.toString(16).padStart(2, "0")).join("");
}

function randomCode() {
  const values = new Uint32Array(1);
  do { crypto.getRandomValues(values); } while (values[0] >= 4294000000);
  return String(values[0] % 1000000).padStart(6, "0");
}

async function key(secret: string) {
  return crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

async function digest(secret: string, value: string) {
  const signed = await crypto.subtle.sign("HMAC", await key(secret), encoder.encode(value));
  return Array.from(new Uint8Array(signed), value => value.toString(16).padStart(2, "0")).join("");
}

async function matches(secret: string, hash: string, value: string) {
  const bytes = Uint8Array.from(hash.match(/.{2}/g) ?? [], value => parseInt(value, 16));
  return crypto.subtle.verify("HMAC", await key(secret), bytes, encoder.encode(value));
}

async function limit(env: Env, subject: string, max: number, window: number, now: number) {
  const bucket = Math.floor(now / window) * window;
  const hash = await digest(env.OTP_SECRET!, `rate:${subject}`);
  const result = await statement(env.DB!, `INSERT INTO early_access_rate_limits (key, bucket, count)
    VALUES (?, ?, 1) ON CONFLICT(key, bucket) DO UPDATE SET count = count + 1
    WHERE count < ? RETURNING count`, hash, bucket, max).first();
  if (!result) throw new Failure(429, "too_many_requests", bucket + window - now);
}

async function cleanup(db: Database, now: number) {
  await db.batch([
    statement(db, "DELETE FROM early_access_challenges WHERE expires_at < ?", now),
    statement(db, "DELETE FROM early_access_rate_limits WHERE bucket < ?", now - 7200),
  ]);
}

function session(request: Request) {
  const values = (request.headers.get("cookie") ?? "").split(";").map(part => part.trim())
    .filter(part => part.startsWith(`${cookieName}=`)).map(part => part.slice(cookieName.length + 1));
  if (values.length !== 1 || !/^[a-f0-9]{32}$/.test(values[0])) throw new Failure(400, "invalid_code");
  return values[0];
}

async function sendEmail(env: Env, email: string, code: string, locale: string) {
  const subject = locale === "ru" ? "DML: код подтверждения почты" : "DML: email confirmation code";
  const text = locale === "ru"
    ? `Код подтверждения: ${code}\n\nКод действует 10 минут. Никому его не сообщайте.\nЕсли вы не записывались на ранний доступ DML, проигнорируйте письмо.`
    : `Confirmation code: ${code}\n\nValid for 10 minutes. Do not share it.\nIf you did not request DML early access, ignore this email.`;
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST", signal: AbortSignal.timeout(10000),
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${env.RESEND_API_KEY}` },
    body: JSON.stringify({ from: env.EMAIL_FROM, to: [email], subject, text }),
  });
  if (!response.ok) throw new Failure(503, "unavailable");
}

async function requestCode(request: Request, env: Env, input: unknown, now: number, ip: string) {
  const parsed = registrationInput.safeParse(input);
  if (!parsed.success) {
    throw new Failure(400, "invalid_input", undefined,
      [...new Set(parsed.error.issues.map(issue => String(issue.path[0] ?? "form")))]);
  }
  if (!configured(env)) throw new Failure(503, "unavailable");
  await cleanup(env.DB!, now);
  await limit(env, `send-ip:${ip}`, 5, 600, now);
  await limit(env, `send-email:${parsed.data.email}`, 3, 3600, now);
  await limit(env, "send-global", 120, 3600, now);
  const id = randomToken();
  const token = randomToken();
  const code = randomCode();
  const codeHash = await digest(env.OTP_SECRET!, `code:${id}:${code}`);
  const sessionHash = await digest(env.OTP_SECRET!, `session:${token}`);
  const { email, firstName, lastName, locale } = parsed.data;
  const created = await statement(env.DB!, `INSERT INTO early_access_challenges
    (id, email, first_name, last_name, code_hash, session_hash, created_at, expires_at, attempts, consumed_token)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 5, NULL) ON CONFLICT(email) DO UPDATE SET
    id = excluded.id, first_name = excluded.first_name, last_name = excluded.last_name,
    code_hash = excluded.code_hash, session_hash = excluded.session_hash,
    created_at = excluded.created_at, expires_at = excluded.expires_at, attempts = 5, consumed_token = NULL
    WHERE early_access_challenges.created_at <= ? RETURNING id`,
  id, email, firstName, lastName, codeHash, sessionHash, now, now + ttl, now - 60).first();
  if (!created) throw new Failure(429, "too_many_requests", 60);
  try { await sendEmail(env, email, code, locale); }
  catch {
    await statement(env.DB!, "DELETE FROM early_access_challenges WHERE id = ?", id).run();
    throw new Failure(503, "unavailable");
  }
  return json({ challengeId: id, expiresIn: ttl, resendAfter: 60 }, 200, {
    "Set-Cookie": `${cookieName}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${ttl}`,
  });
}

type Challenge = { email: string; code_hash: string; created_at: number };

async function verifyCode(request: Request, env: Env, input: unknown, now: number, ip: string) {
  const parsed = verificationInput.safeParse(input);
  if (!parsed.success) throw new Failure(400, "invalid_code");
  if (!configured(env)) throw new Failure(503, "unavailable");
  await limit(env, `verify-ip:${ip}`, 30, 600, now);
  const sessionHash = await digest(env.OTP_SECRET!, `session:${session(request)}`);
  const { challengeId, code } = parsed.data;
  // Reserve an attempt atomically before checking the code, including concurrent requests.
  const challenge = await statement(env.DB!, `UPDATE early_access_challenges SET attempts = attempts - 1
    WHERE id = ? AND session_hash = ? AND consumed_token IS NULL AND expires_at > ? AND attempts > 0
    RETURNING email, code_hash, created_at`, challengeId, sessionHash, now).first<Challenge>();
  if (!challenge || !await matches(env.OTP_SECRET!, challenge.code_hash, `code:${challengeId}:${code}`)) {
    throw new Failure(400, "invalid_code");
  }
  const claim = randomToken();
  // D1 batch is transactional. Only the request that consumes this challenge can insert a registration.
  const result = await env.DB!.batch([
    statement(env.DB!, `UPDATE early_access_challenges SET consumed_token = ?
      WHERE id = ? AND session_hash = ? AND consumed_token IS NULL AND expires_at > ?
      RETURNING id`, claim, challengeId, sessionHash, now),
    statement(env.DB!, `INSERT INTO early_access_registrations
      (email, id, first_name, last_name, verified_at, consent_at, consent_version, bonus_status)
      SELECT email, ?, first_name, last_name, ?, created_at, ?, 'reserved' FROM early_access_challenges
      WHERE id = ? AND consumed_token = ? ON CONFLICT(email) DO NOTHING`,
    crypto.randomUUID(), now, consentVersion, challengeId, claim),
  ]);
  if (!result[0].results.length) throw new Failure(400, "invalid_code");
  return json({ status: result[1].meta.changes === 1 ? "confirmed" : "already_confirmed" }, 200, {
    "Set-Cookie": `${cookieName}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`,
  });
}

export async function earlyAccess(request: Request, env: Env) {
  const path = new URL(request.url).pathname;
  if (path === "/api/early-access/status" && request.method === "GET") {
    return json({ available: configured(env) });
  }
  if (!["/api/early-access/request", "/api/early-access/verify"].includes(path)) return json({ error: "not_found" }, 404);
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405, { Allow: "POST" });
  try {
    if (!env.PUBLIC_SITE_ORIGIN || request.headers.get("origin") !== env.PUBLIC_SITE_ORIGIN
      || request.headers.get("sec-fetch-site") === "cross-site") throw new Failure(403, "forbidden");
    const input = await readBody(request);
    const now = Math.floor(Date.now() / 1000);
    const ip = request.headers.get("cf-connecting-ip") ?? request.headers.get("oai-authenticated-user-id") ?? "unknown";
    return path.endsWith("/request") ? await requestCode(request, env, input, now, ip)
      : await verifyCode(request, env, input, now, ip);
  } catch (error) {
    const failure = error instanceof Failure ? error : new Failure(503, "unavailable");
    return json({ error: failure.code, ...(failure.fields ? { fields: failure.fields } : {}) }, failure.status,
      failure.retryAfter ? { "Retry-After": String(failure.retryAfter) } : {});
  }
}
