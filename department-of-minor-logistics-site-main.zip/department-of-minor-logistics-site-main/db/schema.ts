import { sql } from "drizzle-orm";
import { check, index, integer, primaryKey, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const registrations = sqliteTable("early_access_registrations", {
  email: text("email").primaryKey(),
  id: text("id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  verifiedAt: integer("verified_at").notNull(),
  consentAt: integer("consent_at").notNull(),
  consentVersion: text("consent_version").notNull(),
  bonusStatus: text("bonus_status").notNull().default("reserved"),
  bonusClaimedAt: integer("bonus_claimed_at"),
}, table => [
  uniqueIndex("early_access_registration_id").on(table.id),
  check("early_access_email_length", sql`length(${table.email}) BETWEEN 3 AND 254`),
  check("early_access_bonus_status", sql`${table.bonusStatus} IN ('reserved', 'claimed')`),
]);

export const challenges = sqliteTable("early_access_challenges", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  codeHash: text("code_hash").notNull(),
  sessionHash: text("session_hash").notNull(),
  createdAt: integer("created_at").notNull(),
  expiresAt: integer("expires_at").notNull(),
  attempts: integer("attempts").notNull(),
  consumedToken: text("consumed_token"),
}, table => [
  uniqueIndex("early_access_one_challenge_per_email").on(table.email),
  index("early_access_challenge_expiry").on(table.expiresAt),
  check("early_access_attempts", sql`${table.attempts} BETWEEN 0 AND 5`),
]);

export const rateLimits = sqliteTable("early_access_rate_limits", {
  key: text("key").notNull(),
  bucket: integer("bucket").notNull(),
  count: integer("count").notNull(),
}, table => [
  primaryKey({ columns: [table.key, table.bucket] }),
  index("early_access_rate_expiry").on(table.bucket),
]);
