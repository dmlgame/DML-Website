import { DatabaseSync, backup } from "node:sqlite";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

process.umask(0o077);
const source = process.env.DATABASE_PATH ?? "/data/early-access.sqlite";
const directory = process.env.BACKUP_DIRECTORY ?? "/data/backups";
await mkdir(directory, { recursive: true, mode: 0o700 });
const filename = path.join(directory, `early-access-${new Date().toISOString().replace(/[:.]/g, "-")}-${randomUUID()}.sqlite`);
const sqlite = new DatabaseSync(source, { readOnly: true, timeout: 5000 });
try {
  await backup(sqlite, filename);
  console.log(`Backup saved: ${filename}`);
} finally { sqlite.close(); }
