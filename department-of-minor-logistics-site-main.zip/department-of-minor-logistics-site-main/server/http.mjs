import { createServer } from "node:http";
import { isIP } from "node:net";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

export function clientAddress(incoming, trustProxy) {
  // Trust this header only behind our private Caddy, which replaces the client-supplied value.
  const value = trustProxy ? incoming.headers["x-dml-client-ip"] : incoming.socket.remoteAddress;
  const ip = typeof value === "string" ? value.replace(/^::ffff:/, "") : "";
  return isIP(ip) ? ip : "unknown";
}

function requestBody(incoming) {
  let cleanup;
  return new ReadableStream({
    start(controller) {
      const data = chunk => {
        controller.enqueue(chunk);
        if (controller.desiredSize <= 0) incoming.pause();
      };
      const end = () => { cleanup(); controller.close(); };
      const error = () => { cleanup(); controller.error(new Error("Request interrupted")); };
      cleanup = () => { incoming.off("data", data); incoming.off("end", end); incoming.off("error", error); };
      incoming.on("data", data);
      incoming.once("end", end);
      incoming.once("error", error);
    },
    pull() { incoming.resume(); },
    // Cancelling a Web reader must not destroy the socket before the 413/408 response.
    cancel() { cleanup(); incoming.resume(); },
  });
}

export function createAppServer(worker, env, { trustProxy = false } = {}) {
  const server = createServer({ maxHeaderSize: 16384, requestTimeout: 15000, headersTimeout: 10000 }, async (incoming, outgoing) => {
    incoming.on("error", () => {});
    try {
      if (!incoming.url?.startsWith("/") || incoming.url.startsWith("//")) {
        outgoing.writeHead(400).end();
        incoming.resume();
        return;
      }
      if (incoming.url === "/healthz" && incoming.method === "GET") {
        await env.DB.prepare("SELECT 1 AS ok").first();
        outgoing.writeHead(200, { "Content-Type": "text/plain", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }).end("ok");
        return;
      }
      const headers = new Headers();
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (value !== undefined) headers.set(name, Array.isArray(value) ? value.join(", ") : value);
      }
      headers.delete("oai-authenticated-user-id");
      headers.delete("x-forwarded-for");
      headers.delete("x-real-ip");
      headers.delete("x-dml-client-ip");
      headers.set("cf-connecting-ip", clientAddress(incoming, trustProxy));
      const hasBody = !["GET", "HEAD"].includes(incoming.method);
      const request = new Request(`${env.PUBLIC_SITE_ORIGIN}${incoming.url}`, {
        method: incoming.method, headers,
        ...(hasBody ? { body: requestBody(incoming), duplex: "half" } : {}),
      });
      const response = await worker.fetch(request, env);
      if (!incoming.complete) outgoing.setHeader("Connection", "close");
      for (const [name, value] of response.headers) {
        if (name !== "set-cookie") outgoing.setHeader(name, value);
      }
      const cookies = response.headers.getSetCookie();
      if (cookies.length) outgoing.setHeader("Set-Cookie", cookies);
      outgoing.statusCode = response.status;
      if (incoming.method === "HEAD" || !response.body) {
        if (response.body) await response.body.cancel();
        outgoing.end();
      } else {
        await pipeline(Readable.fromWeb(response.body), outgoing);
      }
      if (!incoming.readableEnded) incoming.resume();
    } catch {
      // Do not log request bodies, database errors, addresses, codes or mail credentials.
      if (!outgoing.headersSent) {
        outgoing.writeHead(503, { "Content-Type": "application/json", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" })
          .end('{"error":"unavailable"}');
      } else outgoing.destroy();
      incoming.resume();
    }
  });
  server.keepAliveTimeout = 5000;
  server.maxHeadersCount = 80;
  server.maxRequestsPerSocket = 1000;
  return server;
}
