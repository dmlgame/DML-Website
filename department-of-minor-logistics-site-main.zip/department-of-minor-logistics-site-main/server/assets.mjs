import { createReadStream } from "node:fs";
import { realpath, stat } from "node:fs/promises";
import { Readable } from "node:stream";
import path from "node:path";

const mime = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json", ".txt": "text/plain; charset=utf-8",
  ".wasm": "application/wasm", ".pck": "application/octet-stream", ".png": "image/png",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml",
  ".ico": "image/x-icon", ".woff": "font/woff", ".woff2": "font/woff2",
  ".glb": "model/gltf-binary", ".gltf": "model/gltf+json", ".mp4": "video/mp4",
};

function inside(root, filename) {
  const relative = path.relative(root, filename);
  return relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative);
}

export async function assets(directory) {
  const root = await realpath(directory);
  return {
    async fetch(request) {
      if (!["GET", "HEAD"].includes(request.method)) {
        return new Response("Method not allowed", { status: 405, headers: { Allow: "GET, HEAD" } });
      }
      let pathname;
      try { pathname = decodeURIComponent(new URL(request.url).pathname); }
      catch { return new Response("Invalid path", { status: 400 }); }
      const segments = pathname.split("/").filter(Boolean);
      if (pathname.includes("\\") || pathname.includes("\0") || segments.some(segment => segment.startsWith(".") || segment.includes(":"))) {
        return new Response("Not found", { status: 404 });
      }
      const base = path.resolve(root, ...segments);
      const candidates = pathname.endsWith("/") ? [path.join(base, "index.html")] : [base, `${base}.html`, path.join(base, "index.html")];
      for (const candidate of candidates) {
        if (!inside(root, candidate)) continue;
        try {
          const filename = await realpath(candidate);
          if (!inside(root, filename)) continue;
          const file = await stat(filename);
          if (!file.isFile()) continue;
          const headers = {
            "Content-Type": mime[path.extname(filename)] ?? "application/octet-stream",
            "Content-Length": String(file.size),
            "Cache-Control": pathname.startsWith("/_next/static/") ? "public, max-age=31536000, immutable" : "no-cache",
          };
          if (pathname === "/demo/index.wasm") headers["Content-Encoding"] = "gzip";
          return new Response(request.method === "HEAD" ? null : Readable.toWeb(createReadStream(filename)), { headers });
        } catch (error) {
          if (!["ENOENT", "ENOTDIR"].includes(error.code)) throw error;
        }
      }
      return new Response(request.method === "HEAD" ? null : "Not found", { status: 404 });
    },
  };
}
