import { fileURLToPath } from "node:url";
import path from "node:path";
import { openDatabase, migrate } from "./database.mjs";
import { assets } from "./assets.mjs";
import { createAppServer } from "./http.mjs";

process.umask(0o077);
const root = fileURLToPath(new URL("../", import.meta.url));
const origin = process.env.PUBLIC_SITE_ORIGIN;
if (!origin || new URL(origin).origin !== origin || !origin.startsWith("https://")) {
  throw new Error("PUBLIC_SITE_ORIGIN must be an exact HTTPS origin without a trailing slash");
}
const enabled = process.env.EARLY_ACCESS_ENABLED ?? "false";
if (!["true", "false"].includes(enabled)) throw new Error("EARLY_ACCESS_ENABLED must be true or false");
if ((process.env.OTP_SECRET?.length ?? 0) < 32) throw new Error("Configure a private OTP_SECRET of at least 32 characters");
if (enabled === "true" && (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM)) {
  throw new Error("Configure a verified mail sender before enabling registration");
}
const port = Number(process.env.PORT ?? "3000");
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");

const { sqlite, DB } = openDatabase(process.env.DATABASE_PATH ?? path.join(root, "data/early-access.sqlite"));
try {
  const count = migrate(sqlite, path.join(root, "drizzle"));
  const worker = (await import(new URL("../dist/server/index.js", import.meta.url))).default;
  const env = {
    DB, ASSETS: await assets(path.join(root, "dist/client")), PUBLIC_SITE_ORIGIN: origin,
    EARLY_ACCESS_ENABLED: enabled, OTP_SECRET: process.env.OTP_SECRET,
    RESEND_API_KEY: process.env.RESEND_API_KEY, EMAIL_FROM: process.env.EMAIL_FROM,
  };
  const status = await worker.fetch(new Request(`${origin}/api/early-access/status`), env);
  if (enabled === "true" && !(await status.json()).available) throw new Error("Mail configuration is invalid");
  const server = createAppServer(worker, env, { trustProxy: process.env.TRUST_CADDY === "true" });
  server.listen(port, process.env.HOST ?? "127.0.0.1", () => {
    console.log(`DML started on port ${port}; ${count} migrations applied; registration ${enabled === "true" ? "enabled" : "disabled"}.`);
  });
  server.on("error", () => { console.error("HTTP server failed to start"); sqlite.close(); process.exitCode = 1; });
  let stopping = false;
  function shutdown() {
    if (stopping) return;
    stopping = true;
    const timer = setTimeout(() => server.closeAllConnections(), 20000);
    timer.unref();
    server.close(() => { clearTimeout(timer); sqlite.close(); });
  }
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
} catch (error) {
  sqlite.close();
  throw error;
}
