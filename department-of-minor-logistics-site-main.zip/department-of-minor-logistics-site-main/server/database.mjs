import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

export function openDatabase(filename) {
  if (filename !== ":memory:") mkdirSync(path.dirname(filename), { recursive: true, mode: 0o700 });
  const sqlite = new DatabaseSync(filename, { timeout: 5000, defensive: true });
  sqlite.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA trusted_schema=OFF;");

  class Statement {
    constructor(sql, values = []) { this.sql = sql; this.values = values; }
    bind(...values) { return new Statement(this.sql, values); }
    execute() {
      const query = sqlite.prepare(this.sql);
      const results = query.columns().length ? query.all(...this.values) : [];
      if (!query.columns().length) query.run(...this.values);
      return { results, meta: { changes: Number(sqlite.prepare("SELECT changes() AS n").get().n) } };
    }
    async first() { return this.execute().results[0] ?? null; }
    async all() { return this.execute(); }
    async run() { return this.execute(); }
  }

  const DB = {
    prepare(sql) {
      if (sql.trim().replace(/;$/, "").includes(";")) throw new Error("Only one prepared statement is allowed");
      return new Statement(sql);
    },
    async batch(statements) {
      // No await inside this transaction: other requests cannot interleave its statements.
      sqlite.exec("BEGIN IMMEDIATE");
      try {
        const results = statements.map(statement => statement.execute());
        sqlite.exec("COMMIT");
        return results;
      } catch (error) {
        sqlite.exec("ROLLBACK");
        throw error;
      }
    },
  };
  return { sqlite, DB };
}

export function migrate(sqlite, directory) {
  const journal = JSON.parse(readFileSync(path.join(directory, "meta/_journal.json"), "utf8"));
  if (journal.dialect !== "sqlite" || !Array.isArray(journal.entries)) throw new Error("Invalid migration journal");
  const migrations = journal.entries.map((entry, index) => {
    if (entry.idx !== index || !/^[a-zA-Z0-9_]+$/.test(entry.tag)) throw new Error("Invalid migration order");
    const sql = readFileSync(path.join(directory, `${entry.tag}.sql`), "utf8").replace(/\r\n/g, "\n");
    return { name: entry.tag, sql, hash: createHash("sha256").update(sql).digest("hex") };
  });
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    sqlite.exec("CREATE TABLE IF NOT EXISTS _dml_migrations (position INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, hash TEXT NOT NULL)");
    const applied = sqlite.prepare("SELECT position, name, hash FROM _dml_migrations ORDER BY position").all();
    for (const [index, row] of applied.entries()) {
      const expected = migrations[index];
      if (row.position !== index || !expected || row.name !== expected.name || row.hash !== expected.hash) {
        throw new Error("Applied migration was changed or removed; deployment stopped");
      }
    }
    for (let index = applied.length; index < migrations.length; index++) {
      const migration = migrations[index];
      sqlite.exec(migration.sql);
      sqlite.prepare("INSERT INTO _dml_migrations VALUES (?, ?, ?)").run(index, migration.name, migration.hash);
    }
    sqlite.exec("COMMIT");
    return migrations.length - applied.length;
  } catch (error) {
    sqlite.exec("ROLLBACK");
    throw error;
  }
}
