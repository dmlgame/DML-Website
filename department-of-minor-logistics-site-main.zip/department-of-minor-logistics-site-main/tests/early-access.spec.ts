import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import { copy } from "../src/config/site";
import { earlyAccessCopy } from "../src/features/EarlyAccess/copy";

async function open(page: Page, lang: "ru" | "en" = "ru") {
  await page.goto(`/?lang=${lang}`);
  const button = page.getByRole("button", { name: `${copy[lang].ending.earlyAccess} ${copy[lang].ending.comingSoon}`, exact: true });
  await button.scrollIntoViewIfNeeded();
  await button.click();
  await expect(page.getByRole("dialog")).toBeVisible();
  return button;
}

async function fill(page: Page) {
  await page.getByLabel("Имя", { exact: true }).fill("Анна");
  await page.getByLabel("Фамилия", { exact: true }).fill("O'Connor");
  await page.getByLabel("Почта", { exact: true }).fill("ANNA@Example.com");
  await page.getByRole("checkbox").check();
}

test("early access keeps its explanation and opens an honest unavailable form in both languages", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.emulateMedia({ reducedMotion: "reduce" });
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  for (const lang of ["ru", "en"] as const) {
    for (const width of [1440, 1024, 390, 360]) {
      await page.setViewportSize({ width, height: 844 });
      await page.goto(`/?lang=${lang}`);
      const button = page.getByRole("button", { name: `${copy[lang].ending.earlyAccess} ${copy[lang].ending.comingSoon}`, exact: true });
      await button.scrollIntoViewIfNeeded();
      await button.hover();
      await expect(page.getByRole("tooltip")).toHaveText(copy[lang].ending.earlyAccessDescription);
      await button.click();
      const dialog = page.getByRole("dialog");
      await expect(dialog).toBeVisible();
      await expect(dialog).toContainText(earlyAccessCopy[lang].unavailable);
      await expect(dialog.getByRole("button", { name: earlyAccessCopy[lang].send })).toBeDisabled();
      await expect(dialog.locator('input[type="email"]')).toHaveCount(1);
      expect(await dialog.evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
      const bounds = (await dialog.boundingBox())!;
      expect(bounds.x).toBeGreaterThanOrEqual(0);
      expect(bounds.x + bounds.width).toBeLessThanOrEqual(width);
      await page.screenshot({ path: `qa/early-access-form-${lang}-${width}.png` });
      await page.keyboard.press("Escape");
      await expect(dialog).toHaveCount(0);
      await expect(button).toBeFocused();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    }
  }
  expect(errors).toEqual([]);
});

test("validation, code errors, confirmation and duplicate states use the server response", async ({ page }) => {
  await page.route("**/api/early-access/status", route => route.fulfill({ json: { available: true } }));
  const sends: unknown[] = [];
  await page.route("**/api/early-access/request", route => {
    sends.push(route.request().postDataJSON());
    return route.fulfill({ json: { challengeId: "a".repeat(32), expiresIn: 600, resendAfter: 60 } });
  });
  let outcome = "invalid";
  await page.route("**/api/early-access/verify", route => outcome === "invalid"
    ? route.fulfill({ status: 400, json: { error: "invalid_code" } })
    : route.fulfill({ json: { status: outcome } }));
  await open(page);
  await expect(page.getByRole("button", { name: "Получить код" })).toBeEnabled();
  await page.getByRole("button", { name: "Получить код" }).click();
  await expect(page.locator('input[aria-invalid="true"]')).toHaveCount(4);
  expect(sends).toHaveLength(0);
  await fill(page);
  await page.getByLabel("Почта", { exact: true }).fill("broken@mail");
  await page.getByRole("button", { name: "Получить код" }).click();
  await expect(page.getByText(earlyAccessCopy.ru.invalidEmail, { exact: true })).toBeVisible();
  expect(sends).toHaveLength(0);
  await page.getByLabel("Почта", { exact: true }).fill("ANNA@Example.com");
  await page.getByRole("button", { name: "Получить код" }).click();
  await expect(page.getByLabel("Код из письма")).toBeFocused();
  for (const width of [1440, 360]) {
    await page.setViewportSize({ width, height: 844 });
    const dialog = page.getByRole("dialog");
    expect(await dialog.evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
    await page.screenshot({ path: `qa/early-access-code-ru-${width}.png` });
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  expect(sends).toEqual([{ firstName: "Анна", lastName: "O'Connor", email: "anna@example.com", consent: true, locale: "ru" }]);
  await expect(page.getByRole("button", { name: /Отправить код ещё раз/ })).toBeDisabled();
  await page.getByLabel("Код из письма").fill("123456");
  await page.getByRole("button", { name: "Подтвердить почту" }).click();
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(earlyAccessCopy.ru.invalidCode);
  outcome = "confirmed";
  await page.getByRole("button", { name: "Подтвердить почту" }).click();
  await expect(page.getByRole("dialog")).toContainText(earlyAccessCopy.ru.success);
  await page.screenshot({ path: "qa/early-access-confirmed.png" });
  await page.getByRole("dialog").getByRole("button", { name: "Закрыть", exact: true }).last().click();
  outcome = "already_confirmed";
  await open(page);
  await fill(page);
  await page.getByRole("button", { name: "Получить код" }).click();
  await page.getByLabel("Код из письма").fill("654321");
  await page.getByRole("button", { name: "Подтвердить почту" }).click();
  await expect(page.getByRole("dialog")).toContainText(earlyAccessCopy.ru.already);
  expect(await page.evaluate(() => localStorage.getItem("email"))).toBeNull();
});

test("delivery failure never advances to code entry and preserves entered details", async ({ page }) => {
  await page.route("**/api/early-access/status", route => route.fulfill({ json: { available: true } }));
  await page.route("**/api/early-access/request", route => route.fulfill({ status: 503, json: { error: "unavailable" } }));
  await open(page);
  await fill(page);
  await page.getByRole("button", { name: "Получить код" }).click();
  await expect(page.getByRole("button", { name: "Получить код" })).toBeDisabled();
  await expect(page.getByLabel("Код из письма")).toHaveCount(0);
  await expect(page.getByLabel("Имя", { exact: true })).toHaveValue("Анна");
  await expect(page.getByLabel("Почта", { exact: true })).toHaveValue("ANNA@Example.com");
});

test("keyboard focus stays inside the mobile dialog", async ({ page }) => {
  await page.setViewportSize({ width: 360, height: 640 });
  const button = await open(page);
  for (let index = 0; index < 15; index++) {
    await page.keyboard.press("Tab");
    expect(await page.getByRole("dialog").evaluate(element => element.contains(document.activeElement))).toBe(true);
  }
  await page.keyboard.press("Escape");
  await expect(button).toBeFocused();
});
