import { mkdir } from "node:fs/promises";
import { expect, test } from "@playwright/test";

test("animation autoplay is half speed on mobile, unchanged on desktop and respects pause", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/?lang=ru");
  const stage = page.getByRole("application");
  await stage.scrollIntoViewIfNeeded();
  await expect.poll(() => stage.evaluate(element => Number(getComputedStyle(element).getPropertyValue("--preview-rate")))).toBe(0.5);
  for (const mode of ["foot", "transporter", "pallet-jack"]) {
    await page.locator(`#movement-tab-${mode}`).click();
    await page.waitForTimeout(150);
    const frames = await page.getByTestId("movement-sprite").evaluate(async element => {
      let previous = (element as HTMLElement).style.backgroundPosition;
      let changes = 0;
      const start = performance.now();
      await new Promise<void>(resolve => {
        const sample = () => {
          const next = (element as HTMLElement).style.backgroundPosition;
          if (next !== previous) { changes++; previous = next; }
          if (performance.now() - start >= 1000) resolve();
          else requestAnimationFrame(sample);
        };
        requestAnimationFrame(sample);
      });
      return changes;
    });
    expect(frames).toBeGreaterThanOrEqual(mode === "foot" ? 4 : 2);
    expect(frames).toBeLessThanOrEqual(mode === "foot" ? 6 : 4);
    await page.locator("#movement").screenshot({ path: `qa/mobile-slow-animation-${mode}.png` });
  }
  await page.getByRole("button", { name: "Приостановить анимацию", exact: true }).click();
  await page.waitForTimeout(100);
  const actor = page.getByTestId("movement-actor");
  const stopped = await actor.getAttribute("style");
  await page.waitForTimeout(250);
  expect(await actor.getAttribute("style")).toBe(stopped);
  await page.setViewportSize({ width: 1440, height: 1000 });
  await stage.scrollIntoViewIfNeeded();
  await expect.poll(() => stage.evaluate(element => Number(getComputedStyle(element).getPropertyValue("--preview-rate")))).toBe(1);
  await page.locator("#movement-tab-foot").click();
  await page.waitForTimeout(150);
  const desktopFrames = await page.getByTestId("movement-sprite").evaluate(async element => {
    const positions = new Set<string>();
    const start = performance.now();
    await new Promise<void>(resolve => {
      const sample = () => {
        positions.add((element as HTMLElement).style.backgroundPosition);
        if (performance.now() - start >= 750) resolve();
        else requestAnimationFrame(sample);
      };
      requestAnimationFrame(sample);
    });
    return positions.size;
  });
  expect(desktopFrames).toBeGreaterThanOrEqual(6);
  await page.locator("#movement").screenshot({ path: "qa/desktop-normal-animation.png" });
  expect(errors).toEqual([]);
});

test("wide touch screens also use the slower autoplay rate", async ({ browser, baseURL }) => {
  const context = await browser.newContext({ baseURL, hasTouch: true, viewport: { width: 1024, height: 768 } });
  const page = await context.newPage();
  await page.goto("/");
  const stage = page.getByRole("application");
  await stage.scrollIntoViewIfNeeded();
  expect(await stage.evaluate(element => Number(getComputedStyle(element).getPropertyValue("--preview-rate")))).toBe(0.5);
  await context.close();
});
