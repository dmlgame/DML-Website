import { expect, test } from "@playwright/test";

test("Russian is the default in generated HTML and when no language is selected", async ({ page, request }) => {
  const response = await request.get("/");
  const html = await response.text();
  expect(html).toContain('<html lang="ru">');
  expect(html).toContain("Независимая игра о складе");
  for (const url of ["/", "/?lang=ru", "/?lang=unknown"]) {
    await page.goto(url);
    await expect(page.locator("html")).toHaveAttribute("lang", "ru");
    await expect(page.getByRole("button", { name: "RU", exact: true })).toHaveAttribute("aria-pressed", "true");
    await expect(page.locator("#overview")).toContainText("Краткая информация");
  }
  const languages = page.locator('[aria-label="Language"] button');
  await expect(languages.nth(0)).toHaveText("RU");
  await expect(languages.nth(1)).toHaveText("EN");
});

test("English is opt-in and survives reload; Russian returns to the base URL", async ({ page }) => {
  await page.goto("/?campaign=demo#overview");
  await page.getByRole("button", { name: "EN", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  await expect(page.locator("#overview")).toContainText("PC and mobile devices");
  let url = new URL(page.url());
  expect(url.searchParams.get("lang")).toBe("en");
  expect(url.searchParams.get("campaign")).toBe("demo");
  expect(url.hash).toBe("#overview");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  await expect(page.getByRole("button", { name: "EN", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "RU", exact: true }).click();
  url = new URL(page.url());
  expect(url.searchParams.has("lang")).toBe(false);
  expect(url.searchParams.get("campaign")).toBe("demo");
  expect(url.hash).toBe("#overview");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "ru");
});

test("registration opened from the default page uses the Site's brand and Russian copy", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Ранний доступ Скоро", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(dialog.getByLabel("Имя", { exact: true })).toBeVisible();
  await expect(dialog.getByLabel("Фамилия", { exact: true })).toBeVisible();
  const design = await dialog.evaluate(element => {
    const style = getComputedStyle(element);
    const heading = getComputedStyle(element.firstElementChild!);
    const primary = getComputedStyle(element.querySelector('button[type="submit"]')!);
    return { radius: style.borderRadius, border: style.borderWidth, shadow: style.boxShadow, heading: heading.backgroundColor, primary: primary.backgroundColor };
  });
  expect(design.radius).toBe("0px");
  expect(design.border).toBe("3px");
  expect(design.shadow).toContain("8px 8px");
  expect(design.heading).toBe("rgb(198, 48, 38)");
  expect(design.primary).toBe("rgb(243, 200, 73)");
});
