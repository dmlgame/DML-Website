import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedDemoSave } from "./helpers/demo";

async function advance(page: Page, mobile: boolean) {
  if (!mobile) await page.keyboard.press("Enter");
  else {
    const { data, info } = await sharp(await page.screenshot({ scale: "css" })).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    let x = 0, y = 0, count = 0;
    for (let i = 0; i < data.length; i += info.channels) {
      if (data[i] > 180 && data[i + 1] > 140 && data[i + 2] < 100) {
        x += (i / info.channels) % info.width;
        y += Math.floor(i / info.channels / info.width);
        count++;
      }
    }
    expect(count).toBeGreaterThan(1000);
    await page.touchscreen.tap(x / count, y / count);
  }
  await page.waitForTimeout(150);
}

for (const device of [
  { name: "desktop", mobile: false, viewport: { width: 1280, height: 720 } },
  { name: "portrait", mobile: true, viewport: { width: 390, height: 844 } },
  { name: "landscape", mobile: true, viewport: { width: 844, height: 390 } },
]) {
  test.describe(device.name, () => {
    test.use({ isMobile: device.mobile, hasTouch: device.mobile, viewport: device.viewport, deviceScaleFactor: device.mobile ? 2 : 1 });
    test(`section lead ends the demo with thanks and an exploration page ${device.name}`, async ({ page }) => {
      test.setTimeout(120000);
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
      async function resume() {
        await page.goto("/demo/index.html");
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
      }
      async function save(stage: string) {
        const previous = (await autosave(page))?.timestamp ?? 0;
        await page.keyboard.press("F5");
        await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(previous);
        await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(stage);
      }
      await resume();
      await save("find_director");
      const jack = "YSortActors/PalletJackAssets/PalletJackRight6";
      await seedDemoSave(page, "report_preparation", [-561.8, -2552.2], {
        demo: { completed: true, zph_assignment: true, gate17_checked: true, gate19_open: true, placed_count: 12,
          assigned_vehicle: jack, pallet_source: [12, -65], pallet_delivered: false, pallet_return: [12, -65],
          tote_source: [-134, -99], totes_delivered: true },
        player: { vehicle: jack, direction: [0, -1], pickup_offset: [0, -28] }, gate_open: true,
      });
      await resume();
      if (device.mobile) await page.touchscreen.tap(device.viewport.width - 42, device.viewport.height - 106);
      else await page.keyboard.press("e");
      await page.waitForTimeout(250);
      await mkdir("qa", { recursive: true });
      await page.screenshot({ path: `qa/final-dialogue-thanks-${device.name}.png`, scale: "css" });
      await advance(page, device.mobile);
      await page.screenshot({ path: `qa/final-dialogue-exploration-${device.name}.png`, scale: "css" });
      if (device.mobile) await expect(page.locator("#fullscreen")).toBeHidden();
      await page.keyboard.press("Escape");
      await save("report_preparation");
      if (device.mobile) await page.touchscreen.tap(device.viewport.width - 118, device.viewport.height - 106);
      else await page.keyboard.press("e");
      await page.waitForTimeout(250);
      await advance(page, device.mobile);
      await advance(page, device.mobile);
      await save("preparation_complete");
      expect((await autosave(page))!.demo.hint_enabled).toBe(false);
      if (device.mobile) await expect(page.locator("#fullscreen")).toBeVisible();
      await page.screenshot({ path: `qa/final-dialogue-complete-${device.name}.png`, scale: "css" });
      await page.reload();
      await running(page);
      await page.waitForTimeout(350);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await save("preparation_complete");
      await expect(page).toHaveTitle("Department of Minor Logistics | Демо-версия");
      expect(errors).toEqual([]);
    });
  });
}
