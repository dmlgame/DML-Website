import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import * as THREE from "three";
import { advancePreview, initialPreview, spriteUrl } from "../src/features/MovementDemo/movement";
import { createObjectModel } from "../src/features/ObjectViewer/models";
import { copy, site } from "../src/config/site";

async function inspectMovementSprite(page: Page) {
  return page.getByTestId("movement-sprite").evaluate(async (sprite) => {
    const style = getComputedStyle(sprite);
    const image = new Image();
    image.src = style.backgroundImage.slice(5, -2);
    await image.decode();
    const sample = document.createElement("canvas");
    sample.width = sample.height = 256;
    const context = sample.getContext("2d")!;
    context.drawImage(image, -parseFloat(style.backgroundPositionX), 0, 256, 256, 0, 0, 256, 256);
    const pixels = context.getImageData(0, 0, 256, 256).data;
    let visible = 0;
    let left = 256, top = 256, right = 0, bottom = 0;
    const colors = new Set<string>();
    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] < 40) continue;
      visible++;
      const x = (i / 4) % 256;
      const y = Math.floor(i / 4 / 256);
      left = Math.min(left, x); top = Math.min(top, y);
      right = Math.max(right, x + 1); bottom = Math.max(bottom, y + 1);
      colors.add(`${pixels[i]},${pixels[i + 1]},${pixels[i + 2]}`);
    }
    const bounds = sprite.getBoundingClientRect();
    const stage = sprite.closest('[role="application"]')!.getBoundingClientRect();
    const inside = bounds.left + left / 256 * bounds.width >= stage.left &&
      bounds.top + top / 256 * bounds.height >= stage.top &&
      bounds.left + right / 256 * bounds.width <= stage.right &&
      bounds.top + bottom / 256 * bounds.height <= stage.bottom;
    return { visible, colors: colors.size, inside, width: image.naturalWidth, height: image.naturalHeight };
  });
}

async function checkGallery(page: Page) {
  const gallery = page.locator("#gallery");
  await gallery.scrollIntoViewIfNeeded();
  const images = gallery.locator("img");
  await expect(images).toHaveCount(4);
  for (const [index, asset] of site.media.gallery.entries()) {
    const image = images.nth(index);
    await expect(image).toHaveAttribute("src", asset.src);
    await expect.poll(() => image.evaluate((element: HTMLImageElement, dimensions) => element.complete && element.naturalWidth === dimensions.width && element.naturalHeight === dimensions.height, asset)).toBe(true);
  }
}

test("requested Russian copy and replacement charging photo fit desktop and mobile", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [390, 1440]) {
    await page.setViewportSize({ width, height: width < 700 ? 844 : 900 });
    await page.goto("/?lang=ru");
    if (width < 920) await page.getByRole("button", { name: "Open menu" }).click();
    await expect(page.locator('header a[href="#overview"]')).toHaveText("Инфо");
    await expect(page.locator('header a[href="#gallery"]')).toHaveText("Фотоотчет");
    await page.locator('header a[href="#overview"]').click();
    await expect(page.locator("#overview")).toContainText("Краткая информация / 01");
    await expect(page.locator("#overview")).not.toContainText("Инструктаж");
    await page.locator("#overview").screenshot({ path: `qa/copy-overview-${width}.png` });
    await page.getByRole("tab", { name: /Ворота приемки/ }).click();
    await expect(page.locator("#objects")).toContainText("Через этот портал прибывают товары");
    await expect(page.locator("#objects")).not.toContainText("Въезд для грузов");
    await page.locator("#objects").screenshot({ path: `qa/copy-gate-${width}.png` });
    await checkGallery(page);
    const photo = page.locator("#gallery figure").nth(2);
    await expect(photo.locator("img")).toHaveAttribute("src", "/media/gallery-charging-v2.png");
    await expect(photo.locator("figcaption")).toContainText("Зарядные места транспорта");
    const dimensions = await photo.locator("img").evaluate((image: HTMLImageElement) => {
      const rect = image.getBoundingClientRect();
      return { displayed: rect.width / rect.height, original: image.naturalWidth / image.naturalHeight };
    });
    expect(Math.abs(dimensions.displayed - dimensions.original)).toBeLessThan(0.01);
    await photo.screenshot({ path: `qa/copy-charging-${width}.png` });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  }
});

test("first gallery photo shows the lift without editor chrome on desktop and mobile", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [390, 1440]) {
    await page.setViewportSize({ width, height: width < 700 ? 844 : 900 });
    await page.goto("/?lang=ru");
    await checkGallery(page);
    const photo = page.locator("#gallery figure").first();
    await expect(photo.locator("img")).toHaveAttribute("src", "/media/gallery-stockroom-lift.png");
    const crop = await photo.locator("img").evaluate((image: HTMLImageElement) => {
      const rect = image.getBoundingClientRect();
      const frame = image.parentElement!.getBoundingClientRect();
      const scale = image.naturalWidth / rect.width;
      return {
        x: (frame.left - rect.left) * scale,
        y: (frame.top - rect.top) * scale,
        width: frame.width * scale,
        height: frame.height * scale,
        clipped: getComputedStyle(image.parentElement!).overflow === "hidden",
      };
    });
    expect(crop.clipped).toBe(true);
    expect(crop.x).toBeCloseTo(384, 0);
    expect(crop.y).toBeCloseTo(196, 0);
    expect(crop.width).toBeCloseTo(1152, 0);
    expect(crop.height).toBeCloseTo(648, 0);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await photo.evaluate((element) => {
      const top = element.getBoundingClientRect().top + scrollY;
      const headerHeight = document.querySelector("header")!.getBoundingClientRect().height;
      scrollTo(0, top - headerHeight - 16);
    });
    await photo.screenshot({ path: `qa/gallery-lift-${width}.png` });
  }
});

test("approved logo and brand palette render without overlapping the hero", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.goto("/");
  const heroBackground = await page.locator("#top").evaluate(async (hero) => {
    const url = getComputedStyle(hero).backgroundImage.slice(5, -2).replaceAll('"', "");
    const image = new Image();
    image.src = url;
    await image.decode();
    return { url: new URL(url).pathname, width: image.naturalWidth, height: image.naturalHeight };
  });
  expect(heroBackground.url).toBe("/media/hero-conveyor-3d-v2.png");
  expect(heroBackground.width).toBeGreaterThan(1500);
  expect(heroBackground.height).toBeGreaterThan(800);
  const logos = page.locator("[data-brand-logo] img");
  await expect(logos).toHaveCount(3);
  for (const logo of await logos.all()) {
    await expect(logo).toHaveAttribute("src", "/media/dml-logo.png");
    await expect.poll(() => logo.evaluate((image: HTMLImageElement) => image.complete && image.naturalWidth === 1672)).toBe(true);
  }
  const asset = await logos.first().evaluate((image: HTMLImageElement) => {
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d")!;
    context.drawImage(image, 0, 0);
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let transparent = 0, red = 0, black = 0, yellow = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] === 0) { transparent++; continue; }
      if (pixels[i + 3] < 200) continue;
      if (pixels[i] > 150 && pixels[i + 1] < 90 && pixels[i + 2] < 90) red++;
      if (pixels[i] < 20 && pixels[i + 1] < 20 && pixels[i + 2] < 20) black++;
      if (pixels[i] > 180 && pixels[i + 1] > 140 && pixels[i + 2] < 100) yellow++;
    }
    return { transparent, red, black, yellow };
  });
  expect(asset.transparent).toBeGreaterThan(100000);
  expect(asset.red).toBeGreaterThan(100000);
  expect(asset.black).toBeGreaterThan(20000);
  expect(asset.yellow).toBeGreaterThan(5000);
  const palette = await page.evaluate(() => {
    const style = getComputedStyle(document.documentElement);
    return ["--red", "--ink", "--yellow"].map((name) => style.getPropertyValue(name).trim());
  });
  expect(palette).toEqual(["#e63e35", "#202729", "#f3c849"]);
  const headerLogo = page.locator('header [data-brand-logo="full"]');
  const heroLogo = page.locator('#top [data-brand-logo="full"]');
  await expect(headerLogo.locator("[data-brand-title]")).toHaveText("Department ofMinor Logistics");
  await expect(heroLogo.locator("[data-brand-title]")).toHaveText("Department ofMinor Logistics");
  await expect(page.locator("[data-brand-belt]")).toHaveCount(3);
  await expect(page.locator("[data-brand-belt]").first()).toHaveAttribute("fill", "#050505");
  await expect(headerLogo.locator("[data-brand-wheel]")).toHaveCount(4);
  await expect(heroLogo.locator("[data-brand-wheel]")).toHaveCount(4);
  await expect(page.locator("[data-brand-wheel]").first()).toHaveAttribute("stroke", "#050505");
  await expect(page.locator("[data-brand-parcel]").first()).toHaveAttribute("stroke-width", "16");
  for (const width of [360, 390, 1440, 1920]) {
    await page.setViewportSize({ width, height: width < 700 ? 844 : 1080 });
    const background = await page.locator("#top").evaluate(async (hero) => {
      const url = getComputedStyle(hero).backgroundImage.slice(5, -2).replaceAll('"', "");
      const image = new Image();
      image.src = url;
      await image.decode();
      return { path: new URL(url).pathname, width: image.naturalWidth, height: image.naturalHeight };
    });
    expect(background.path).toBe(width < 700 ? "/media/hero-conveyor-3d-mobile.png" : "/media/hero-conveyor-3d-v2.png");
    expect(background.height > background.width).toBe(width < 700);
    const header = await page.locator("header").boundingBox();
    const headerMark = await headerLogo.locator("[data-brand-mark]").boundingBox();
    const headerTitle = await headerLogo.locator("[data-brand-title]").boundingBox();
    const heroMark = await heroLogo.locator("[data-brand-mark]").boundingBox();
    const heroTitle = await heroLogo.locator("[data-brand-title]").boundingBox();
    expect(heroMark!.y).toBeGreaterThan(header!.y + header!.height);
    expect(headerTitle!.y).toBeGreaterThanOrEqual(headerMark!.y + headerMark!.height);
    expect(heroTitle!.y).toBeGreaterThanOrEqual(heroMark!.y + heroMark!.height);
    expect(Math.abs((headerTitle!.x - headerMark!.x) / headerMark!.width - (heroTitle!.x - heroMark!.x) / heroMark!.width)).toBeLessThan(0.01);
    expect(await headerLogo.locator("[data-brand-title]").evaluate((title) => title.scrollWidth <= title.clientWidth)).toBe(true);
    expect(await heroLogo.locator("[data-brand-title]").evaluate((title) => title.scrollWidth <= title.clientWidth)).toBe(true);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: `qa/brand-top-${width}.png` });
  }
});

test("header stays visible and section links land below it", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [390, 1440]) {
    await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
    await page.goto("/?lang=ru");
    await expect(page.locator("#top")).toContainText("Листай вниз, чтоб узнать больше");
    await expect(page.locator("#top a")).toHaveCount(0);
    for (const id of ["overview", "movement", "objects", "gallery"]) {
      if (width < 920) await page.getByRole("button", { name: "Open menu" }).click();
      await page.locator(`header a[href="#${id}"]`).click();
      await expect.poll(async () => {
        const header = await page.locator("header").boundingBox();
        const section = await page.locator(`#${id}`).boundingBox();
        return !!header && !!section && Math.abs(header.y) < 1 &&
          section.y >= header.height && section.y < header.height + 24;
      }).toBe(true);
    }
  }
});

test("movement state preserves direction, speed and safe bounds", () => {
  const size = { width: 354, height: 236, scale: 1.1 };
  const start = initialPreview();
  const foot = advancePreview(start, "foot", "right", false, 0.1, size);
  const jack = advancePreview(start, "pallet-jack", "right", false, 0.1, size);
  expect(foot.position.x).toBeGreaterThan(jack.position.x);
  expect(foot.frame).toBe(1);
  const stopped = advancePreview(foot, "foot", null, false, 0.1, size);
  expect(stopped.position).toEqual(foot.position);
  expect(spriteUrl("foot", stopped)).toBe("/media/foot-idle-right.png");
  expect(advancePreview(start, "transporter", "up", false, 20, size).position.y).toBeGreaterThan(25);
  expect(advancePreview(start, "transporter", "down", false, 20, size).position.y).toBeLessThan(75);
  expect(advancePreview(start, "pallet-jack", "left", false, 20, size).position.x).toBe(25);
  expect(advancePreview(start, "pallet-jack", "right", false, 20, size).position.x).toBe(75);
});

test("equipment models use the shaped pallet-jack handle and crosswise conveyor rollers", () => {
  const palletJack = createObjectModel("pallet-jack");
  const grip = palletJack.getObjectByName("pallet-jack-grip") as THREE.Mesh;
  expect(grip.geometry).toBeInstanceOf(THREE.ExtrudeGeometry);
  expect((grip.geometry as THREE.ExtrudeGeometry).parameters.shapes).toBeInstanceOf(THREE.Shape);
  expect(((grip.geometry as THREE.ExtrudeGeometry).parameters.shapes as THREE.Shape).holes).toHaveLength(1);
  const conveyor = createObjectModel("conveyor");
  const bend = conveyor.getObjectByName("conveyor-belt-bend") as THREE.Mesh;
  expect(bend.geometry).toBeInstanceOf(THREE.ExtrudeGeometry);
  for (const rail of ["conveyor-lower-inner-rail", "conveyor-lower-outer-rail"]) {
    expect(conveyor.getObjectByName(rail)).toBeInstanceOf(THREE.Mesh);
    expect((conveyor.getObjectByName(rail) as THREE.Mesh).geometry).toBeInstanceOf(THREE.ExtrudeGeometry);
  }
  expect(conveyor.children.some((child) => child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry)).toBe(false);
  const rollers = conveyor.children.filter((child) => child.name === "conveyor-roller");
  expect(rollers.length).toBeGreaterThan(10);
  expect(rollers.some((roller) => Math.abs(roller.rotation.x - Math.PI / 2) < 0.01)).toBe(true);
  expect(rollers.some((roller) => Math.abs(roller.rotation.z - Math.PI / 2) < 0.01)).toBe(true);
  const rack = createObjectModel("storage-rack");
  expect(rack.children.filter((child) => child.name === "storage-shelf")).toHaveLength(5);
  const uprights = rack.children.filter((child) => child.name === "storage-upright");
  expect(uprights).toHaveLength(4);
  expect(uprights.every((post) => Math.abs(post.position.x) > 1.7)).toBe(true);
  expect(rack.children.some((child) => child.rotation.z !== 0)).toBe(false);
  expect(rack.children.some((child) => child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry)).toBe(false);
  for (const locale of ["en", "ru"] as const) {
    const sprite = copy[locale].objects.items.find((item) => item.id === "storage-rack");
    expect(sprite?.pixelCrop).toMatchObject({ x: 0, y: 192, width: 134, height: 96 });
  }
});

test("storage rack game sprite shows five shelf levels", async ({ page }) => {
  await page.goto("/?lang=en");
  const rack = copy.en.objects.items.find((item) => item.id === "storage-rack")!;
  const crop = rack.pixelCrop!;
  const shelfCount = await page.evaluate(async ({ src, x, y, width, height }) => {
    const image = new Image();
    image.src = src;
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d")!;
    context.drawImage(image, x, y, width, height, 0, 0, width, height);
    const pixels = context.getImageData(0, 0, width, height).data;
    const centerX = Math.floor(width / 2);
    let count = 0;
    let start = -1;
    for (let row = 0; row <= height; row++) {
      const opaque = row < height && pixels[(row * width + centerX) * 4 + 3] > 40;
      if (opaque && start < 0) start = row;
      if (!opaque && start >= 0) {
        if (row - start >= 5 && start < height - 5) count++;
        start = -1;
      }
    }
    return count;
  }, { src: rack.pixelImage, ...crop });
  expect(shelfCount).toBe(5);
});

test("freight lift has a deeper platform and an open stair exit", () => {
  const lift = createObjectModel("freight-lift");
  const floor = lift.getObjectByName("lift-floor") as THREE.Mesh;
  const mainDeck = lift.getObjectByName("lift-deck-main") as THREE.Mesh;
  const landing = lift.getObjectByName("lift-deck-landing") as THREE.Mesh;
  expect(floor).toBeInstanceOf(THREE.Mesh);
  expect(mainDeck).toBeInstanceOf(THREE.Mesh);
  expect(landing).toBeInstanceOf(THREE.Mesh);
  const floorBounds = new THREE.Box3().setFromObject(floor);
  expect(floorBounds.max.z - floorBounds.min.z).toBeGreaterThan(2.2);
  const stairExit = new THREE.Vector3(-1.64, 2.18, -0.5);
  expect(new THREE.Box3().setFromObject(mainDeck).containsPoint(stairExit)).toBe(false);
  expect(new THREE.Box3().setFromObject(landing).containsPoint(stairExit)).toBe(false);
  expect(new THREE.Box3().setFromObject(landing).containsPoint(new THREE.Vector3(-1.64, 2.18, -1.1))).toBe(true);
  const landingBounds = new THREE.Box3().setFromObject(landing);
  const stringers = lift.children.filter((child) => child.name === "lift-stair-stringer") as THREE.Mesh[];
  expect(stringers).toHaveLength(2);
  for (const stringer of stringers) {
    stringer.geometry.computeBoundingBox();
    const halfLength = stringer.geometry.boundingBox!.max.z;
    const top = stringer.localToWorld(new THREE.Vector3(0, 0, -halfLength));
    const bottom = stringer.localToWorld(new THREE.Vector3(0, 0, halfLength));
    expect(landingBounds.containsPoint(top)).toBe(true);
    expect(bottom.y).toBeLessThan(0.2);
  }
  const handrails = lift.children.filter((child) => child.name === "lift-stair-handrail") as THREE.Mesh[];
  expect(handrails).toHaveLength(2);
  for (const rail of handrails) {
    rail.geometry.computeBoundingBox();
    const halfLength = rail.geometry.boundingBox!.max.z;
    const top = rail.localToWorld(new THREE.Vector3(0, 0, -halfLength));
    const bottom = rail.localToWorld(new THREE.Vector3(0, 0, halfLength));
    expect(top.y).toBeGreaterThan(2.75);
    expect((top.y - bottom.y) / (bottom.z - top.z)).toBeCloseTo(1);
    expect(bottom.y).toBeGreaterThan(0.55);
  }
});

test("freight lift renders clearly from the front and side", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
    await page.goto("/?lang=en#objects");
    await page.locator("#tab-freight-lift").click();
    const canvas = page.locator('[data-testid="object-canvas"]');
    await expect(canvas).toBeVisible();
    await canvas.scrollIntoViewIfNeeded();
    const front = await inspectCanvas(page);
    expect(front.visible).toBeGreaterThan(35);
    expect(front.colors).toBeGreaterThan(10);
    const frontShot = await page.locator("#objects").screenshot({ path: `qa/freight-lift-front-${width}.png` });
    const bounds = await canvas.boundingBox();
    if (!bounds) throw new Error("Freight lift canvas has no bounds");
    expect(bounds.width).toBeLessThan(width);
    const centerX = bounds.x + bounds.width / 2;
    const centerY = bounds.y + bounds.height / 2;
    expect(await page.evaluate(({ x, y }) => document.elementFromPoint(x, y)?.getAttribute("data-testid"), { x: centerX, y: centerY })).toBe("object-canvas");
    await page.mouse.move(centerX, centerY);
    await page.mouse.down();
    await page.mouse.move(centerX + bounds.width * 0.3, centerY, { steps: 12 });
    await page.mouse.up();
    await page.waitForTimeout(200);
    const sideShot = await page.locator("#objects").screenshot({ path: `qa/freight-lift-side-${width}.png` });
    const side = await inspectCanvas(page);
    expect(side.visible).toBeGreaterThan(35);
    expect(sideShot.equals(frontShot)).toBe(false);
  }
});

test("all equipment sprites and 3D models render at desktop and mobile widths", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
    await page.goto("/?lang=en#objects");
    const tabs = page.locator("#objects").getByRole("tab");
    await expect(tabs).toHaveCount(8);
    for (const id of ["pallet-jack", "sorting-table", "conveyor", "receiving-table", "receiving-gate", "storage-rack", "freight-lift", "mesh-cart"]) {
      await page.locator(`#tab-${id}`).click();
      await page.waitForTimeout(160);
      const pixels = await inspectCanvas(page);
      expect(pixels.visible, `${id} should have visible model pixels at ${width}px`).toBeGreaterThan(35);
      expect(pixels.colors, `${id} should have modeled detail at ${width}px`).toBeGreaterThan(10);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      await page.locator("#objects").screenshot({ path: `qa/equipment-${id}-${width}.png` });
    }
  }
  await page.getByRole("button", { name: "RU", exact: true }).click();
  await page.locator("#tab-storage-rack").click();
  await expect(page.locator("#object-panel")).toContainText("Стеллаж для хранения");
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator("#objects").screenshot({ path: "qa/equipment-storage-rack-ru-390.png" });
  expect(errors).toEqual([]);
});

test("receiving table details remain visible while turning on desktop and mobile", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  const model = createObjectModel("receiving-table");
  for (const name of ["receiving-worktop", "receiving-flat-cartons", "receiving-monitor", "receiving-parcel", "receiving-scanner", "receiving-mouse", "receiving-mouse-cable"]) {
    expect(model.getObjectByName(name), `${name} should be part of the intake station`).toBeTruthy();
  }
  expect(model.getObjectByName("receiving-scanner")?.scale.toArray()).toEqual([0.5, 0.5, 0.5]);
  const scanner = model.getObjectByName("receiving-scanner")!;
  expect(scanner.children.some((node) => node instanceof THREE.Mesh && node.geometry instanceof THREE.TubeGeometry)).toBe(false);
  expect(model.getObjectByName("receiving-tape-gun")).toBeUndefined();
  const totes = model.children.filter((node) => node.name === "receiving-tote");
  expect(totes).toHaveLength(2);
  for (const tote of totes) {
    expect(new THREE.Box3().setFromObject(tote).getSize(new THREE.Vector3()).y).toBeGreaterThan(0.45);
  }
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
    await page.goto("/?lang=en#objects");
    await page.locator("#tab-receiving-table").click();
    const canvas = page.locator('[data-testid="object-canvas"]');
    await expect(canvas).toBeVisible();
    await canvas.scrollIntoViewIfNeeded();
    const front = await inspectCanvas(page);
    expect(front.visible).toBeGreaterThan(35);
    await canvas.screenshot({ path: `qa/receiving-table-mouse-front-${width}.png` });
    const bounds = await canvas.boundingBox();
    if (!bounds) throw new Error("Receiving table canvas has no bounds");
    await page.mouse.move(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
    await page.mouse.down();
    await page.mouse.move(bounds.x + bounds.width * 0.8, bounds.y + bounds.height / 2, { steps: 12 });
    await page.mouse.up();
    await expect.poll(async () => (await inspectCanvas(page)).image !== front.image).toBe(true);
    expect((await inspectCanvas(page)).visible).toBeGreaterThan(35);
    await canvas.screenshot({ path: `qa/receiving-table-mouse-side-${width}.png` });
  }
});

test("every left-facing pallet-jack frame is free of neighboring frame pixels", async ({ page }) => {
  await page.goto("/?lang=en");
  const frames = await page.evaluate(async () => {
    const image = new Image();
    image.src = "/media/pallet-jack-move-left.png";
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 256;
    const context = canvas.getContext("2d")!;
    return Array.from({ length: 8 }, (_, frame) => {
      context.clearRect(0, 0, 256, 256);
      context.drawImage(image, frame * 256, 0, 256, 256, 0, 0, 256, 256);
      const pixels = context.getImageData(0, 0, 256, 256).data;
      let visible = 0, stray = 0;
      for (let i = 0; i < pixels.length; i += 4) {
        if (pixels[i + 3] < 40) continue;
        visible++;
        if ((i / 4) % 256 < 128) stray++;
      }
      return { frame, visible, stray };
    });
  });
  for (const frame of frames) {
    expect(frame.stray, `Left frame ${frame.frame} must have a transparent left gutter`).toBe(0);
    expect(frame.visible, `Left frame ${frame.frame} must preserve the character and pallet jack`).toBeGreaterThan(1500);
  }
});

async function inspectCanvas(page: Page) {
  return page.locator('[data-testid="object-canvas"]').evaluate(async (canvas: HTMLCanvasElement) => {
    const image = new Image();
    image.src = canvas.toDataURL();
    await image.decode();
    const sample = document.createElement("canvas");
    sample.width = 48;
    sample.height = 48;
    const context = sample.getContext("2d")!;
    context.drawImage(image, 0, 0, 48, 48);
    const pixels = context.getImageData(0, 0, 48, 48).data;
    let visible = 0;
    const colors = new Set<string>();
    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] < 40) continue;
      visible += 1;
      colors.add(`${pixels[i]},${pixels[i + 1]},${pixels[i + 2]}`);
    }
    return { visible, colors: colors.size, image: image.src };
  });
}

test("desktop page, language, movement and 3D models", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/?lang=en");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Department of");
  await expect(page.locator("#overview")).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(await page.locator("#overview").evaluate((element) => element.getBoundingClientRect().top)).toBeLessThan(900);
  await page.screenshot({ path: "qa/desktop-top.png" });

  await page.getByRole("button", { name: "RU" }).click();
  await expect(page.getByRole("heading", { name: "У каждой мелочи свое место." })).toBeVisible();
  await expect(page.locator("#overview")).toContainText("ПК и мобильные устройства");
  await expect(page.getByRole("heading", { name: "Анимации", exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.lang)).toBe("ru");
  await page.getByRole("button", { name: "EN", exact: true }).click();
  await expect(page.locator("#overview")).toContainText("PC and mobile devices");

  const stage = page.getByRole("application");
  await stage.scrollIntoViewIfNeeded();
  await stage.focus();
  const sprite = stage.locator("[style*=left]").first();
  const before = await sprite.getAttribute("style");
  await page.keyboard.down("ArrowRight");
  await page.waitForTimeout(260);
  await page.keyboard.up("ArrowRight");
  expect(await sprite.getAttribute("style")).not.toBe(before);
  await page.screenshot({ path: "qa/desktop-movement.png" });

  for (const [name, id] of [["On foot", "foot"], ["Transporter", "transporter"], ["Pallet jack", "pallet-jack"]]) {
    await page.locator("#movement").getByRole("tab", { name, exact: true }).click();
    await expect(page.getByTestId("movement-actor")).toHaveAttribute("data-mode", id);
    const initial = await page.getByTestId("movement-actor").getAttribute("style");
    await page.waitForTimeout(350);
    expect(await page.getByTestId("movement-actor").getAttribute("style")).not.toBe(initial);
    const pixels = await inspectMovementSprite(page);
    expect(pixels.visible).toBeGreaterThan(500);
    expect(pixels.colors).toBeGreaterThan(15);
    expect(pixels.inside).toBe(true);
    expect(pixels.width).toBe(2048);
    await page.getByRole("button", { name: "Pause animation", exact: true }).click();
    await page.waitForTimeout(100);
    const paused = await page.getByTestId("movement-actor").getAttribute("style");
    await page.waitForTimeout(160);
    expect(await page.getByTestId("movement-actor").getAttribute("style")).toBe(paused);
    await page.locator("#movement").screenshot({ path: `qa/desktop-animation-${id}.png` });
  }
  await checkGallery(page);
  await page.locator("#gallery").screenshot({ path: "qa/desktop-gallery.png" });

  await page.locator("#objects").scrollIntoViewIfNeeded();
  await expect(page.locator('[data-testid="object-canvas"]')).toBeVisible();
  await page.waitForTimeout(500);
  const first = await inspectCanvas(page);
  expect(first.visible).toBeGreaterThan(75);
  expect(first.colors).toBeGreaterThan(12);
  await page.screenshot({ path: "qa/desktop-objects.png" });
  await page.waitForTimeout(900);
  const rotated = await inspectCanvas(page);
  expect(rotated.image).not.toBe(first.image);
  await page.getByRole("tab", { name: /Sorting table/ }).click();
  await page.waitForTimeout(400);
  const second = await inspectCanvas(page);
  expect(second.visible).toBeGreaterThan(75);
  expect(second.image).not.toBe(first.image);
  await page.screenshot({ path: "qa/desktop-sorting-table.png" });
  await page.getByRole("tab", { name: /Conveyor/ }).click();
  await page.waitForTimeout(400);
  for (const label of ["Corner", "Horizontal", "Vertical"]) {
    await expect(page.locator("#objects").getByText(label, { exact: true })).toBeVisible();
  }
  const third = await inspectCanvas(page);
  expect(third.visible).toBeGreaterThan(75);
  expect(third.image).not.toBe(second.image);
  await page.screenshot({ path: "qa/desktop-conveyor.png" });
  expect(errors).toEqual([]);
});

test("mobile layout and 3D scene", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/?lang=en");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(await page.locator("#overview").evaluate((element) => element.getBoundingClientRect().top)).toBeLessThan(844);
  await page.screenshot({ path: "qa/mobile-top.png" });
  await page.getByRole("button", { name: "Open menu" }).click();
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();
  await page.getByRole("link", { name: "Equipment" }).click();
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeHidden();
  await page.locator("#objects").scrollIntoViewIfNeeded();
  await page.waitForTimeout(550);
  const pixels = await inspectCanvas(page);
  expect(pixels.visible).toBeGreaterThan(30);
  expect(pixels.colors).toBeGreaterThan(10);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: "qa/mobile-objects.png" });
  await page.locator("#objects").getByRole("tab", { name: /Conveyor/ }).click();
  await expect(page.locator("#objects").getByText("Horizontal", { exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator("#objects").screenshot({ path: "qa/mobile-conveyor.png" });

  await page.locator("#movement").scrollIntoViewIfNeeded();
  for (const [name, id] of [["On foot", "foot"], ["Transporter", "transporter"], ["Pallet jack", "pallet-jack"]]) {
    await page.locator("#movement").getByRole("tab", { name, exact: true }).click();
    await page.waitForTimeout(250);
    expect((await inspectMovementSprite(page)).inside).toBe(true);
    await page.getByRole("button", { name: "Pause animation", exact: true }).click();
    await page.locator("#movement").screenshot({ path: `qa/mobile-animation-${id}.png` });
    for (const direction of ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]) {
      await page.getByRole("application").focus();
      await page.keyboard.down(direction);
      await page.waitForTimeout(800);
      await page.keyboard.up(direction);
      expect((await inspectMovementSprite(page)).inside).toBe(true);
    }
    await page.getByRole("button", { name: "Return to start", exact: true }).click();
  }
  const actor = page.getByTestId("movement-actor");
  const initial = await actor.getAttribute("style");
  const right = page.getByRole("button", { name: "Move right", exact: true });
  const bounds = await right.boundingBox();
  await page.mouse.move(bounds!.x + 20, bounds!.y + 20);
  await page.mouse.down();
  await page.waitForTimeout(200);
  await page.mouse.up();
  expect(await actor.getAttribute("style")).not.toBe(initial);
  await checkGallery(page);
  await page.locator("#gallery").screenshot({ path: "qa/mobile-gallery.png" });
  await page.getByRole("button", { name: "RU", exact: true }).click();
  await expect(page.locator("#overview")).toContainText("ПК и мобильные устройства");
  await page.locator("#movement").scrollIntoViewIfNeeded();
  await page.locator("#movement").screenshot({ path: "qa/mobile-animation-ru.png" });
  await page.setViewportSize({ width: 360, height: 780 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(errors).toEqual([]);
});

test("reduced motion starts paused but allows explicit playback", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/?lang=en");
  await page.getByRole("application").scrollIntoViewIfNeeded();
  const actor = page.getByTestId("movement-actor");
  const initial = await actor.getAttribute("style");
  await page.waitForTimeout(250);
  expect(await actor.getAttribute("style")).toBe(initial);
  await page.getByRole("button", { name: "Play animation", exact: true }).click();
  await page.waitForTimeout(250);
  expect(await actor.getAttribute("style")).not.toBe(initial);
});
