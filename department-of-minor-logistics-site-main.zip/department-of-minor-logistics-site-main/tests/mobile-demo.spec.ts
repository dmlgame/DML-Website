import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedOrientationSave } from "./helpers/demo";

test.use({ isMobile: true, hasTouch: true, deviceScaleFactor: 2, viewport: { width: 844, height: 390 } });

async function capture(page: Page, name: string) {
  await mkdir("qa", { recursive: true });
  const pixels = await page.screenshot({ path: `qa/mobile-${name}.png`, scale: "css" });
  const stats = await sharp(pixels).stats();
  expect(Math.max(...stats.channels.slice(0, 3).map(channel => channel.stdev))).toBeGreaterThan(15);
  return pixels;
}

async function actionPixels(page: Page, left: number, top: number, secondary = false) {
  const pixels = await sharp(await page.screenshot({ scale: "css" })).extract({ left, top, width: 44, height: 44 }).removeAlpha().raw().toBuffer();
  let matching = 0;
  for (let i = 0; i < pixels.length; i += 3) {
    if (secondary ? pixels[i] < 100 && pixels[i + 1] > 160 && pixels[i + 2] < 160 : pixels[i] < 100 && pixels[i + 1] > 90 && pixels[i + 1] < 190 && pixels[i + 2] > 180) matching++;
  }
  return matching;
}

function upperHintRegion(viewport: { width: number; height: number }) {
  if (viewport.height > viewport.width) {
    return { left: 80, top: 108, width: Math.floor(mobileMapWidth(viewport)), height: 240 };
  }
  const width = viewport.width - 528;
  return viewport.width > viewport.height && width >= 200
    ? { left: 272, top: 16, width, height: 128 }
    : null;
}

function mobileMapWidth(viewport: { width: number; height: number }) {
  return viewport.height > viewport.width ? Math.min(176, (viewport.width - 108) / 2) : 176;
}

function mapImageRegion(viewport: { width: number; height: number }) {
  return { left: 88, top: 24, width: Math.floor(mobileMapWidth(viewport) - 16), height: 44 };
}

async function expectUpperHint(page: Page) {
  const region = upperHintRegion(page.viewportSize()!);
  if (!region) return;
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract(region).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let dark = 0, title = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (Math.max(data[i], data[i + 1], data[i + 2]) < 35) dark++;
    if (i / info.channels < info.width * 80 && Math.abs(data[i] - 255) < 8 && Math.abs(data[i + 1] - 104) < 8 && Math.abs(data[i + 2] - 104) < 8) title++;
  }
  expect(dark, "Interaction panel occupies the correct mobile hint area").toBeGreaterThan(1500);
  expect(title, "Interaction title is below the portrait minimap or in the landscape upper gap").toBeGreaterThan(15);
}

test("portrait cold start shows the complete objective before any rotation", async ({ page }) => {
  test.setTimeout(90000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await expect(page.locator("#fullscreen")).toBeVisible();
  await page.waitForTimeout(600);
  await expectCompleteObjective(page);
  await capture(page, "portrait-cold-start-390x844");
  for (const viewport of [{ width: 320, height: 640 }, { width: 346, height: 794 }, { width: 844, height: 390 }, { width: 390, height: 844 }]) {
    await page.setViewportSize(viewport);
    await page.waitForTimeout(250);
    await expectCompleteObjective(page);
    await capture(page, `full-objective-${viewport.width}x${viewport.height}`);
  }
  const route = await hintButtonPoint(page);
  await page.touchscreen.tap(390 - 44, route.y);
  await expect.poll(() => objectiveTitlePixels(page)).toBe(0);
  await page.touchscreen.tap(390 - 38, 38);
  await page.waitForTimeout(150);
  await expectCompleteObjective(page);
  await page.locator("#fullscreen").tap();
  await expect.poll(() => page.evaluate(() => document.fullscreenElement?.tagName)).toBe("HTML");
  await page.waitForTimeout(200);
  await expectCompleteObjective(page);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  await page.reload();
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
  await expectCompleteObjective(page);
  await capture(page, "portrait-full-objective-resumed");
  expect(errors).toEqual([]);
});

async function expectCompleteObjective(page: Page) {
  const canvas = (await page.locator("#canvas").boundingBox())!;
  const width = canvas.height > canvas.width ? mobileMapWidth(canvas) : 224;
  const route = await hintButtonPoint(page);
  const top = Math.ceil(canvas.y + 22);
  const region = { left: Math.ceil(canvas.x + canvas.width - width - 10), top, width: Math.floor(width - 12), height: Math.floor(route.y - 24 - top) };
  expect(region.height).toBeGreaterThan(30);
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract(region).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let whiteText = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (Math.abs(data[i] - 237) < 8 && Math.abs(data[i + 1] - 242) < 8 && Math.abs(data[i + 2] - 237) < 8) whiteText++;
  }
  expect(whiteText, "Expanded objective includes its white description, not only the shortened heading").toBeGreaterThan(60);
  expect(await objectiveTitlePixels(page)).toBeGreaterThan(15);
}

test("mobile objective collapses in the top-right corner while contextual explanations stay automatic", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  for (const viewport of [{ width: 390, height: 844 }, { width: 320, height: 640 }, { width: 844, height: 390 }]) {
    await page.setViewportSize(viewport);
    await seedOrientationSave(page, "meet_shift_lead", [-624, -2614]);
    await page.goto("/demo/index.html");
    await running(page);
    await page.waitForTimeout(350);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(600);
    await expectUpperHint(page);
    expect(await objectiveTitlePixels(page)).toBeGreaterThan(15);
    await expectCompleteObjective(page);
    await capture(page, `corrected-expanded-${viewport.width}x${viewport.height}`);
    const route = await hintButtonPoint(page);
    const taskWidth = viewport.height > viewport.width ? mobileMapWidth(viewport) : 224;
    const taskLeft = viewport.width - taskWidth - 16;
    await page.touchscreen.tap(taskLeft + taskWidth - 28, route.y);
    await page.waitForTimeout(150);
    // Only the objective collapses; the proximity explanation remains visible.
    await expectUpperHint(page);
    expect(await objectiveTitlePixels(page)).toBe(0);
    await capture(page, `corrected-collapsed-${viewport.width}x${viewport.height}`);
    const rotated = viewport.height > viewport.width ? { width: 844, height: 390 } : { width: 390, height: 844 };
    await page.setViewportSize(rotated);
    await page.waitForTimeout(200);
    await expectUpperHint(page);
    expect(await objectiveTitlePixels(page)).toBe(0);
    await page.touchscreen.tap(40, 40);
    await expect(page.locator("#fullscreen")).toBeHidden();
    await page.keyboard.press("Escape");
    await expect(page.locator("#fullscreen")).toBeVisible();
    await page.waitForTimeout(200);
    await expectUpperHint(page);
    expect(await objectiveTitlePixels(page)).toBe(0);
    await capture(page, `corrected-rotated-${viewport.width}x${viewport.height}`);
    await page.touchscreen.tap(rotated.width - 38, 38);
    await page.waitForTimeout(150);
    const restoredRoute = await hintButtonPoint(page);
    await expectUpperHint(page);
    expect(await objectiveTitlePixels(page)).toBeGreaterThan(15);
    await expectCompleteObjective(page);
    await capture(page, `corrected-restored-${viewport.width}x${viewport.height}`);
    // The route control still opens its regular confirmation after restoration.
    await page.touchscreen.tap(restoredRoute.x, restoredRoute.y);
    await page.waitForTimeout(150);
    const yes = await primaryDialogButton(page, 260);
    await page.touchscreen.tap(yes.x, yes.y);
    await page.waitForTimeout(150);
    await page.keyboard.press("F5");
    await expect.poll(async () => (await autosave(page))?.demo.hint_enabled).toBe(true);
    expect((await autosave(page))!.demo.stage).toBe("meet_shift_lead");
    expect((await autosave(page))!.player.position).toEqual([-624, -2614]);
  }
  expect(errors).toEqual([]);
});

async function objectiveTitlePixels(page: Page) {
  const canvas = (await page.locator("#canvas").boundingBox())!;
  const width = canvas.height > canvas.width ? mobileMapWidth(canvas) : 224;
  const region = { left: Math.ceil(canvas.x + canvas.width - width - 16), top: Math.ceil(canvas.y + 16), width: Math.floor(width), height: 90 };
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract(region).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let count = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (Math.abs(data[i] - 242) < 8 && Math.abs(data[i + 1] - 204) < 8 && Math.abs(data[i + 2] - 69) < 8) count++;
  }
  return count;
}

test("mobile fullscreen toggles from a real tap, resizes and handles unavailable browsers", async ({ page }) => {
  test.setTimeout(90000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto("/demo/index.html");
  await running(page);
  const toggle = page.locator("#fullscreen");
  await expect(toggle).toBeHidden();
  await page.waitForTimeout(400);
  await page.touchscreen.tap(420, 182);
  await expect(toggle).toBeVisible();
  await expect(toggle).toBeEnabled();
  expect(await toggle.boundingBox()).toEqual({ x: 780, y: 326, width: 48, height: 48 });
  await toggle.tap();
  await expect.poll(() => page.evaluate(() => document.fullscreenElement?.tagName)).toBe("HTML");
  await expect(toggle).toHaveAttribute("aria-pressed", "true");
  await expect(page.locator("#fullscreen-exit")).toBeVisible();
  await expect(page.locator("#fullscreen-enter")).toBeHidden();
  await capture(page, "fullscreen-landscape");
  await page.setViewportSize({ width: 390, height: 844 });
  await expect.poll(() => page.locator("#canvas").evaluate((element: HTMLCanvasElement) => [element.width, element.height])).toEqual([390, 844]);
  await capture(page, "fullscreen-portrait");
  await toggle.tap();
  await expect.poll(() => page.evaluate(() => document.fullscreenElement === null)).toBe(true);
  await expect(toggle).toHaveAttribute("aria-pressed", "false");
  await expect(page.locator("#fullscreen-enter")).toBeVisible();
  await toggle.tap();
  await expect(toggle).toHaveAttribute("aria-pressed", "true");
  await page.evaluate(() => document.exitFullscreen());
  await expect(toggle).toHaveAttribute("aria-pressed", "false");
  // A denied request must not leave a fake active state or block game input.
  await page.evaluate(() => { document.documentElement.requestFullscreen = () => Promise.reject(new TypeError("Denied")); });
  await toggle.tap();
  await expect(page.locator("#fullscreen-error")).toBeVisible();
  await expect(toggle).toHaveAttribute("aria-pressed", "false");
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  await page.addInitScript(() => { Object.defineProperty(document, "fullscreenEnabled", { value: false }); });
  await page.reload();
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await expect(toggle).toBeVisible();
  await expect(toggle).toBeDisabled();
  await expect(toggle).toHaveAttribute("title", /недоступен/);
  await expect(page.locator("#fullscreen-error")).toBeHidden();
  expect(errors).toEqual([]);
});

test("mobile demo steers, sprints with a second finger, pauses and survives rotation", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(600);
  await capture(page, "menu");
  await page.touchscreen.tap(420, 182);
  await page.waitForTimeout(1000);
  await capture(page, "landscape");
  expect(await page.locator("#canvas").evaluate((element: HTMLCanvasElement) => ({ width: element.width, height: element.height }))).toEqual({ width: 844, height: 390 });
  expect(await actionPixels(page, 705, 263)).toBeGreaterThan(1500);
  expect(await actionPixels(page, 781, 263, true)).toBeGreaterThan(1500);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  const before = (await autosave(page))!;
  const input = await page.context().newCDPSession(page);
  const steer = { x: 116, y: 310, id: 0 };
  const sprint = { x: 764, y: 220, id: 1 };
  await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [steer] });
  await page.waitForTimeout(500);
  await input.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.player.position[0]).toBeGreaterThan(before.player.position[0] + 25);
  const walked = (await autosave(page))!;
  await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [steer] });
  await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [steer, sprint] });
  await page.waitForTimeout(500);
  await input.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.player.position[0]).toBeGreaterThan(walked.player.position[0] + 50);
  const sprinted = (await autosave(page))!;
  await page.waitForTimeout(400);
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp).toBeGreaterThan(sprinted.timestamp);
  expect((await autosave(page))!.player.position).toEqual(sprinted.player.position);
  await page.touchscreen.tap(40, 40);
  await page.waitForTimeout(300);
  await capture(page, "pause");
  expect(await actionPixels(page, 705, 263)).toBeLessThan(200);
  await expect(page.locator("#fullscreen")).toBeHidden();
  await page.touchscreen.tap(420, 150);
  await page.waitForTimeout(200);
  expect(await actionPixels(page, 705, 263)).toBeGreaterThan(1500);
  await expect(page.locator("#fullscreen")).toBeVisible();
  await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [steer, sprint] });
  await input.send("Input.dispatchTouchEvent", { type: "touchCancel", touchPoints: [] });
  await page.keyboard.press("F5");
  await page.waitForTimeout(250);
  const canceled = (await autosave(page))!;
  await page.waitForTimeout(350);
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp).toBeGreaterThan(canceled.timestamp);
  expect((await autosave(page))!.player.position).toEqual(canceled.player.position);
  await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [steer] });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(300);
  await input.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await capture(page, "portrait");
  expect(await actionPixels(page, 251, 717)).toBeGreaterThan(1500);
  expect(await actionPixels(page, 327, 717, true)).toBeGreaterThan(1500);
  await page.keyboard.press("F5");
  await page.waitForTimeout(300);
  const rotated = (await autosave(page))!;
  await page.waitForTimeout(400);
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp).toBeGreaterThan(rotated.timestamp);
  expect((await autosave(page))!.player.position).toEqual(rotated.player.position);
  await input.detach();
  expect(errors).toEqual([]);
});

test("retina portrait keeps safe-area controls and hint dialogs touchable", async ({ page }) => {
  test.setTimeout(90000);
  await page.setViewportSize({ width: 390, height: 844 });
  const device = await page.context().newCDPSession(page);
  await device.send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 3, mobile: true });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.touchscreen.tap(195, 380);
  await page.waitForTimeout(700);
  expect(await page.evaluate(() => devicePixelRatio)).toBe(3);
  await page.locator("body").evaluate(element => { element.style.padding = "16px 22px 34px"; });
  await expect.poll(() => page.locator("#canvas").evaluate((element: HTMLCanvasElement) => [element.width, element.height])).toEqual([346, 794]);
  const canvas = (await page.locator("#canvas").boundingBox())!;
  expect(canvas).toEqual({ x: 22, y: 16, width: 346, height: 794 });
  await expectCompleteObjective(page);
  expect(await actionPixels(page, canvas.x + canvas.width - 139, canvas.y + canvas.height - 127)).toBeGreaterThan(1500);
  expect(await actionPixels(page, canvas.x + canvas.width - 63, canvas.y + canvas.height - 127, true)).toBeGreaterThan(1500);
  await capture(page, "safe-area-retina");
  const hint = await hintButtonPoint(page);
  await page.touchscreen.tap(hint.x, hint.y);
  await page.waitForTimeout(250);
  await capture(page, "hint-dialog");
  const yes = await primaryDialogButton(page);
  expect(yes.height).toBeGreaterThanOrEqual(42);
  expect(yes.bottom).toBeLessThan(620);
  await page.touchscreen.tap(yes.x, yes.y);
  await page.waitForTimeout(250);
  expect(await actionPixels(page, canvas.x + canvas.width - 139, canvas.y + canvas.height - 127)).toBeGreaterThan(1500);
  await capture(page, "hint-accepted");
  // Hide the route, reopen confirmation, then decline with the secondary button.
  await page.touchscreen.tap(hint.x, hint.y);
  await page.waitForTimeout(100);
  await page.touchscreen.tap(hint.x, hint.y);
  await page.waitForTimeout(200);
  const reopened = await primaryDialogButton(page);
  await page.touchscreen.tap(2 * (canvas.x + canvas.width / 2) - reopened.x, reopened.y);
  await page.waitForTimeout(200);
  expect(await actionPixels(page, canvas.x + canvas.width - 139, canvas.y + canvas.height - 127)).toBeGreaterThan(1500);
  await capture(page, "hint-declined");
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await device.detach();
});

test("orientation conversations advance by touch in portrait and landscape", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.touchscreen.tap(420, 182);
  await page.waitForTimeout(800);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  for (const viewport of [{ width: 390, height: 844 }, { width: 844, height: 390 }, { width: 812, height: 320 }]) {
    await page.setViewportSize(viewport);
    for (const conversation of [
      { stage: "meet_shift_lead", position: [-624, -2614] as [number, number], pages: 6, next: "meet_receiving_lead", name: "shift" },
      { stage: "meet_receiving_lead", position: [-561.8, -2552.2] as [number, number], pages: 8, next: "open_gate_19", name: "receiving" },
    ]) {
      await seedOrientationSave(page, conversation.stage, conversation.position);
      await page.goto("/demo/index.html");
      await running(page);
      await page.waitForTimeout(350);
      // The first menu item resumes the complete save fixture, not a debug hook.
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await page.keyboard.press("F5");
      await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(conversation.stage);
      await expectUpperHint(page);
      await capture(page, `hint-${conversation.name}-${viewport.width}x${viewport.height}`);
      await page.touchscreen.tap(viewport.width - (conversation.name === "shift" ? 118 : 42), viewport.height - 106);
      await page.waitForTimeout(250);
      expect(await actionPixels(page, viewport.width - 139, viewport.height - 127)).toBeLessThan(200);
      await expect(page.locator("#fullscreen")).toBeHidden();
      for (let index = 0; index < conversation.pages; index++) {
        const next = await primaryDialogButton(page, 521);
        expect(next.height).toBeGreaterThanOrEqual(42);
        expect(next.bottom).toBeLessThan(viewport.height - 15);
        await capture(page, `orientation-${conversation.name}-${viewport.width}x${viewport.height}-${index + 1}`);
        await page.touchscreen.tap(next.x, next.y);
        await page.waitForTimeout(120);
      }
      expect(await actionPixels(page, viewport.width - 139, viewport.height - 127)).toBeGreaterThan(1500);
      await expect(page.locator("#fullscreen")).toBeVisible();
      await page.keyboard.press("F5");
      await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(conversation.next);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    }
  }
  expect(errors).toEqual([]);
});

test("blue operates lift doors and green selects floors in both door states", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.touchscreen.tap(420, 182);
  await page.waitForTimeout(700);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  for (const viewport of [{ width: 844, height: 390 }, { width: 390, height: 844 }, { width: 812, height: 320 }]) {
    await page.setViewportSize(viewport);
    await seedOrientationSave(page, "find_director", [-64, -1627.112]);
    await page.goto("/demo/index.html");
    await running(page);
    await page.waitForTimeout(350);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(600);
    const primary = { x: viewport.width - 118, y: viewport.height - 106 };
    const secondary = { x: viewport.width - 42, y: primary.y };
    const close = { x: viewport.width / 2 + 124, y: Math.floor((viewport.height - 208) / 2) + 26 };
    await expectUpperHint(page);
    await capture(page, `lift-two-actions-${viewport.width}x${viewport.height}`);
    await page.keyboard.press("F5");
    await expect.poll(async () => (await autosave(page))?.lifts.FreightLiftGroundFloor).toBe(false);
    const { data, info } = await sharp(await page.screenshot({ scale: "css" })).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    const symbols = [0, 0];
    const upperRegion = upperHintRegion(viewport);
    const hintLeft = upperRegion?.left ?? 16;
    const hintTop = upperRegion?.top ?? 96;
    const hintRight = upperRegion ? upperRegion.left + upperRegion.width : Math.min(360, viewport.width - 16);
    const hintBottom = viewport.height <= 420 ? viewport.height - 80 : viewport.height - 208;
    for (let y = hintTop; y < hintBottom; y++) {
      for (let x = hintLeft; x < hintRight; x++) {
        const i = (y * info.width + x) * info.channels;
        if (Math.abs(data[i] - 59) < 4 && Math.abs(data[i + 1] - 140) < 4 && Math.abs(data[i + 2] - 232) < 4) symbols[0]++;
        if (Math.abs(data[i] - 55) < 4 && Math.abs(data[i + 1] - 199) < 4 && Math.abs(data[i + 2] - 121) < 4) symbols[1]++;
      }
    }
    expect(symbols[0]).toBeGreaterThan(5);
    expect(symbols[1]).toBeGreaterThan(5);
    await page.touchscreen.tap(secondary.x, secondary.y);
    await expect(page.locator("#fullscreen")).toBeHidden();
    await capture(page, `lift-floor-picker-closed-${viewport.width}x${viewport.height}`);
    const floor = await primaryDialogButton(page);
    expect(floor.height).toBeGreaterThanOrEqual(42);
    await page.touchscreen.tap(close.x, close.y);
    await expect(page.locator("#fullscreen")).toBeVisible();
    await page.keyboard.press("F5");
    expect((await autosave(page))!.lifts.FreightLiftGroundFloor).toBe(false);
    await page.touchscreen.tap(primary.x, primary.y);
    await page.waitForTimeout(500);
    await expect(page.locator("#fullscreen")).toBeVisible();
    await page.keyboard.press("F5");
    await expect.poll(async () => (await autosave(page))?.lifts.FreightLiftGroundFloor).toBe(true);
    await capture(page, `lift-open-blue-${viewport.width}x${viewport.height}`);
    await page.touchscreen.tap(secondary.x, secondary.y);
    await expect(page.locator("#fullscreen")).toBeHidden();
    await capture(page, `lift-floor-picker-open-${viewport.width}x${viewport.height}`);
    await page.touchscreen.tap(close.x, close.y);
    await expect(page.locator("#fullscreen")).toBeVisible();
    await page.keyboard.press("F5");
    expect((await autosave(page))!.lifts.FreightLiftGroundFloor).toBe(true);
    await page.touchscreen.tap(primary.x, primary.y);
    await page.waitForTimeout(500);
    await expect(page.locator("#fullscreen")).toBeVisible();
    await page.keyboard.press("F5");
    await expect.poll(async () => (await autosave(page))?.lifts.FreightLiftGroundFloor).toBe(false);
  }
  expect(errors).toEqual([]);
});

test("equipment availability hints stay readable and keep vehicles locked", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.touchscreen.tap(420, 182);
  await page.waitForTimeout(600);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  for (const viewport of [{ width: 844, height: 390 }, { width: 390, height: 844 }, { width: 812, height: 320 }]) {
    await page.setViewportSize(viewport);
    for (const vehicle of [
      { name: "pallet-jack", position: [302, -958.4] as [number, number] },
      { name: "transporter", position: [594, -1509] as [number, number] },
    ]) {
      await seedOrientationSave(page, "find_director", vehicle.position);
      await page.goto("/demo/index.html");
      await running(page);
      await page.waitForTimeout(350);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await expectUpperHint(page);
      await capture(page, `equipment-${vehicle.name}-${viewport.width}x${viewport.height}`);
      for (const offset of [118, 42]) {
        await page.touchscreen.tap(viewport.width - offset, viewport.height - 106);
        await page.keyboard.press("F5");
        await expect.poll(async () => (await autosave(page))?.player).toHaveProperty("vehicle", "");
        await expect(page.locator("#fullscreen")).toBeVisible();
      }
    }
  }
  expect(errors).toEqual([]);
});

test("mobile minimap renders the warehouse and follows the player while pinch and zoom icons scale the scene", async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.touchscreen.tap(420, 182);
  await page.waitForTimeout(600);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  const input = await page.context().newCDPSession(page);
  let firstMarker = 0;
  for (const viewport of [{ width: 844, height: 390 }, { width: 390, height: 844 }, { width: 812, height: 320 }]) {
    await page.setViewportSize(viewport);
    await seedOrientationSave(page, "find_director", [-2200, -1325]);
    await page.goto("/demo/index.html");
    await running(page);
    await page.waitForTimeout(350);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(600);
    const baseline = await avatarPixels(page);
    expect(baseline).toBeGreaterThan(50);
    const map = await sharp(await page.screenshot({ scale: "css" })).extract(mapImageRegion(viewport)).stats();
    expect(Math.max(...map.channels.slice(0, 3).map(channel => channel.stdev))).toBeGreaterThan(12);
    const marker = await mapMarkerX(page);
    expect(marker).toBeGreaterThan(88);
    expect(marker).toBeLessThan(248);
    firstMarker = marker;
    for (let step = 0; step < 3; step++) await page.touchscreen.tap(40, 102);
    await page.waitForTimeout(200);
    expect(await avatarPixels(page)).toBeGreaterThan(baseline * 1.5);
    await capture(page, `zoom-in-${viewport.width}x${viewport.height}`);
    for (let step = 0; step < 3; step++) await page.touchscreen.tap(40, 154);
    await page.waitForTimeout(200);
    expect(await avatarPixels(page)).toBeGreaterThan(baseline * 0.8);
    expect(await avatarPixels(page)).toBeLessThan(baseline * 1.2);
    const center = { x: viewport.width / 2, y: viewport.height / 2 };
    const left = { x: center.x - 60, y: center.y, id: 3 };
    const right = { x: center.x + 60, y: center.y, id: 4 };
    await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [left, right] });
    await input.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ ...left, x: center.x - 20 }, { ...right, x: center.x + 20 }] });
    await input.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
    await page.waitForTimeout(200);
    expect(await avatarPixels(page)).toBeLessThan(baseline * 0.4);
    await capture(page, `pinch-out-${viewport.width}x${viewport.height}`);
    // Pinch back in without touching the joystick or either action button.
    await input.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ ...left, x: center.x - 20 }, { ...right, x: center.x + 20 }] });
    await input.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [left, right] });
    await input.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
    await page.waitForTimeout(200);
    expect(await avatarPixels(page)).toBeGreaterThan(baseline);
    await page.keyboard.press("F5");
    await expect.poll(async () => (await autosave(page))?.player.position).toEqual([-2200, -1325]);
    expect((await autosave(page))!.demo.stage).toBe("find_director");
  }
  await page.setViewportSize({ width: 844, height: 390 });
  await seedOrientationSave(page, "find_director", [2200, -2400]);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
  expect(await mapMarkerX(page)).toBeGreaterThan(firstMarker + 40);
  await capture(page, "minimap-third-block");
  await input.detach();
  expect(errors).toEqual([]);
});

async function avatarPixels(page: Page) {
  const viewport = page.viewportSize()!;
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract({ left: Math.floor(viewport.width / 2) - 60, top: Math.floor(viewport.height / 2) - 60, width: 120, height: 120 }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let count = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    // The avatar's brown hair, excluding the gray floor and interface overlays.
    if (data[i] > 50 && data[i] < 150 && data[i + 1] < 80 && data[i + 2] < 45) count++;
  }
  return count;
}

async function mapMarkerX(page: Page) {
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract(mapImageRegion(page.viewportSize()!)).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let sum = 0, count = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (Math.abs(data[i] - 242) < 4 && Math.abs(data[i + 1] - 204) < 4 && Math.abs(data[i + 2] - 69) < 4) {
      sum += (i / info.channels) % info.width;
      count++;
    }
  }
  expect(count).toBeGreaterThan(5);
  return 88 + sum / count;
}

async function hintButtonPoint(page: Page) {
  const canvas = (await page.locator("#canvas").boundingBox())!;
  const portrait = canvas.height > canvas.width;
  const width = portrait ? mobileMapWidth(canvas) : 224;
  const left = canvas.x + canvas.width - width - 16;
  const top = canvas.y + 16;
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const rows: number[] = [];
  for (let y = Math.ceil(top); y < Math.min(info.height, top + 340); y++) {
    let matching = 0;
    for (let x = Math.ceil(left + 6); x < left + width - 6; x++) {
      const pixel = (y * info.width + x) * info.channels;
      if (Math.abs(data[pixel] - 48) < 3 && Math.abs(data[pixel + 1] - 59) < 3 && Math.abs(data[pixel + 2] - 55) < 3) matching++;
    }
    if (matching > 40) rows.push(y);
  }
  expect(rows.length).toBeGreaterThanOrEqual(35);
  return { x: left + 6 + (width - 60) / 2, y: (rows[0] + rows[rows.length - 1]) / 2 };
}

async function primaryDialogButton(page: Page, maximumWidth = 180) {
  const { width } = page.viewportSize()!;
  const pixels = await sharp(await page.screenshot({ scale: "css" })).removeAlpha().raw().toBuffer();
  const mask = new Uint8Array(pixels.length / 3);
  for (let i = 0; i < mask.length; i++) mask[i] = Number(pixels[i * 3] > 180 && pixels[i * 3 + 1] > 140 && pixels[i * 3 + 2] < 120);
  let button: { left: number; top: number; right: number; bottom: number } | undefined;
  // Find a filled yellow component; outlines and yellow heading letters are not buttons.
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i]) continue;
    const stack = [i]; mask[i] = 0;
    let left = width, top = Infinity, right = 0, bottom = 0, count = 0;
    while (stack.length) {
      const pixel = stack.pop()!;
      const x = pixel % width, y = Math.floor(pixel / width);
      left = Math.min(left, x); right = Math.max(right, x);
      top = Math.min(top, y); bottom = Math.max(bottom, y); count++;
      const neighbors = [pixel - width, pixel + width];
      if (x > 0) neighbors.push(pixel - 1);
      if (x < width - 1) neighbors.push(pixel + 1);
      for (const neighbor of neighbors) {
        if (neighbor >= 0 && neighbor < mask.length && mask[neighbor]) { mask[neighbor] = 0; stack.push(neighbor); }
      }
    }
    if (count > 1000 && count / ((right - left + 1) * (bottom - top + 1)) > 0.65) button = { left, top, right, bottom };
  }
  expect(button).toBeDefined();
  const { left, top, right, bottom } = button!;
  expect(bottom - top).toBeLessThan(60);
  expect(right - left).toBeLessThan(maximumWidth);
  return { x: (left + right) / 2, y: (top + bottom) / 2, height: bottom - top + 1, bottom };
}
