import { mkdir } from "node:fs/promises";
import { expect, test } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedDemoSave } from "./helpers/demo";

const originalCenter = [-2514, -3192];
const placedCenter = [-2322, -3292];
const comparisonPosition: [number, number] = [-2418, -3242];

async function orangeBounds(pixels: Buffer, center: number[], viewport: { width: number; height: number }, zoom: number) {
  const x = Math.round(viewport.width / 2 + (center[0] - comparisonPosition[0]) * zoom);
  const y = Math.round(viewport.height / 2 + (center[1] - comparisonPosition[1]) * zoom);
  const halfWidth = Math.ceil(32 * zoom) + 2;
  const halfHeight = Math.ceil(48 * zoom) + 2;
  const { data, info } = await sharp(pixels).extract({ left: x - halfWidth, top: y - halfHeight,
    width: halfWidth * 2, height: halfHeight * 2 }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let left = info.width, right = -1, top = info.height, bottom = -1, count = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (data[i] > 150 && data[i] > data[i + 1] * 1.25 && data[i + 1] > data[i + 2] * 1.6) {
      const px = (i / info.channels) % info.width;
      const py = Math.floor(i / info.channels / info.width);
      left = Math.min(left, px); right = Math.max(right, px);
      top = Math.min(top, py); bottom = Math.max(bottom, py);
      count++;
    }
  }
  expect(count).toBeGreaterThan(200);
  return { width: right - left + 1, height: bottom - top + 1 };
}

for (const device of [
  { name: "desktop", mobile: false, viewport: { width: 1280, height: 720 } },
  { name: "portrait", mobile: true, viewport: { width: 390, height: 844 } },
  { name: "landscape", mobile: true, viewport: { width: 844, height: 390 } },
]) {
  test.describe(device.name, () => {
    test.use({ isMobile: device.mobile, hasTouch: device.mobile, viewport: device.viewport, deviceScaleFactor: device.mobile ? 2 : 1 });
    test(`unloaded pallet matches tileset scale and remains placeable ${device.name}`, async ({ page }) => {
      test.setTimeout(120000);
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
      async function resume() {
        await page.goto("/demo/index.html");
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
      }
      async function save(stage: string) {
        const previous = (await autosave(page))?.timestamp ?? 0;
        await page.keyboard.press("F5");
        await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(previous);
        await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(stage);
        return (await autosave(page))!;
      }
      await resume();
      const initial = await save("find_director");
      const work = { completed: true, zph_assignment: true, gate17_checked: true, gate19_open: true, placed_count: 12 };
      await seedDemoSave(page, "find_stock_jack", comparisonPosition, { demo: work, gate_open: true });
      await resume();
      let zoom = 2;
      if (device.mobile) {
        for (let i = 0; i < 2; i++) {
          await page.touchscreen.tap(40, 154);
          await page.waitForTimeout(150);
          zoom /= 1.2;
        }
      }
      await mkdir("qa", { recursive: true });
      const pixels = await page.screenshot({ path: `qa/full-size-pallet-comparison-${device.name}.png`, scale: "css" });
      const original = await orangeBounds(pixels, originalCenter, device.viewport, zoom);
      const placed = await orangeBounds(pixels, placedCenter, device.viewport, zoom);
      expect(Math.abs(placed.width - original.width)).toBeLessThanOrEqual(1);
      expect(Math.abs(placed.height - original.height)).toBeLessThanOrEqual(1);
      expect((await save("find_stock_jack")).demo.placed_count).toBe(12);
      const transporter = Object.keys(initial.vehicles).find(path => path.startsWith("YSortActors/TransporterSprites/"))!;
      await seedDemoSave(page, "unload_place", [-1938, -2977], {
        demo: { ...work, placed_count: 11, assigned_vehicle: transporter }, gate_open: true,
        player: { vehicle: transporter, direction: [0, -1], pickup_offset: [10, -25] },
      });
      await resume();
      if (device.mobile) await page.touchscreen.tap(device.viewport.width - 42, device.viewport.height - 106);
      else await page.keyboard.press("e");
      await page.waitForTimeout(350);
      expect((await save("report_receiving_lead")).demo.placed_count).toBe(12);
      await page.screenshot({ path: `qa/full-size-pallet-final-placement-${device.name}.png`, scale: "css" });
      await page.reload();
      await running(page);
      await page.waitForTimeout(350);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      expect((await save("report_receiving_lead")).demo.placed_count).toBe(12);
      expect(errors).toEqual([]);
    });
  });
}
