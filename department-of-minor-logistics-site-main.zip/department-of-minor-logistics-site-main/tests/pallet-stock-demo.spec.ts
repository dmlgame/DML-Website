import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedDemoSave } from "./helpers/demo";

const work = { completed: true, zph_assignment: true, gate17_checked: true, gate19_open: true, placed_count: 12 };

async function save(page: Page, stage: string) {
  const previous = (await autosave(page))?.timestamp ?? 0;
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(previous);
  await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(stage);
  return (await autosave(page))!;
}

async function resumeFixture(page: Page, stage: string, position: [number, number], overrides: Parameters<typeof seedDemoSave>[3]) {
  await seedDemoSave(page, stage, position, overrides);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
}

async function action(page: Page, mobile: boolean, secondary = false) {
  if (mobile) {
    const viewport = page.viewportSize()!;
    await page.touchscreen.tap(viewport.width - (secondary ? 42 : 118), viewport.height - 106);
  } else {
    await page.keyboard.press(secondary ? "Enter" : "e");
  }
  await page.waitForTimeout(350);
}

async function capture(page: Page, name: string) {
  await mkdir("qa", { recursive: true });
  const image = await page.screenshot({ path: `qa/pallet-stock-${name}.png`, scale: "css" });
  const stats = await sharp(image).stats();
  expect(Math.max(...stats.channels.slice(0, 3).map(channel => channel.stdev))).toBeGreaterThan(15);
}

async function palletPixels(page: Page, player: [number, number], source: [number, number], single: boolean) {
  const viewport = page.viewportSize()!;
  const center = { x: viewport.width / 2 + (source[0] - player[0]) * 2, y: viewport.height / 2 + (source[1] - player[1]) * 2 };
  const left = Math.max(0, Math.round(center.x - 56));
  const top = Math.max(0, Math.round(center.y + (single ? 6 : -94)));
  const width = Math.min(112, viewport.width - left);
  const height = Math.min(single ? 90 : 188, viewport.height - top);
  const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract({ left, top, width, height }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let count = 0;
  for (let index = 0; index < data.length; index += info.channels) {
    if (data[index] > 140 && data[index + 1] > 90 && data[index + 1] < 220 && data[index + 2] < 140 && data[index] - data[index + 1] > 15) count++;
  }
  return count;
}

for (const device of [
  { name: "desktop", mobile: false, viewport: { width: 1280, height: 720 } },
  { name: "portrait", mobile: true, viewport: { width: 390, height: 844 } },
  { name: "landscape", mobile: true, viewport: { width: 844, height: 390 } },
]) {
  test.describe(device.name, () => {
    test.use({ isMobile: device.mobile, hasTouch: device.mobile, deviceScaleFactor: device.mobile ? 2 : 1, viewport: device.viewport });
    test(`empty pallet assignment uses stock zones, loads and delivers ${device.name}`, async ({ page }) => {
      test.setTimeout(180000);
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
      await page.goto("/demo/index.html");
      await running(page);
      await page.waitForTimeout(400);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await save(page, "find_director");
      await resumeFixture(page, "zph_complete", [-561.8, -2552.2], { demo: work, gate_open: true });
      await action(page, device.mobile);
      await capture(page, `briefing-${device.name}`);
      for (let index = 0; index < 2; index++) {
        await page.keyboard.press("Enter");
        await page.waitForTimeout(120);
      }
      const assigned = await save(page, "find_stock_jack");
      const jack = "YSortActors/PalletJackAssets/PalletJackRight16";
      expect(assigned.vehicles[jack]).toBeTruthy();
      const jackPosition = assigned.vehicles[jack];
      await resumeFixture(page, "find_stock_jack", [jackPosition[0], jackPosition[1] + 28], { demo: work, gate_open: true });
      await action(page, device.mobile, true);
      const selected = await save(page, "find_pallet_stock");
      expect(selected.player.vehicle).toBe(selected.demo.assigned_vehicle);
      expect(selected.player.vehicle).toMatch(/PalletJackAssets/);
      const mounted = { vehicle: selected.player.vehicle, direction: [0, -1], pickup_offset: [0, -28] };
      const progress = { ...work, assigned_vehicle: selected.player.vehicle };
      await resumeFixture(page, "find_pallet_stock", [2382, -1041], { demo: progress, player: mounted, gate_open: true });
      await action(page, device.mobile);
      const refused = await save(page, "find_pallet_stock");
      expect(refused.demo.pallet_source).toEqual([]);
      await capture(page, `scattered-refused-${device.name}`);
      for (const source of [
        { name: "left-stack", cell: [12, -65], world: [590, -1944], approach: [526, -1897], single: false },
        { name: "right-single", cell: [125, -38], world: [4206, -1080], approach: [4206, -1001], single: true },
      ]) {
        const position = source.approach as [number, number];
        await resumeFixture(page, "find_pallet_stock", position, { demo: progress, player: mounted, gate_open: true });
        const before = await palletPixels(page, position, source.world as [number, number], source.single);
        await capture(page, `${source.name}-before-${device.name}`);
        await action(page, device.mobile, source.single);
        const loaded = await save(page, "deliver_empty_pallet");
        expect(loaded.demo.pallet_source).toEqual(source.cell);
        expect(loaded.demo.pallet_delivered).toBe(false);
        expect(loaded.player.vehicle).toBe(selected.player.vehicle);
        const after = await palletPixels(page, position, source.world as [number, number], source.single);
        // The narrow landscape HUD overlaps part of this world-space crop.
        if (device.name !== "landscape") expect(after).toBeLessThan(before * (source.single ? 0.4 : 0.99));
        await capture(page, `${source.name}-loaded-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "deliver_empty_pallet")).demo.pallet_source).toEqual(source.cell);
        await resumeFixture(page, "deliver_empty_pallet", [-465.8, -2608.2], { demo: { ...progress, pallet_source: source.cell, pallet_delivered: false }, player: mounted, gate_open: true });
        await capture(page, `delivery-mark-${source.name}-${device.name}`);
        await action(page, device.mobile, true);
        const done = await save(page, "empty_pallet_complete");
        expect(done.demo.pallet_delivered).toBe(true);
        expect(done.demo.pallet_source).toEqual(source.cell);
        expect(done.demo.placed_count).toBe(12);
        await capture(page, `delivered-${source.name}-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "empty_pallet_complete")).demo.pallet_delivered).toBe(true);
      }
      expect(errors).toEqual([]);
    });
  });
}
