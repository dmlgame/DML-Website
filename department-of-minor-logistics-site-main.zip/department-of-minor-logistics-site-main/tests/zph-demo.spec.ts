import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedDemoSave } from "./helpers/demo";

test.use({ isMobile: true, hasTouch: true, deviceScaleFactor: 2 });

async function resumeFixture(page: Page, stage: string, position: [number, number], overrides: Parameters<typeof seedDemoSave>[3]) {
  await seedDemoSave(page, stage, position, overrides);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await expect(page.locator("#fullscreen")).toBeVisible();
  await page.waitForTimeout(500);
}

async function save(page: Page, stage: string) {
  const previous = (await autosave(page))?.timestamp ?? 0;
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(previous);
  await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(stage);
  return (await autosave(page))!;
}

async function action(page: Page, secondary = false) {
  const viewport = page.viewportSize()!;
  await page.touchscreen.tap(viewport.width - (secondary ? 42 : 118), viewport.height - 106);
  await page.waitForTimeout(350);
}

async function capture(page: Page, name: string) {
  await mkdir("qa", { recursive: true });
  const pixels = await page.screenshot({ path: `qa/zph-${name}.png`, scale: "css" });
  const stats = await sharp(pixels).stats();
  expect(Math.max(...stats.channels.slice(0, 3).map(channel => channel.stdev))).toBeGreaterThan(15);
}

for (const viewport of [{ width: 390, height: 844 }, { width: 844, height: 390 }]) {
  test(`paired ZPH assignments open gates, load cargo and report to the section lead ${viewport.width}x${viewport.height}`, async ({ page }) => {
    test.setTimeout(150000);
    const errors: string[] = [];
    page.on("pageerror", error => errors.push(error.message));
    page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
    await page.setViewportSize(viewport);
    await page.goto("/demo/index.html");
    await running(page);
    await page.waitForTimeout(400);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(600);
    await save(page, "find_director");
    const work = { completed: true, zph_assignment: true, gate17_checked: false };
    await resumeFixture(page, "open_gate_19", [-1104, -3341], { demo: work });
    await capture(page, `both-tasks-${viewport.width}`);
    await action(page);
    const inspected = await save(page, "open_gate_19");
    expect(inspected.demo.gate17_checked).toBe(true);
    expect(inspected.demo.placed_count).toBe(0);
    await capture(page, `gate17-empty-${viewport.width}`);
    await resumeFixture(page, "open_gate_19", [-2128, -3341], { demo: { ...work, gate17_checked: true }, gate_open: true });
    await action(page);
    const open = await save(page, "find_free_transporter");
    const transporter = Object.keys(open.vehicles).find(path => path.startsWith("YSortActors/TransporterSprites/"))!;
    expect(transporter).toBeTruthy();
    const transport = { ...work, gate19_open: true, gate17_checked: true, assigned_vehicle: transporter };
    const mounted = { vehicle: transporter, direction: [0, -1], pickup_offset: [10, -25] };
    await resumeFixture(page, "at_gate19_with_transporter", [-2208, -3305], { demo: transport, player: mounted, gate_open: true });
    await action(page);
    const loaded = await save(page, "unload_place");
    expect(loaded.demo.placed_count).toBe(0);
    expect(loaded.player.vehicle).toBe(transporter);
    await capture(page, `cargo-after-fade-${viewport.width}`);
    // The last real placement still cannot skip an unchecked gate seventeen.
    await resumeFixture(page, "unload_place", [-1938, -2977], { demo: { ...transport, gate17_checked: false, placed_count: 11 }, player: mounted });
    await action(page);
    const waiting = await save(page, "check_gate_17");
    expect(waiting.demo.placed_count).toBe(12);
    expect(waiting.demo.gate17_checked).toBe(false);
    await capture(page, `unloaded-awaiting-check-${viewport.width}`);
    await resumeFixture(page, "check_gate_17", [-1104, -3341], { demo: { ...transport, gate17_checked: false, placed_count: 12 } });
    await action(page, true);
    expect((await save(page, "report_receiving_lead")).demo.gate17_checked).toBe(true);
    await capture(page, `both-finished-${viewport.width}`);
    await resumeFixture(page, "report_receiving_lead", [-561.8, -2552.2], { demo: { ...transport, placed_count: 12 }, gate_open: true });
    await action(page, true);
    await expect(page.locator("#fullscreen")).toBeHidden();
    await capture(page, `section-lead-thanks-${viewport.width}`);
    for (let index = 0; index < 3; index++) {
      await page.keyboard.press("Enter");
      await page.waitForTimeout(100);
    }
    await expect(page.locator("#fullscreen")).toBeVisible();
    const done = await save(page, "find_stock_jack");
    expect(done.demo.assigned_vehicle).toBe("");
    expect(done.demo.gate17_checked).toBe(true);
    await capture(page, `complete-${viewport.width}`);
    await page.reload();
    await running(page);
    await page.waitForTimeout(350);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(500);
    expect((await save(page, "find_stock_jack")).demo.placed_count).toBe(12);
    expect(errors).toEqual([]);
  });
}
