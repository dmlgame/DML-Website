import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { copy, site } from "../src/config/site";
import { autosave, running, seedOrientationSave } from "./helpers/demo";

async function screenshot(page: Page, name: string) {
  const image = await page.screenshot({ path: `qa/online-${name}.png` });
  const { channels } = await sharp(image).stats();
  expect(Math.max(...channels.slice(0, 3).map((channel) => channel.stdev))).toBeGreaterThan(15);
  return image;
}

async function controlsPanelPixels(page: Page): Promise<number> {
  const { width, height } = page.viewportSize()!;
  // The left edge belongs only to the hint, not the narrower objective panel.
  const pixels = await sharp(await page.screenshot()).extract({ left: width - 334, top: height - 144, width: 24, height: 128 }).ensureAlpha().raw().toBuffer();
  let dark = 0;
  for (let index = 0; index < pixels.length; index += 4) {
    if (Math.max(pixels[index], pixels[index + 1], pixels[index + 2]) < 35) dark++;
  }
  return dark;
}

test("the online demo link is active and fits both languages and screen sizes", async ({ page }) => {
  await mkdir("qa", { recursive: true });
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const lang of ["ru", "en"] as const) {
    for (const width of [360, 390, 921, 960, 1024, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(`/?lang=${lang}`);
      const menu = page.getByRole("navigation", { name: "Main navigation" });
      const toggle = page.getByRole("button", { name: "Open menu" });
      if (await toggle.isVisible()) await toggle.click();
      const navigationLinks = menu.getByRole("link");
      await expect(navigationLinks).toHaveCount(5);
      await expect(navigationLinks.nth(4)).toHaveText(copy[lang].nav.demo);
      await expect(navigationLinks.nth(4)).toHaveAttribute("href", site.demoUrl);
      for (const item of await navigationLinks.all()) {
        const box = (await item.boundingBox())!;
        expect(box.x).toBeGreaterThanOrEqual(0);
        expect(box.x + box.width).toBeLessThanOrEqual(width);
      }
      const languageBounds = (await page.getByRole("button", { name: "EN", exact: true }).boundingBox())!;
      const demoBounds = (await navigationLinks.nth(4).boundingBox())!;
      if (!(await page.getByRole("button", { name: "Close menu" }).isVisible())) {
        expect(demoBounds.x + demoBounds.width).toBeLessThanOrEqual(languageBounds.x);
      }
      await page.locator("header").screenshot({ path: `qa/online-navigation-${lang}-${width}.png` });
      const close = page.getByRole("button", { name: "Close menu" });
      if (await close.isVisible()) await close.click();
      const link = page.getByRole("link", { name: copy[lang].footer.demo, exact: true });
      await link.scrollIntoViewIfNeeded();
      await expect(link).toHaveAttribute("href", site.demoUrl);
      await expect(link).not.toHaveAttribute("aria-disabled", "true");
      const bounds = await link.boundingBox();
      expect(bounds!.height).toBeGreaterThanOrEqual(44);
      expect(bounds!.x).toBeGreaterThanOrEqual(0);
      expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(width);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      expect(await page.evaluate(() => performance.getEntriesByType("resource").some((entry) => entry.name.includes("/demo/")))).toBe(false);
      await page.locator("footer").screenshot({ path: `qa/online-link-${lang}-${width}.png` });
    }
  }
});

test("the real Godot demo starts, moves, saves, reloads and exits in the browser", async ({ page }) => {
  test.setTimeout(180000);
  await mkdir("qa", { recursive: true });
  await page.setViewportSize({ width: 1280, height: 720 });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text());
  });
  await page.goto("/?lang=ru");
  await page.getByRole("link", { name: "Играть в демоверсию онлайн", exact: true }).click();
  await expect(page).toHaveURL(/\/demo\/index\.html$/);
  await running(page);
  await page.waitForTimeout(1000);
  await screenshot(page, "menu");
  await page.keyboard.press("Enter");
  await page.waitForTimeout(1500);
  await screenshot(page, "warehouse");
  for (const viewport of [{ width: 1280, height: 720 }, { width: 960, height: 540 }, { width: 390, height: 844 }, { width: 360, height: 240 }]) {
    await page.setViewportSize(viewport);
    await page.waitForTimeout(250);
    const expanded = await controlsPanelPixels(page);
    expect(expanded).toBeGreaterThan(1500);
    await screenshot(page, `controls-${viewport.width}-expanded`);
    await page.mouse.click(viewport.width - 44, viewport.height - 100);
    await expect.poll(() => controlsPanelPixels(page)).toBeLessThan(expanded * 0.4);
    await screenshot(page, `controls-${viewport.width}-collapsed`);
    await page.mouse.click(viewport.width - 92, viewport.height - 36);
    await expect.poll(() => controlsPanelPixels(page)).toBeGreaterThan(expanded * 0.9);
  }
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.waitForTimeout(250);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page), { timeout: 15000 }).not.toBeNull();
  const first = (await autosave(page))!;
  expect(first.demo.stage).toBe("find_director");
  await page.keyboard.down("ArrowRight");
  await page.waitForTimeout(600);
  await page.keyboard.up("ArrowRight");
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.player.position, { timeout: 15000 }).not.toEqual(first.player.position);
  const moved = (await autosave(page))!;
  await screenshot(page, "walking");
  await page.reload();
  await running(page);
  await page.waitForTimeout(500);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(1000);
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp, { timeout: 15000 }).toBeGreaterThan(moved.timestamp);
  expect((await autosave(page))!.player.position).toEqual(moved.player.position);
  await screenshot(page, "restored");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(300);
  await screenshot(page, "pause");
  expect(errors).toEqual([]);
  for (let index = 0; index < 4; index++) await page.keyboard.press("ArrowDown");
  await page.keyboard.press("Enter");
  await expect.poll(() => page.evaluate(() => (window as Window & { demoState?: string }).demoState)).toBe("exited");
  await expect(page.getByRole("link", { name: "На сайт" })).toBeVisible();
  // Godot 4.6.2 logs a known allocator cleanup diagnostic after Web shutdown.
  expect(errors.filter((message) => !/Pages in use exist at exit in PagedAllocator|~PagedAllocator \(\.\/core\/templates\/paged_allocator\.h:169\)/.test(message))).toEqual([]);
});

test("mezzanine announces entry briefly in the center without a permanent top-left explanation", async ({ page }) => {
  test.setTimeout(90000);
  await mkdir("qa", { recursive: true });
  await page.setViewportSize({ width: 1280, height: 720 });
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  await seedOrientationSave(page, "find_director", [-2200, -1870]);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
  const darkPixels = async (left: number, width: number, top = 16) => {
    const pixels = await sharp(await page.screenshot()).extract({ left, top, width, height: 60 }).removeAlpha().raw().toBuffer();
    let count = 0;
    for (let i = 0; i < pixels.length; i += 3) if (Math.max(pixels[i], pixels[i + 1], pixels[i + 2]) < 35) count++;
    return count;
  };
  expect(await darkPixels(460, 360)).toBeLessThan(600);
  await page.keyboard.down("ArrowDown");
  await page.waitForTimeout(300);
  await page.keyboard.up("ArrowDown");
  await expect.poll(() => darkPixels(460, 360)).toBeGreaterThan(10000);
  expect(await darkPixels(16, 300, 108)).toBeLessThan(600);
  await screenshot(page, "mezzanine-entry");
  await page.waitForTimeout(3100);
  expect(await darkPixels(460, 360)).toBeLessThan(600);
  expect(await darkPixels(16, 300, 108)).toBeLessThan(600);
  await screenshot(page, "mezzanine-standing");
  await page.waitForTimeout(500);
  expect(await darkPixels(460, 360)).toBeLessThan(600);
  expect(errors).toEqual([]);
});

test("desktop minimap renders the warehouse, tracks the player and stays clear of explanations", async ({ page }) => {
  test.setTimeout(120000);
  await mkdir("qa", { recursive: true });
  await page.setViewportSize({ width: 1280, height: 720 });
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
  const mapRegion = { left: 24, top: 24, width: 160, height: 44 };
  const mapMarker = async () => {
    const { data, info } = await sharp(await page.screenshot({ scale: "css" })).extract(mapRegion).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    let sum = 0, count = 0;
    for (let i = 0; i < data.length; i += info.channels) {
      if (Math.abs(data[i] - 242) < 4 && Math.abs(data[i + 1] - 204) < 4 && Math.abs(data[i + 2] - 69) < 4) {
        sum += (i / info.channels) % info.width;
        count++;
      }
    }
    return { pixels: count, x: count ? mapRegion.left + sum / count : 0 };
  };
  const markerX = async () => {
    const marker = await mapMarker();
    expect(marker.pixels).toBeGreaterThan(5);
    return marker.x;
  };
  const mapStats = async () => {
    const stats = await sharp(await page.screenshot({ scale: "css" })).extract(mapRegion).stats();
    return Math.max(...stats.channels.slice(0, 3).map(channel => channel.stdev));
  };
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(400);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(700);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  let firstMarker = 0;
  for (const position of [[-2200, -1325], [2200, -2400]] as [number, number][]) {
    await seedOrientationSave(page, "find_director", position);
    await page.goto("/demo/index.html");
    await running(page);
    await page.waitForTimeout(350);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(700);
    expect(await mapStats()).toBeGreaterThan(12);
    const marker = await markerX();
    expect(marker).toBeGreaterThan(24);
    expect(marker).toBeLessThan(184);
    if (!firstMarker) firstMarker = marker;
    else expect(marker).toBeGreaterThan(firstMarker + 40);
    await screenshot(page, `desktop-map-${position[0]}`);
  }
  for (const viewport of [{ width: 1280, height: 720 }, { width: 960, height: 540 }, { width: 800, height: 600 }]) {
    await page.setViewportSize(viewport);
    await page.waitForTimeout(250);
    expect(await mapStats()).toBeGreaterThan(12);
    await screenshot(page, `desktop-map-${viewport.width}`);
  }
  await page.setViewportSize({ width: 1280, height: 720 });
  await seedOrientationSave(page, "find_director", [302, -958.4]);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(700);
  expect(await mapStats()).toBeGreaterThan(12);
  const { data, info } = await sharp(await page.screenshot()).extract({ left: 16, top: 108, width: 300, height: 120 }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  let titlePixels = 0;
  for (let i = 0; i < data.length; i += info.channels) {
    if (data[i] > 180 && data[i + 1] < 140 && data[i + 2] < 140) titlePixels++;
  }
  expect(titlePixels, "Equipment explanation appears below the map").toBeGreaterThan(30);
  await screenshot(page, "desktop-map-equipment-hint");
  const beforePause = await markerX();
  await page.keyboard.press("Escape");
  await page.waitForTimeout(250);
  expect((await mapMarker()).pixels).toBe(0);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(300);
  expect(await mapStats()).toBeGreaterThan(12);
  expect(await markerX()).toBeCloseTo(beforePause, 0);
  expect(errors).toEqual([]);
});

test("a failed game download offers a retry and a way back", async ({ page }) => {
  await page.route("**/demo/index.pck", (route) => route.abort());
  await page.goto(site.demoUrl);
  await expect(page.getByRole("button", { name: "Повторить" })).toBeVisible({ timeout: 90000 });
  await expect(page.getByRole("link", { name: "На сайт" })).toBeVisible();
  await expect(page.locator("#message")).toContainText("Не удалось загрузить");
});

test("WASD moves the player with a Russian keyboard layout", async ({ page }) => {
  test.setTimeout(90000);
  await page.goto("/?lang=ru");
  await page.getByRole("navigation", { name: "Main navigation" }).getByRole("link", { name: "Демо-версия", exact: true }).click();
  await expect(page).toHaveURL(/\/demo\/index\.html$/);
  await running(page);
  await page.waitForTimeout(500);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(1000);
  await page.keyboard.press("F5");
  await expect.poll(() => autosave(page)).not.toBeNull();
  const keyboard = await page.context().newCDPSession(page);
  for (const [code, latin, russian, keyCode, axis, direction] of [
    ["KeyD", "d", "в", 68, 0, 1],
    ["KeyA", "a", "ф", 65, 0, -1],
    ["KeyS", "s", "ы", 83, 1, 1],
    ["KeyW", "w", "ц", 87, 1, -1],
  ] as const) {
    for (const key of [latin, russian]) {
      const before = (await autosave(page))!;
      await keyboard.send("Input.dispatchKeyEvent", { type: "keyDown", code, key, windowsVirtualKeyCode: keyCode });
      await page.waitForTimeout(200);
      await keyboard.send("Input.dispatchKeyEvent", { type: "keyUp", code, key, windowsVirtualKeyCode: keyCode });
      await page.keyboard.press("F5");
      await expect.poll(async () => ((await autosave(page))!.player.position[axis] - before.player.position[axis]) * direction).toBeGreaterThan(0);
    }
  }
  const stopped = (await autosave(page))!;
  await page.waitForTimeout(400);
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp).toBeGreaterThan(stopped.timestamp);
  expect((await autosave(page))!.player.position).toEqual(stopped.player.position);
  await keyboard.detach();
});
