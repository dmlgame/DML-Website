import { expect, type Page } from "@playwright/test";

export type DemoSave = { timestamp: number; player: { position: [number, number]; vehicle: string }; demo: { stage: string; hint_enabled: boolean; placed_count: number; assigned_vehicle: string; gate17_checked?: boolean; zph_assignment?: boolean; pallet_source?: [number, number] | []; pallet_delivered?: boolean; pallet_return?: [number, number] | []; tote_source?: [number, number] | []; totes_delivered?: boolean }; lifts: Record<string, boolean>; vehicles: Record<string, [number, number]> };

export async function running(page: Page) {
  await expect.poll(() => page.evaluate(() => (window as Window & { demoState?: string }).demoState), { timeout: 90000 }).toBe("running");
  await expect(page.locator("#status")).toBeHidden();
  await expect(page.locator("#canvas")).toBeVisible();
}

export async function autosave(page: Page): Promise<DemoSave | null> {
  return page.evaluate(async () => {
    for (const database of await indexedDB.databases()) {
      if (!database.name) continue;
      const db = await new Promise<IDBDatabase>((resolve, reject) => {
        const request = indexedDB.open(database.name!);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      if (!db.objectStoreNames.contains("FILE_DATA")) { db.close(); continue; }
      const store = db.transaction("FILE_DATA").objectStore("FILE_DATA");
      const keys = await new Promise<IDBValidKey[]>((resolve, reject) => {
        const request = store.getAllKeys();
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      const key = keys.find((entry) => String(entry).endsWith("/saves/autosave.json"));
      if (!key) { db.close(); continue; }
      const value = await new Promise<{ contents: Uint8Array }>((resolve, reject) => {
        const request = db.transaction("FILE_DATA").objectStore("FILE_DATA").get(key);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      db.close();
      return JSON.parse(new TextDecoder().decode(value.contents));
    }
    return null;
  });
}

export async function seedOrientationSave(page: Page, stage: string, position: [number, number]) {
  return seedDemoSave(page, stage, position);
}

export async function seedDemoSave(page: Page, stage: string, position: [number, number], overrides: { demo?: Record<string, unknown>; player?: Record<string, unknown>; gate_open?: boolean } = {}) {
  // Stop the engine before changing its IDBFS fixture so it cannot overwrite it.
  await page.goto("/");
  await page.evaluate(async ({ stage, position, overrides }) => {
    for (const database of await indexedDB.databases()) {
      if (!database.name) continue;
      const db = await new Promise<IDBDatabase>((resolve, reject) => {
        const request = indexedDB.open(database.name!);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      if (!db.objectStoreNames.contains("FILE_DATA")) { db.close(); continue; }
      const keys = await new Promise<IDBValidKey[]>((resolve, reject) => {
        const request = db.transaction("FILE_DATA").objectStore("FILE_DATA").getAllKeys();
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      const key = keys.find(entry => String(entry).endsWith("/saves/autosave.json"));
      if (!key) { db.close(); continue; }
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction("FILE_DATA", "readwrite");
        const store = transaction.objectStore("FILE_DATA");
        const request = store.get(key);
        request.onsuccess = () => {
          const file = request.result;
          const state = JSON.parse(new TextDecoder().decode(file.contents));
          state.player.position = position;
          state.player.vehicle = "";
          state.player.pickup_offset = [0, 0];
          state.demo = { ...state.demo, stage, completed: stage === "orientation_complete", hint_enabled: false, free_time_remaining: 0, gate19_open: false, assigned_vehicle: "", placed_count: 0, tote_source: [], totes_delivered: false };
          delete state.demo.zph_assignment;
          delete state.demo.gate17_checked;
          delete state.demo.pallet_source;
          delete state.demo.pallet_delivered;
          delete state.demo.pallet_return;
          Object.assign(state.demo, overrides.demo);
          Object.assign(state.player, overrides.player);
          state.gate_open = overrides.gate_open ?? false;
          state.timestamp = Date.now() / 1000;
          store.put({ ...file, timestamp: new Date(), contents: new TextEncoder().encode(JSON.stringify(state)) }, key);
        };
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error);
      });
      db.close();
      return;
    }
    throw new Error("No autosave fixture found");
  }, { stage, position, overrides });
}
