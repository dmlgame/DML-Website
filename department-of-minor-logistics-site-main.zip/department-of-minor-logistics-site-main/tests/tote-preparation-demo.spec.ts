import { mkdir } from "node:fs/promises";
import { expect, test, type Page } from "@playwright/test";
import sharp from "sharp";
import { autosave, running, seedDemoSave } from "./helpers/demo";

const jack = "YSortActors/PalletJackAssets/PalletJackRight6";
const work = { completed: true, zph_assignment: true, gate17_checked: true, gate19_open: true, placed_count: 12,
  assigned_vehicle: jack, pallet_source: [12, -65] };
const mounted = { vehicle: jack, direction: [0, -1], pickup_offset: [0, -28] };

async function save(page: Page, stage: string) {
  const previous = (await autosave(page))?.timestamp ?? 0;
  await page.keyboard.press("F5");
  await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(previous);
  await expect.poll(async () => (await autosave(page))?.demo.stage).toBe(stage);
  return (await autosave(page))!;
}

async function fixture(page: Page, stage: string, position: [number, number], overrides: Parameters<typeof seedDemoSave>[3]) {
  await seedDemoSave(page, stage, position, overrides);
  await page.goto("/demo/index.html");
  await running(page);
  await page.waitForTimeout(350);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(600);
}

async function action(page: Page, mobile: boolean, secondary = false) {
  if (mobile) {
    const viewport = page.viewportSize()!;
    await page.touchscreen.tap(viewport.width - (secondary ? 42 : 118), viewport.height - 106);
  } else await page.keyboard.press(secondary ? "Enter" : "e");
  await page.waitForTimeout(350);
}

async function nextPage(page: Page, mobile: boolean) {
  if (!mobile) await page.keyboard.press("Enter");
  else {
    const { data, info } = await sharp(await page.screenshot({ scale: "css" })).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    let x = 0, y = 0, count = 0;
    for (let i = 0; i < data.length; i += info.channels) {
      if (data[i] > 180 && data[i + 1] > 140 && data[i + 2] < 100) {
        x += (i / info.channels) % info.width;
        y += Math.floor(i / info.channels / info.width);
        count++;
      }
    }
    expect(count).toBeGreaterThan(1000);
    await page.touchscreen.tap(x / count, y / count);
  }
  await page.waitForTimeout(150);
}

async function capture(page: Page, name: string) {
  await mkdir("qa", { recursive: true });
  const stats = await sharp(await page.screenshot({ path: `qa/tote-preparation-${name}.png`, scale: "css" })).stats();
  expect(Math.max(...stats.channels.slice(0, 3).map(channel => channel.stdev))).toBeGreaterThan(15);
}

for (const device of [
  { name: "desktop", mobile: false, viewport: { width: 1280, height: 720 } },
  { name: "portrait", mobile: true, viewport: { width: 390, height: 844 } },
  { name: "landscape", mobile: true, viewport: { width: 844, height: 390 } },
]) {
  test.describe(device.name, () => {
    test.use({ isMobile: device.mobile, hasTouch: device.mobile, deviceScaleFactor: device.mobile ? 2 : 1, viewport: device.viewport });
    test(`receiving preparation retrieves the exact pallet and delivers blue totes ${device.name}`, async ({ page }) => {
      test.setTimeout(180000);
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
      await page.goto("/demo/index.html");
      await running(page);
      await page.waitForTimeout(400);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await save(page, "find_director");
      await fixture(page, "empty_pallet_complete", [-561.8, -2552.2], { demo: { ...work, pallet_delivered: true }, player: mounted, gate_open: true });
      await action(page, device.mobile);
      for (let index = 0; index < 3; index++) {
        await capture(page, `briefing-${index + 1}-${device.name}`);
        await nextPage(page, device.mobile);
      }
      const assigned = await save(page, "retrieve_empty_pallet");
      expect(assigned.demo.pallet_delivered).toBe(true);
      expect(assigned.demo.tote_source).toEqual([]);
      await fixture(page, "retrieve_empty_pallet", [-465.8, -2608.2], { demo: { ...work, pallet_delivered: true }, player: mounted, gate_open: true });
      await capture(page, `own-pallet-before-${device.name}`);
      await action(page, device.mobile, true);
      const retrieved = await save(page, "find_blue_tote_stock");
      expect(retrieved.demo.pallet_delivered).toBe(false);
      expect(retrieved.demo.pallet_source).toEqual([12, -65]);
      await capture(page, `own-pallet-retrieved-${device.name}`);
      const emptyPallet = { ...work, pallet_delivered: false };
      await fixture(page, "find_blue_tote_stock", [238, -2017], { demo: emptyPallet, player: mounted, gate_open: true });
      await action(page, device.mobile);
      expect((await save(page, "find_blue_tote_stock")).demo.tote_source).toEqual([]);
      await capture(page, `last-stack-unavailable-${device.name}`);
      for (const source of [
        { cell: [-134, -99], position: [-4082, -2977], name: "left" },
        { cell: [3, -76], position: [302, -2241], name: "right" },
      ]) {
        await fixture(page, "find_blue_tote_stock", source.position as [number, number], { demo: emptyPallet, player: { ...mounted, direction: [-1, 0] }, gate_open: true });
        await capture(page, `empty-pallet-at-${source.name}-stock-${device.name}`);
        await action(page, device.mobile);
        const loaded = await save(page, "deliver_blue_totes");
        expect(loaded.demo.tote_source).toEqual(source.cell);
        expect(loaded.demo.pallet_source).toEqual([12, -65]);
        expect(loaded.demo.pallet_delivered).toBe(false);
        await capture(page, `blue-totes-loaded-${source.name}-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "deliver_blue_totes")).demo.tote_source).toEqual(source.cell);
        await fixture(page, "deliver_blue_totes", [-1626.5, -2376], { demo: { ...emptyPallet, tote_source: source.cell, totes_delivered: false }, player: { ...mounted, direction: [-1, 0] }, gate_open: true });
        await capture(page, `table-five-mark-${source.name}-${device.name}`);
        await action(page, device.mobile, true);
        const delivered = await save(page, "return_empty_pallet");
        expect(delivered.demo.totes_delivered).toBe(true);
        expect(delivered.demo.pallet_delivered).toBe(false);
        expect(delivered.demo.pallet_source).toEqual([12, -65]);
        await capture(page, `table-five-delivered-${source.name}-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "return_empty_pallet")).demo.totes_delivered).toBe(true);
        const returnedCell = source.name === "left" ? [12, -65] : [125, -38];
        const returnPosition: [number, number] = source.name === "left" ? [670, -1929] : [4206, -1001];
        const returnWork = { ...emptyPallet, tote_source: source.cell, totes_delivered: true, pallet_return: [] };
        await fixture(page, "return_empty_pallet", returnPosition, { demo: returnWork, player: mounted, gate_open: true });
        await capture(page, `empty-pallet-return-${source.name}-${device.name}`);
        await action(page, device.mobile);
        const returned = await save(page, "report_preparation");
        expect(returned.demo.pallet_return).toEqual(returnedCell);
        expect(returned.demo.totes_delivered).toBe(true);
        await capture(page, `pallet-returned-${source.name}-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "report_preparation")).demo.pallet_return).toEqual(returnedCell);
        await fixture(page, "report_preparation", [-561.8, -2552.2], { demo: { ...returnWork, pallet_return: returnedCell }, player: mounted, gate_open: true });
        await action(page, device.mobile, true);
        await capture(page, `final-thanks-${source.name}-${device.name}`);
        await nextPage(page, device.mobile);
        await capture(page, `final-exploration-${source.name}-${device.name}`);
        await nextPage(page, device.mobile);
        const finished = await save(page, "preparation_complete");
        expect(finished.demo.pallet_return).toEqual(returnedCell);
        expect(finished.demo.hint_enabled).toBe(false);
        await capture(page, `finished-${source.name}-${device.name}`);
        await page.reload();
        await running(page);
        await page.waitForTimeout(350);
        await page.keyboard.press("Enter");
        await page.waitForTimeout(600);
        expect((await save(page, "preparation_complete")).demo.totes_delivered).toBe(true);
      }
      expect(errors).toEqual([]);
    });
  });
}
