import { expect, test } from "@playwright/test";
import { autosave, running } from "./helpers/demo";

const title = "Department of Minor Logistics | Демо-версия";

for (const device of [
  { name: "desktop", mobile: false, viewport: { width: 1280, height: 720 } },
  { name: "portrait", mobile: true, viewport: { width: 390, height: 844 } },
  { name: "landscape", mobile: true, viewport: { width: 844, height: 390 } },
]) {
  test.describe(device.name, () => {
    test.use({ isMobile: device.mobile, hasTouch: device.mobile, viewport: device.viewport, deviceScaleFactor: device.mobile ? 2 : 1 });
    test(`demo keeps its branded tab title during play and save continuation ${device.name}`, async ({ page }) => {
      test.setTimeout(120000);
      const errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => { if (message.type() === "error" || /SCRIPT ERROR|^ERROR:/.test(message.text())) errors.push(message.text()); });
      await page.goto("/?lang=ru");
      await page.getByRole("link", { name: "Играть в демоверсию онлайн", exact: true }).click();
      await expect(page).toHaveURL(/\/demo\/index\.html$/);
      await running(page);
      await expect(page).toHaveTitle(title);
      await page.waitForTimeout(500);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await expect(page).toHaveTitle(title);
      await page.keyboard.press("F5");
      await expect.poll(() => autosave(page)).not.toBeNull();
      const saved = (await autosave(page))!;
      if (device.mobile) {
        await page.locator("#fullscreen").tap();
        await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(true);
        await expect(page).toHaveTitle(title);
        await page.locator("#fullscreen").tap();
        await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(false);
      }
      await page.reload();
      await running(page);
      await expect(page).toHaveTitle(title);
      await page.waitForTimeout(350);
      await page.keyboard.press("Enter");
      await page.waitForTimeout(600);
      await page.keyboard.press("F5");
      await expect.poll(async () => (await autosave(page))?.timestamp ?? 0).toBeGreaterThan(saved.timestamp);
      expect((await autosave(page))!.player.position).toEqual(saved.player.position);
      expect((await autosave(page))!.demo.stage).toBe(saved.demo.stage);
      await expect(page).toHaveTitle(title);
      await page.keyboard.press("Escape");
      await page.waitForTimeout(250);
      await expect(page).toHaveTitle(title);
      expect(errors).toEqual([]);
      for (let i = 0; i < 4; i++) await page.keyboard.press("ArrowDown");
      await page.keyboard.press("Enter");
      await expect.poll(() => page.evaluate(() => (window as Window & { demoState?: string }).demoState)).toBe("exited");
      await expect(page).toHaveTitle(title);
      await expect(page.getByRole("link", { name: "На сайт" })).toBeVisible();
      expect(errors.filter(message => !/Pages in use exist at exit in PagedAllocator|~PagedAllocator \(\.\/core\/templates\/paged_allocator\.h:169\)/.test(message))).toEqual([]);
    });
  });
}
