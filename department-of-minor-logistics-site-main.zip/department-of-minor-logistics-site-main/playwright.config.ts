import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests",
  timeout: 45000,
  use: {
    baseURL: process.env.SITE_TEST_URL ?? "http://127.0.0.1:3005",
    browserName: "chromium",
    channel: "chrome",
    headless: true,
  },
});
