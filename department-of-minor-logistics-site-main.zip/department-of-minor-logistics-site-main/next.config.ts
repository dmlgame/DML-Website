import type { NextConfig } from "next";
import { PHASE_DEVELOPMENT_SERVER } from "next/constants";

const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
  devIndicators: false,
};

export default function config(phase: string): NextConfig {
  if (phase !== PHASE_DEVELOPMENT_SERVER) return nextConfig;
  return {
    ...nextConfig,
    headers: async () => [{
      source: "/demo/index.wasm",
      headers: [
        { key: "Content-Encoding", value: "gzip" },
        { key: "Content-Type", value: "application/wasm" },
      ],
    }],
  };
}
