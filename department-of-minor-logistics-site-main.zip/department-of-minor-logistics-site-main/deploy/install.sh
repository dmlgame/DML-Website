#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
docker compose version
if [ ! -f .env.beget ]; then
    umask 077
    secret=$(openssl rand -hex 32)
    sed "s/^OTP_SECRET=$/OTP_SECRET=$secret/" .env.beget.example > .env.beget
    unset secret
    printf '%s\n' 'Created private .env.beget; registration is disabled.'
fi
chmod 600 .env.beget
docker compose --env-file .env.beget config --quiet
docker compose --env-file .env.beget build --pull
docker compose --env-file .env.beget up -d --wait --wait-timeout 180
docker compose --env-file .env.beget ps
