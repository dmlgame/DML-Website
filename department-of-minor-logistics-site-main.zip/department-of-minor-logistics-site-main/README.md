# Department of Minor Logistics website

A promotional website built with Next.js App Router, TypeScript, CSS Modules, and Three.js. The interface is available in English and Russian. Static frontend files are served by a Cloudflare Worker. The early-access backend uses a private D1 database and transactional email codes.

## Run locally

```powershell
cd C:\Users\nikni\Documents\Codex\2026-05-25\new-chat\department-of-minor-logistics-site
npm install
npm run dev
```

Open `http://localhost:3000`. If port 3000 is occupied, run `npm run dev -- --port 3005`.

## Build and verify

```powershell
npm run lint
npm run build
npm run test:security
node scripts/preview-worker.mjs 3005
npm run test:e2e
```

`npm run build` writes frontend assets to `out/`, then packages them in `dist/client/` with the Worker in `dist/server/`. Playwright uses installed Chrome and expects a server on port 3005. Use the Worker preview to test production CSP and the Godot gzip headers; `next dev` alone has no registration API. The local Worker preview keeps mail delivery disabled. Security tests use the actual backend with isolated in-memory SQLite and a mock mail transport, never real recipients.

## Project structure

- `src/app/`: Next.js entry point, metadata, and global design tokens.
- `src/config/`: Site settings and all English/Russian page copy.
- `src/widgets/`: Page sections, each with its own component and CSS Module.
- `src/features/MovementDemo/`: Keyboard and touch controls for the game sprite.
- `src/features/ObjectViewer/`: Interactive 3D models and Three.js renderer.
- `public/media/`: Screenshots and original sprites exported from the Godot project.
- `scripts/`: Optional Godot scripts used to refresh screenshots and character animation strips.
- `tests/`: Desktop/mobile browser checks.
- `worker/`: Server-only registration, verification, mail transport and security headers.
- `db/schema.ts`, `drizzle/`: Database schema and generated, versioned migrations.

The game remains separate. No game-account registration or bonus-redemption endpoint is implemented yet. See [SECURITY.md](SECURITY.md) for mail setup, data handling and future integration boundaries.

## Beget VPS deployment

The same backend can also run on Node.js 24 with a private persistent SQLite database,
without Cloudflare bindings. `npm run package:beget` builds and tests a release archive
in `.sites-runtime/beget/`. The runtime Docker image contains only prebuilt assets,
the bundled backend, the Node adapter and migrations, not development dependencies
or secrets. Caddy terminates HTTPS; only ports 80 and 443 are published.
`npm run test:beget:browser` starts an isolated Node adapter and exercises the
demo, locales and registration UI with Playwright, without sending real mail.
See [BEGET.md](BEGET.md) for the upload, first launch, updates and backups.
The existing Site deployment is unchanged. D1 data is not automatically migrated.

## Refresh game media

Run the scripts with a Godot 4.6 executable, using the game directory for `--path`. The scripts write into this website's `public/media/` folder:

```powershell
godot --path <game-project-path> --script <this-project-path>\scripts\capture-game.gd
godot --path <game-project-path> --script <this-project-path>\scripts\export-character.gd
```

The Steam link is intentionally absent until an actual Steam page exists. Add it in `src/config/site.ts` when it is ready.

## Online demo

The footer links to `/demo/index.html`, a standalone Godot 4.6.2 Web export.
Export the game using the `Web Demo` preset into `public/demo/index.html`, then run:

```powershell
node scripts/prepare-web-demo.mjs
npm run build
```

The preparation script compresses the engine without changing the game.
`public/_headers` configures transparent gzip delivery on the static host;
the development server uses the same headers. Keep these headers when moving
the demo to another host. The export has no thread requirement, backend or
registration. Saves are device-local browser data, independent of Windows saves.

On touch devices the demo shows a left joystick, an action button, a hold-to-sprint
button (on foot only), and pause. Keyboard controls remain unchanged. Menus and
dialogs accept taps; rotating the screen or losing focus clears held controls.
The Web shell uses CSS-pixel rendering on phones to keep buttons readable on
high-density screens and reduce GPU load. It also reserves screen safe areas.
Both orientations work; landscape shows more of the warehouse. This is a minimal
browser adaptation, not a native Android/iOS export. Test performance on actual
phones before promising broad device support.

`npm run test:beget:browser` includes the real Web export in touch-enabled Chromium,
multi-touch steering/sprint, pause/resume, rotation, high-density screens and dialogs.
Re-export from the Godot source before rebuilding; editing the generated HTML
alone will be overwritten by the next export.
