CREATE TABLE `early_access_challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`first_name` text NOT NULL,
	`last_name` text NOT NULL,
	`code_hash` text NOT NULL,
	`session_hash` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`attempts` integer NOT NULL,
	`consumed_token` text,
	CONSTRAINT "early_access_attempts" CHECK("early_access_challenges"."attempts" BETWEEN 0 AND 5)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `early_access_one_challenge_per_email` ON `early_access_challenges` (`email`);--> statement-breakpoint
CREATE INDEX `early_access_challenge_expiry` ON `early_access_challenges` (`expires_at`);--> statement-breakpoint
CREATE TABLE `early_access_rate_limits` (
	`key` text NOT NULL,
	`bucket` integer NOT NULL,
	`count` integer NOT NULL,
	PRIMARY KEY(`key`, `bucket`)
);
--> statement-breakpoint
CREATE INDEX `early_access_rate_expiry` ON `early_access_rate_limits` (`bucket`);--> statement-breakpoint
CREATE TABLE `early_access_registrations` (
	`email` text PRIMARY KEY NOT NULL,
	`id` text NOT NULL,
	`first_name` text NOT NULL,
	`last_name` text NOT NULL,
	`verified_at` integer NOT NULL,
	`consent_at` integer NOT NULL,
	`consent_version` text NOT NULL,
	`bonus_status` text DEFAULT 'reserved' NOT NULL,
	`bonus_claimed_at` integer,
	CONSTRAINT "early_access_email_length" CHECK(length("early_access_registrations"."email") BETWEEN 3 AND 254),
	CONSTRAINT "early_access_bonus_status" CHECK("early_access_registrations"."bonus_status" IN ('reserved', 'claimed'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `early_access_registration_id` ON `early_access_registrations` (`id`);