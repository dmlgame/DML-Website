# Early-access registration

## Deployment and mail setup

The Site keeps its existing audience. The manifest requests a managed D1 binding named `DB`; generated Drizzle migrations create three tables. Credentials and mail configuration are runtime values, not browser variables or committed `.env` files.

Registration is intentionally disabled until a real transactional mail service is configured. The current adapter uses Resend's HTTPS API. Create a mail-provider account, verify a sender domain (including its DNS records), and configure these values using Sites environment settings:

- `OTP_SECRET`: cryptographically random server-only secret, at least 32 characters. A private secret is configured when deploying this change.
- `PUBLIC_SITE_ORIGIN`: exact production origin, without a trailing slash.
- `RESEND_API_KEY`: secret mail-provider key with only the required sending permissions.
- `EMAIL_FROM`: a verified plain sender email, such as `signup@your-domain.example`.
- `EARLY_ACCESS_ENABLED`: leave `false` until domain verification and a real delivery test succeed; then use `true` and redeploy.

Never paste keys into chat or commit them. No fake key, public mail relay, test recipient, or pretend delivery is used in production. Before enabling public collection, provide the owner's real privacy/contact details, settle the applicable data-processing requirements, and review provider costs and abuse limits. Existing private Site access does not automatically become public.

## Beget adapter

On Beget, `server/` adapts the same bundled registration backend to Node.js 24 and
SQLite. Prepared values and transactional batches retain the existing validation,
rate limits and single-confirmation behavior. Startup applies versioned migrations
atomically and refuses modified previously applied migrations. A named Docker volume
persists the database across container replacement. The database is never an asset
and is not exposed on a network port. An online SQLite backup command includes WAL
changes; copies still need protected off-server storage and a retention policy.

Only private Caddy can reach the application in the provided Compose deployment.
Caddy replaces `X-DML-Client-IP` with its direct peer address. The Node adapter strips
client-supplied edge identity headers and supplies the verified IP to the shared
backend. `TRUST_CADDY=true` must not be used with a publicly exposed application port
or an untrusted reverse proxy. Adding a CDN requires a new explicit trust review.

Runtime settings are in a private, uncommitted `.env.beget`; installation generates
the OTP secret without displaying it. Docker build contexts and release archives
exclude runtime secrets and databases. Registration is disabled by default and fails
closed without mail configuration. Beget is a public deployment, unlike the current
owner-private Site; publishing it does not enable email collection. Existing D1
records require a separate private migration if they are to be retained.

`npm run test:beget` covers the actual Node HTTP adapter, persistent database,
migration checks, batch rollback, recoverable backups, spoofed IP headers, static
path confinement, body limits, cookies and the Godot gzip headers. These local
tests do not prove VPS firewall configuration, actual TLS issuance or real mail delivery.

## Stored data

- Confirmed registrations: canonical email (primary key), UUID, first name, surname, verification time, consent time/version, `bonus_status=reserved`, and an empty claim timestamp.
- Pending confirmation: the same contact details temporarily, challenge identifier, keyed code/session hashes, expiry and remaining attempts. Codes expire after 10 minutes. Expired pending rows are removed on the next code-request cleanup; the expiry is not a promise of immediate physical deletion during inactivity.
- Rate counters: keyed hashes of the email/IP namespaces, time bucket and count. No raw IP is stored. Old counters are removed during request cleanup.

No codes, mail keys or personal details are written to application logs. Browser state holds only the currently open form and clears when it closes; it is not the registration database. Confirmed records have no automatic retention deadline until an owner policy is defined. Export/deletion is owner-only database administration, not a public API.

## Controls

- Identical strict schemas validate frontend and backend independently. Unknown fields are rejected. Names use Unicode letters/marks, spaces, hyphens and apostrophes, with bounded length; HTML and control characters are rejected. Emails use a maintained syntax validator and are verified by a code, not syntax alone.
- The entire email is trimmed and lowercased for deduplication. Provider-specific aliases, dots and `+tags` are not collapsed: different addresses can remain different registrations. A database primary key and transactional insert prevent duplicates, including races.
- All user values enter SQL through bound prepared parameters. Exactly one statement per prepare. Text is rendered by React, never as user-supplied HTML. Transactional emails are text-only.
- Crypto-secure six-digit codes are stored as HMAC-SHA256 using a private pepper. Five guesses per challenge, ten-minute lifetime, one-minute resend delay. A new challenge invalidates the previous code and browser session.
- Challenge-bound `__Host-` cookies are Secure, HttpOnly, SameSite=Strict and short-lived. Exact Origin checks reject cross-site writes; no permissive CORS is exposed. No user enumeration occurs before email ownership is proven, including existing addresses.
- Atomic rate limits: five sends per trusted edge IP per ten-minute bucket, three per email per hour, 120 total sends per hour, 30 verification requests per IP per ten minutes. Fixed-window boundaries permit bursts; these limits complement, not replace, provider/platform abuse controls. Missing trusted edge identity shares an `unknown` bucket.
- JSON-only requests, a streamed 4 KiB cap, body-read timeout and upstream-mail timeout. Failures return generic errors and never successful confirmation.
- API responses are not cached. Site HTML has a restrictive CSP with build-generated hashes for Next/Godot inline scripts, plus nosniff/referrer/permissions headers. WASM execution is explicitly allowed; arbitrary inline scripts are not.
- This is not a full account/login service. No password, public subscriber list, arbitrary email lookup or bonus-claim route exists.

## Verification

`npm run test:security` tests real prepared SQL and transaction behavior using temporary SQLite and mock mail delivery. It covers malicious inputs, code expiry/attempts/replay, session binding, resend invalidation, duplicate emails, concurrent requests, limits and provider/database failures. Browser tests cover the real unavailable state and mocked email success/error flows; they do not prove real mail delivery.

No application can be guaranteed immune to hacking. Keep dependencies patched, audit access, monitor provider usage, review production behavior before launch and maintain database backups through the hosting provider.

At implementation time, `npm audit --omit=dev` reports no known production dependency advisories after updating `source-map-js`. Full development-tool audit still reports nine inherited findings in the ESLint glob parser and Drizzle's legacy esbuild loader. Do not use those tools to process untrusted project files or expose their development servers. The proposed automatic fix downgrades major toolchains; it is intentionally not applied blindly. These development tools are not included in the Worker or client runtime.

## Future game bonus

The future game backend must independently verify account email ownership, then match the canonical confirmed Site email through a private server-to-server integration. Bonus claiming must atomically change `reserved` to `claimed`, attach the authenticated game account, and prevent retries from granting twice. Never issue a bonus merely because a browser supplies someone else's email. That integration and the bonus content are deliberately not implemented in this task.
