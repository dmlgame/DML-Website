import { useState } from "react";
import { Rotate3D } from "lucide-react";
import Image from "next/image";
import type { ObjectId, PageCopy } from "@/config/site";
import ObjectViewer from "@/features/ObjectViewer/ObjectViewer";
import styles from "./ObjectShowcase.module.css";

export default function ObjectShowcase({ content }: { content: PageCopy }) {
  const [selected, setSelected] = useState<ObjectId>("pallet-jack");
  const item = content.objects.items.find((entry) => entry.id === selected)!;

  return (
    <section id="objects" className={styles.section} aria-labelledby="objects-title">
      <div className="container">
        <div className={styles.intro}>
          <p className="eyebrow">{content.objects.eyebrow}</p>
          <h2 id="objects-title" className="section-title">{content.objects.title}</h2>
          <p>{content.objects.body}</p>
        </div>
        <div className={styles.tabs} role="tablist" aria-label={content.objects.title}>
          {content.objects.items.map((entry) => (
            <button
              key={entry.id}
              type="button"
              role="tab"
              id={`tab-${entry.id}`}
              aria-selected={selected === entry.id}
              aria-controls="object-panel"
              onClick={() => setSelected(entry.id)}
            >
              <span>{entry.number}</span>{entry.name}
            </button>
          ))}
        </div>
        <div className={styles.display} role="tabpanel" id="object-panel" aria-labelledby={`tab-${item.id}`}>
          <div className={styles.details}>
            <span className={styles.record}>DML / EQUIPMENT {item.number}</span>
            <h3>{item.name}</h3>
            <p className={styles.label}>{item.label}</p>
            <p className={styles.description}>{item.description}</p>
            <div className={styles.reference}>
              <span>{content.objects.reference}</span>
              {item.id === "conveyor" ? (
                <div className={styles.conveyorVariants}>
                  <div className={styles.variant}>
                    <Image src={item.pixelImage} alt="" width={64} height={64} />
                    <small>{content.objects.conveyorVariants.corner}</small>
                  </div>
                  <div className={styles.variant}>
                    <span className={styles.horizontalSprite} aria-hidden="true" />
                    <small>{content.objects.conveyorVariants.horizontal}</small>
                  </div>
                  <div className={styles.variant}>
                    <span className={styles.verticalSprite} aria-hidden="true">
                      <span className={styles.verticalTile} />
                      <span className={styles.verticalTile} />
                      <span className={styles.verticalTileEnd} />
                    </span>
                    <small>{content.objects.conveyorVariants.vertical}</small>
                  </div>
                </div>
              ) : item.pixelCrop ? (
                <span
                  className={styles.pixelCrop}
                  role="img"
                  aria-label={item.name}
                  style={{
                    width: item.pixelCrop.width * (item.pixelCrop.scale ?? 1),
                    height: item.pixelCrop.height * (item.pixelCrop.scale ?? 1),
                    backgroundImage: `url(${item.pixelImage})`,
                    backgroundPosition: `-${item.pixelCrop.x * (item.pixelCrop.scale ?? 1)}px -${item.pixelCrop.y * (item.pixelCrop.scale ?? 1)}px`,
                    backgroundSize: item.pixelCrop.sourceWidth ? `${item.pixelCrop.sourceWidth * (item.pixelCrop.scale ?? 1)}px auto` : undefined,
                  }}
                />
              ) : (
                <Image src={item.pixelImage} alt="" width={100} height={76} className={item.id === "freight-lift" ? styles.largeSprite : undefined} />
              )}
            </div>
          </div>
          <div className={styles.scene}>
            <ObjectViewer objectId={item.id} label={`${item.name} 3D model`} />
            <div className={styles.dragHint}><Rotate3D size={16} />{content.objects.rotate}</div>
          </div>
        </div>
      </div>
    </section>
  );
}
