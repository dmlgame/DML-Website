"use client";

import { useEffect, useState } from "react";
import { copy, type Locale } from "@/config/site";
import Header from "@/widgets/Header/Header";
import Hero from "@/widgets/Hero/Hero";
import Overview from "@/widgets/Overview/Overview";
import MovementSection from "@/widgets/MovementSection/MovementSection";
import ObjectShowcase from "@/widgets/ObjectShowcase/ObjectShowcase";
import Gallery from "@/widgets/Gallery/Gallery";
import Notice from "@/widgets/Notice/Notice";
import Footer from "@/widgets/Footer/Footer";

export default function LandingPage() {
  const [locale, setLocale] = useState<Locale>("ru");

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const currentLocale = new URLSearchParams(window.location.search).get("lang");
      const nextLocale = currentLocale === "en" ? "en" : "ru";
      setLocale(nextLocale);
      document.documentElement.lang = nextLocale;
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  function changeLocale(nextLocale: Locale) {
    setLocale(nextLocale);
    document.documentElement.lang = nextLocale;
    const url = new URL(window.location.href);
    if (nextLocale === "ru") url.searchParams.delete("lang");
    else url.searchParams.set("lang", nextLocale);
    window.history.replaceState(null, "", url);
  }

  const content = copy[locale];

  return (
    <>
      <Header locale={locale} onLocaleChange={changeLocale} content={content} />
      <main>
        <Hero content={content} />
        <Overview content={content} />
        <MovementSection content={content} />
        <ObjectShowcase content={content} />
        <Gallery content={content} />
        <Notice content={content} locale={locale} />
      </main>
      <Footer content={content} />
    </>
  );
}
