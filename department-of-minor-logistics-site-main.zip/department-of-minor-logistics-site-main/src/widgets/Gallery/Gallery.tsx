import type { PageCopy } from "@/config/site";
import { site } from "@/config/site";
import Image from "next/image";
import styles from "./Gallery.module.css";

export default function Gallery({ content }: { content: PageCopy }) {
  return (
    <section id="gallery" className={styles.section} aria-labelledby="gallery-title">
      <div className="container">
        <div className={styles.heading}>
          <p className="eyebrow">{content.gallery.eyebrow}</p>
          <h2 id="gallery-title" className="section-title">{content.gallery.title}</h2>
        </div>
        <div className={styles.grid}>
          {site.media.gallery.map((image, index) => (
            <figure key={image.src}>
              <div className={styles.frame} style={image.crop ? { aspectRatio: `${image.crop.width} / ${image.crop.height}` } : undefined}>
                <Image
                  src={image.src}
                  alt={content.gallery.captions[index]}
                  width={image.width}
                  height={image.height}
                  sizes="(max-width: 700px) calc(100vw - 36px), (max-width: 1392px) calc((100vw - 94px) / 2), 649px"
                  loading="lazy"
                  style={image.crop ? {
                    position: "absolute",
                    width: `${image.width / image.crop.width * 100}%`,
                    maxWidth: "none",
                    left: `${-image.crop.x / image.crop.width * 100}%`,
                    top: `${-image.crop.y / image.crop.height * 100}%`,
                  } : undefined}
                />
              </div>
              <figcaption><span>0{index + 1}</span>{content.gallery.captions[index]}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
