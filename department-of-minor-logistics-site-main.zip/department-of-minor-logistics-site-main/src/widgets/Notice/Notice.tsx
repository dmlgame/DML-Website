import { Clock3 } from "lucide-react";
import type { Locale, PageCopy } from "@/config/site";
import EarlyAccessButton from "./EarlyAccessButton";
import styles from "./Notice.module.css";

export default function Notice({ content, locale }: { content: PageCopy; locale: Locale }) {
  return (
    <section className={styles.section} aria-labelledby="notice-title">
      <div className={`container ${styles.inner}`}>
        <div>
          <p className="eyebrow">{content.ending.eyebrow}</p>
          <h2 id="notice-title" className="section-title">{content.ending.title}</h2>
          <p className={styles.body}>{content.ending.body}</p>
        </div>
        <div className={styles.actions}>
          <EarlyAccessButton content={content.ending} locale={locale} />
          <div className={styles.status}><Clock3 size={23} /><span>{content.ending.status}</span></div>
        </div>
      </div>
    </section>
  );
}
