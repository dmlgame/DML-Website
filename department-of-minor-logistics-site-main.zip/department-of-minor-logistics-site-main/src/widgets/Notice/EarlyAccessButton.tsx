"use client";

import { useEffect, useId, useRef, useState } from "react";
import { Gift } from "lucide-react";
import type { Locale, PageCopy } from "@/config/site";
import EarlyAccessDialog from "@/features/EarlyAccess/EarlyAccessDialog";
import styles from "./Notice.module.css";

export default function EarlyAccessButton({ content, locale }: { content: PageCopy["ending"]; locale: Locale }) {
  const [open, setOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const tooltipId = useId();
  const wrapper = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const dismissOutside = (event: PointerEvent) => {
      if (!wrapper.current?.contains(event.target as Node)) setOpen(false);
    };
    const dismissOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", dismissOutside);
    document.addEventListener("keydown", dismissOnEscape);
    return () => {
      document.removeEventListener("pointerdown", dismissOutside);
      document.removeEventListener("keydown", dismissOnEscape);
    };
  }, [open]);

  return (
    <div
      ref={wrapper}
      className={styles.accessPrompt}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => {
        if (!wrapper.current?.contains(document.activeElement)) setOpen(false);
      }}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false);
      }}
    >
      <button
        ref={trigger}
        className={styles.earlyAccess}
        type="button"
        aria-describedby={tooltipId}
        aria-haspopup="dialog"
        onFocus={() => setOpen(true)}
        onClick={() => { setOpen(false); setDialogOpen(true); }}
      >
        <Gift size={28} aria-hidden="true" />
        <span>{content.earlyAccess}</span>
        <small>{content.comingSoon}</small>
      </button>
      <p id={tooltipId} className={styles.tooltip} role="tooltip" hidden={!open || dialogOpen}>
        {content.earlyAccessDescription}
      </p>
      {dialogOpen && <EarlyAccessDialog locale={locale} onClose={() => {
        setDialogOpen(false);
        requestAnimationFrame(() => trigger.current?.focus());
      }} />}
    </div>
  );
}
