import type { PageCopy } from "@/config/site";
import MovementDemo from "@/features/MovementDemo/MovementDemo";
import styles from "./MovementSection.module.css";

export default function MovementSection({ content }: { content: PageCopy }) {
  return (
    <section id="movement" className={styles.section} aria-labelledby="movement-title">
      <div className="container">
        <div className={styles.intro}>
          <div>
            <p className="eyebrow">{content.movement.eyebrow}</p>
            <h2 id="movement-title" className="section-title">{content.movement.title}</h2>
          </div>
          <p>{content.movement.body}</p>
        </div>
        <MovementDemo content={content} />
      </div>
    </section>
  );
}
