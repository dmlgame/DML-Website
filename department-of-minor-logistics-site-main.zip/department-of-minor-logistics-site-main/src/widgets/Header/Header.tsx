import { useState } from "react";
import { Menu, X } from "lucide-react";
import { site, type Locale, type PageCopy } from "@/config/site";
import BrandLogo from "@/shared/BrandLogo/BrandLogo";
import styles from "./Header.module.css";

type Props = { locale: Locale; onLocaleChange: (locale: Locale) => void; content: PageCopy };

export default function Header({ locale, onLocaleChange, content }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const links = [
    { href: "#overview", label: content.nav.overview },
    { href: "#movement", label: content.nav.movement },
    { href: "#objects", label: content.nav.objects },
    { href: "#gallery", label: content.nav.gallery },
    { href: site.demoUrl, label: content.nav.demo },
  ];

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <a className={styles.brand} href="#top" aria-label={site.title}>
          <BrandLogo className={styles.brandLogo} decorative />
        </a>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ""}`} aria-label="Main navigation">
          {links.map((link) => <a href={link.href} key={link.href} onClick={() => setMenuOpen(false)}>{link.label}</a>)}
        </nav>
        <div className={styles.actions}>
          <div className={styles.languages} aria-label="Language">
            <button type="button" aria-pressed={locale === "ru"} onClick={() => onLocaleChange("ru")}>RU</button>
            <button type="button" aria-pressed={locale === "en"} onClick={() => onLocaleChange("en")}>EN</button>
          </div>
          <button className={styles.menuButton} type="button" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>
        </div>
      </div>
    </header>
  );
}
