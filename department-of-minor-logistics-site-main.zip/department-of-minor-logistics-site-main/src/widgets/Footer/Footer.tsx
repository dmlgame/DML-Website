import { ArrowUp, Gamepad2 } from "lucide-react";
import { site, type PageCopy } from "@/config/site";
import BrandLogo from "@/shared/BrandLogo/BrandLogo";
import styles from "./Footer.module.css";

export default function Footer({ content }: { content: PageCopy }) {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}><BrandLogo variant="symbol" className={styles.brandLogo} decorative /><strong>{site.title}</strong></div>
        <p>{content.footer.development}</p>
        <div className={styles.actions}>
          <a className={styles.demo} href={site.demoUrl}>
            <Gamepad2 size={21} aria-hidden="true" />
            <span>{content.footer.demo}</span>
          </a>
          <a className={styles.backToTop} href="#top" title={content.footer.backToTop} aria-label={content.footer.backToTop}><ArrowUp size={20} /></a>
        </div>
      </div>
    </footer>
  );
}
