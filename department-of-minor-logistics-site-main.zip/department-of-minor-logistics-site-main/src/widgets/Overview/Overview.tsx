import type { PageCopy } from "@/config/site";
import styles from "./Overview.module.css";

export default function Overview({ content }: { content: PageCopy }) {
  return (
    <section id="overview" className={styles.section} aria-labelledby="overview-title">
      <div className={`container ${styles.inner}`}>
        <div className={styles.heading}>
          <p className="eyebrow">{content.overview.eyebrow}</p>
          <h2 id="overview-title" className="section-title">{content.overview.title}</h2>
        </div>
        <div className={styles.description}>
          <p className={styles.lead}>{content.overview.lead}</p>
          <p className={styles.body}>{content.overview.body}</p>
        </div>
        <dl className={styles.facts}>
          {content.overview.facts.map((fact, index) => (
            <div key={fact.label}>
              <span className={styles.number}>0{index + 1}</span>
              <dt>{fact.label}</dt>
              <dd>{fact.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
