import type { CSSProperties } from "react";
import { site } from "@/config/site";
import type { PageCopy } from "@/config/site";
import BrandLogo from "@/shared/BrandLogo/BrandLogo";
import styles from "./Hero.module.css";

export default function Hero({ content }: { content: PageCopy }) {
  return (
    <section id="top" className={styles.hero} aria-labelledby="hero-title" style={{ "--hero-image": `url(${site.media.hero})`, "--hero-mobile-image": `url(${site.media.heroMobile})` } as CSSProperties}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.copy}>
          <p className={`eyebrow ${styles.eyebrow}`}><span className={styles.dot} />{content.hero.eyebrow}</p>
          <BrandLogo tone="light" heading className={styles.heroLogo} decorative />
          <p className={styles.lead}>{content.hero.lead}</p>
        </div>
        <div className={styles.bottom}>
          <span>{content.hero.scroll}</span>
          <span>FORM DML-001 / WAREHOUSE VIEW</span>
        </div>
      </div>
    </section>
  );
}
