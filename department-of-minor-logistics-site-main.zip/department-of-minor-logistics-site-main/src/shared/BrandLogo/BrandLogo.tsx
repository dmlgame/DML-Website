import Image from "next/image";
import { site } from "@/config/site";
import styles from "./BrandLogo.module.css";

type Props = {
  variant?: "full" | "symbol";
  tone?: "dark" | "light";
  heading?: boolean;
  className?: string;
  decorative?: boolean;
};

export default function BrandLogo({ variant = "full", tone = "dark", heading = false, className = "", decorative = false }: Props) {
  const logo = site.media.logo;
  const title = <><span>Department of</span><span>Minor Logistics</span></>;

  return (
    <div
      className={`${styles.logo} ${tone === "light" ? styles.light : ""} ${className}`}
      data-brand-logo={variant}
    >
      <span className={styles.mark} style={{ aspectRatio: `${logo.width} / ${logo.symbolHeight}` }} data-brand-mark>
        <Image src={logo.src} width={logo.width} height={logo.height} alt={decorative ? "" : site.title} loading="eager" />
        <svg className={styles.details} viewBox={`0 0 ${logo.width} ${logo.symbolHeight}`} aria-hidden="true" focusable="false">
          <rect data-brand-belt x="48" y="524" width="1576" height="68" rx="34" fill="#050505" />
          {[207, 621, 1042, 1462].map((x) => (
            <circle data-brand-wheel key={x} cx={x} cy="605" r="38" fill="none" stroke="#050505" strokeWidth="32" />
          ))}
          <rect data-brand-parcel x="1446" y="355" width="177" height="165" rx="15" fill="#f3c849" stroke="#050505" strokeWidth="16" />
          <path d="M1516 355h35v73h-35z" fill="#202729" />
        </svg>
      </span>
      {variant === "full" && (heading
        ? <h1 id="hero-title" className={styles.title} data-brand-title>{title}</h1>
        : <span className={styles.title} data-brand-title>{title}</span>)}
    </div>
  );
}
