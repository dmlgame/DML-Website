import { z } from "zod";
import isEmail from "validator/lib/isEmail";

const personName = z.string().max(120).transform(value => value.trim().normalize("NFC"))
  .pipe(z.string().min(1).max(80).regex(/^[\p{L}\p{M}][\p{L}\p{M} '\u2019-]*$/u));

export const emailAddress = z.string().max(254).transform(value => value.trim().toLowerCase())
  .refine(value => isEmail(value, { allow_display_name: false, allow_utf8_local_part: false, require_tld: true }));

export const registrationInput = z.strictObject({
  firstName: personName,
  lastName: personName,
  email: emailAddress,
  consent: z.literal(true),
  locale: z.enum(["ru", "en"]),
});

export const verificationInput = z.strictObject({
  challengeId: z.string().regex(/^[a-f0-9]{32}$/),
  code: z.string().regex(/^[0-9]{6}$/),
});

export type RegistrationInput = z.infer<typeof registrationInput>;
