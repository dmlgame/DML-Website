import type { Locale } from "@/config/site";

export const earlyAccessCopy: Record<Locale, {
  title: string; verifyTitle: string; firstName: string; lastName: string; email: string;
  code: string; send: string; verify: string; sending: string; checking: string;
  consent: string; description: string; unavailable: string; retry: string; close: string;
  changeEmail: string; resend: string; sent: string; success: string; already: string;
  bonus: string; invalidName: string; invalidEmail: string; invalidConsent: string;
  invalidCode: string; tooMany: string; invalidInput: string;
}> = {
  ru: {
    title: "Ранний доступ", verifyTitle: "Подтверждение почты",
    firstName: "Имя", lastName: "Фамилия", email: "Почта", code: "Код из письма",
    send: "Получить код", verify: "Подтвердить почту", sending: "Отправляем код…", checking: "Проверяем…",
    consent: "Согласен на сохранение имени, фамилии и почты для раннего доступа и будущего приветственного бонуса DML.",
    description: "Запишитесь на ранний доступ. Подтверждённую почту можно будет использовать для приветственного бонуса при регистрации в игре.",
    unavailable: "Запись пока готовится. Отправка кодов временно недоступна.",
    retry: "Проверить ещё раз", close: "Закрыть", changeEmail: "Изменить данные",
    resend: "Отправить код ещё раз", sent: "Введите шестизначный код, отправленный на",
    success: "Почта подтверждена. Вы в списке раннего доступа.",
    already: "Эта почта уже подтверждена. Повторная регистрация не нужна.",
    bonus: "При регистрации в игре используйте эту же почту. Состав приветственного бонуса объявим позже.",
    invalidName: "Введите имя буквами. Можно использовать пробел, дефис и апостроф.",
    invalidEmail: "Введите почту в формате name@example.com.",
    invalidConsent: "Для записи необходимо согласие на сохранение данных.",
    invalidCode: "Код неверный, истёк или исчерпаны попытки. Проверьте письмо или запросите новый код.",
    tooMany: "Слишком много попыток. Подождите и попробуйте снова.", invalidInput: "Проверьте введённые данные.",
  },
  en: {
    title: "Early access", verifyTitle: "Confirm your email",
    firstName: "First name", lastName: "Last name", email: "Email", code: "Email code",
    send: "Send code", verify: "Confirm email", sending: "Sending code…", checking: "Checking…",
    consent: "I agree to storing my name and email for DML early access and a future welcome bonus.",
    description: "Join early access. Your confirmed email can be used for a welcome bonus when you register in the game.",
    unavailable: "Sign-ups are being prepared. Email code delivery is temporarily unavailable.",
    retry: "Check again", close: "Close", changeEmail: "Change details", resend: "Resend code",
    sent: "Enter the six-digit code sent to", success: "Email confirmed. You are on the early access list.",
    already: "This email is already confirmed. You do not need to sign up again.",
    bonus: "Use the same email when registering in the game. Welcome bonus details will be announced later.",
    invalidName: "Use letters, spaces, hyphens or apostrophes.", invalidEmail: "Enter an email such as name@example.com.",
    invalidConsent: "Please agree to storing your details to join early access.",
    invalidCode: "The code is incorrect, expired or has no attempts left. Check your email or request a new code.",
    tooMany: "Too many attempts. Please wait and try again.", invalidInput: "Please check your details.",
  },
};
