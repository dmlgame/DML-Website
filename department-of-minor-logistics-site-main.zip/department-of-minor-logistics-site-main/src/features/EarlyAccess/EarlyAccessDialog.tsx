"use client";

import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { CheckCircle2, Gift, LoaderCircle, Mail, RefreshCw, X } from "lucide-react";
import type { Locale } from "@/config/site";
import { earlyAccessCopy } from "./copy";
import { registrationInput, verificationInput } from "./validation";
import styles from "./EarlyAccessDialog.module.css";

type Availability = "loading" | "ready" | "unavailable";
type Challenge = { challengeId: string; expiresIn: number; resendAfter: number };

export default function EarlyAccessDialog({ locale, onClose }: { locale: Locale; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const formId = useId();
  const codeInput = useRef<HTMLInputElement>(null);
  const [availability, setAvailability] = useState<Availability>("loading");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);
  const [code, setCode] = useState("");
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [confirmed, setConfirmed] = useState<"confirmed" | "already_confirmed" | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<string[]>([]);
  const [remaining, setRemaining] = useState(0);
  const resendAt = useRef(0);
  const c = earlyAccessCopy[locale];

  useEffect(() => {
    const element = dialog.current;
    element?.showModal();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; element?.close(); };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/early-access/status", { cache: "no-store", signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]) })
      .then(async response => response.ok && (await response.json()).available === true)
      .then(available => setAvailability(available ? "ready" : "unavailable"))
      .catch(() => { if (!controller.signal.aborted) setAvailability("unavailable"); });
    return () => controller.abort();
  }, []);

  useEffect(() => { if (challenge) codeInput.current?.focus(); }, [challenge]);
  useEffect(() => {
    if (!challenge) return;
    const timer = window.setInterval(() => setRemaining(Math.max(0, Math.ceil((resendAt.current - Date.now()) / 1000))), 1000);
    return () => window.clearInterval(timer);
  }, [challenge]);

  async function retryAvailability() {
    setAvailability("loading");
    try {
      const response = await fetch("/api/early-access/status", { cache: "no-store", signal: AbortSignal.timeout(15000) });
      setAvailability(response.ok && (await response.json()).available === true ? "ready" : "unavailable");
    } catch { setAvailability("unavailable"); }
  }

  function serverError(value: string) {
    return value === "invalid_code" ? c.invalidCode : value === "too_many_requests" ? c.tooMany
      : value === "invalid_input" ? c.invalidInput : c.unavailable;
  }

  async function send(event?: FormEvent) {
    event?.preventDefault();
    setError("");
    const parsed = registrationInput.safeParse({ firstName, lastName, email, consent, locale });
    if (!parsed.success) {
      setFields([...new Set(parsed.error.issues.map(issue => String(issue.path[0])))]);
      return;
    }
    setFields([]);
    setBusy(true);
    try {
      const response = await fetch("/api/early-access/request", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
        signal: AbortSignal.timeout(20000),
      });
      const result = await response.json();
      if (!response.ok) {
        setError(serverError(result.error));
        if (result.error === "unavailable") setAvailability("unavailable");
        if (Array.isArray(result.fields)) setFields(result.fields.filter((field: string) => ["firstName", "lastName", "email", "consent"].includes(field)));
        const retryAfter = Number(response.headers.get("Retry-After"));
        if (retryAfter > 0 && challenge) { resendAt.current = Date.now() + retryAfter * 1000; setRemaining(retryAfter); }
        return;
      }
      if (!/^[a-f0-9]{32}$/.test(result.challengeId) || !Number.isFinite(result.resendAfter)
        || result.resendAfter < 0 || result.resendAfter > 3600) throw new Error("Unexpected response");
      setEmail(parsed.data.email);
      setCode("");
      resendAt.current = Date.now() + result.resendAfter * 1000;
      setRemaining(result.resendAfter);
      setChallenge(result);
    } catch { setError(c.unavailable); }
    finally { setBusy(false); }
  }

  async function verify(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (!challenge || !verificationInput.safeParse({ challengeId: challenge.challengeId, code }).success) {
      setError(c.invalidCode); return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/early-access/verify", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ challengeId: challenge.challengeId, code }),
        signal: AbortSignal.timeout(20000),
      });
      const result = await response.json();
      if (!response.ok) { setError(serverError(result.error)); return; }
      if (!["confirmed", "already_confirmed"].includes(result.status)) throw new Error("Unexpected response");
      setConfirmed(result.status);
      setCode("");
    } catch { setError(c.unavailable); }
    finally { setBusy(false); }
  }

  return (
    <dialog ref={dialog} className={styles.dialog} aria-labelledby={titleId} onCancel={onClose}
      onKeyDown={event => {
        if (event.key !== "Tab") return;
        const elements = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]'));
        const first = elements[0];
        const last = elements.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }}
      onClick={event => { if (event.target === dialog.current && !busy) onClose(); }}>
      <div className={styles.heading}>
        <h2 id={titleId}><Gift size={26} aria-hidden="true" /><span>{challenge && !confirmed ? c.verifyTitle : c.title}</span></h2>
        <button type="button" className={styles.close} onClick={onClose} aria-label={c.close} title={c.close}><X size={22} /></button>
      </div>
      {confirmed ? (
        <div className={styles.success} role="status">
          <CheckCircle2 size={38} aria-hidden="true" /><h3>{confirmed === "confirmed" ? c.success : c.already}</h3>
          <p>{c.bonus}</p><button type="button" className={styles.primary} onClick={onClose}>{c.close}</button>
        </div>
      ) : (
        <>
          {availability === "unavailable" && <div className={styles.unavailable} role="status">
            <p>{c.unavailable}</p><button type="button" className={styles.secondary} onClick={retryAvailability}><RefreshCw size={18} />{c.retry}</button>
          </div>}
          {challenge ? (
            <form onSubmit={verify} noValidate aria-busy={busy}>
              <p className={styles.description}>{c.sent} <strong className={styles.email}>{email}</strong>. {locale === "ru" ? "Код действует 10 минут." : "The code expires in 10 minutes."}</p>
              <label className={styles.label} htmlFor={`${formId}-code`}>{c.code}</label>
              <input ref={codeInput} id={`${formId}-code`} name="code" className={styles.code} value={code}
                onChange={event => setCode(event.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                type="text" inputMode="numeric" autoComplete="one-time-code" maxLength={6} required
                aria-invalid={!!error} aria-describedby={error ? `${formId}-error` : undefined} />
              {error && <p id={`${formId}-error`} role="alert" className={styles.error}>{error}</p>}
              <button className={styles.primary} type="submit" disabled={busy || code.length !== 6}>
                {busy ? <LoaderCircle size={20} className={styles.spin} /> : <CheckCircle2 size={20} />}{busy ? c.checking : c.verify}
              </button>
              <div className={styles.bottom}>
                <button type="button" className={styles.secondary} onClick={() => void send()} disabled={busy || remaining > 0 || availability !== "ready"}>
                  <RefreshCw size={17} />{c.resend}{remaining > 0 ? ` (${remaining})` : ""}
                </button>
                <button type="button" className={styles.secondary} disabled={busy} onClick={() => { setChallenge(null); setCode(""); setError(""); }}>{c.changeEmail}</button>
              </div>
            </form>
          ) : (
            <form onSubmit={send} noValidate aria-busy={busy}>
              <p className={styles.description}>{c.description}</p>
              <div className={styles.names}>
                {(["firstName", "lastName"] as const).map(field => <div key={field}>
                  <label className={styles.label} htmlFor={`${formId}-${field}`}>{c[field]}</label>
                  <input id={`${formId}-${field}`} name={field} value={field === "firstName" ? firstName : lastName}
                    onChange={event => (field === "firstName" ? setFirstName : setLastName)(event.target.value)}
                    type="text" autoComplete={field === "firstName" ? "given-name" : "family-name"} maxLength={80} required
                    aria-invalid={fields.includes(field)} aria-describedby={fields.includes(field) ? `${formId}-${field}-error` : undefined} />
                  {fields.includes(field) && <p id={`${formId}-${field}-error`} className={styles.error}>{c.invalidName}</p>}
                </div>)}
              </div>
              <label className={styles.label} htmlFor={`${formId}-email`}>{c.email}</label>
              <input id={`${formId}-email`} name="email" value={email} onChange={event => setEmail(event.target.value)}
                type="email" autoComplete="email" maxLength={254} required aria-invalid={fields.includes("email")}
                aria-describedby={fields.includes("email") ? `${formId}-email-error` : undefined} />
              {fields.includes("email") && <p id={`${formId}-email-error`} className={styles.error}>{c.invalidEmail}</p>}
              <label className={styles.consent}>
                <input name="consent" type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} required aria-invalid={fields.includes("consent")} />
                <span>{c.consent}</span>
              </label>
              {fields.includes("consent") && <p className={styles.error}>{c.invalidConsent}</p>}
              {error && <p role="alert" className={styles.error}>{error}</p>}
              <button className={styles.primary} type="submit" disabled={busy || availability !== "ready"}>
                {busy || availability === "loading" ? <LoaderCircle size={20} className={styles.spin} /> : <Mail size={20} />}
                {busy ? c.sending : c.send}
              </button>
            </form>
          )}
        </>
      )}
    </dialog>
  );
}
