import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import type { ObjectId } from "@/config/site";

const red = new THREE.MeshStandardMaterial({ color: 0xc73e35, metalness: 0.45, roughness: 0.35 });
const redDark = new THREE.MeshStandardMaterial({ color: 0x8e2726, metalness: 0.5, roughness: 0.4 });
const blue = new THREE.MeshStandardMaterial({ color: 0x146390, metalness: 0.55, roughness: 0.4 });
const steel = new THREE.MeshStandardMaterial({ color: 0xb9c5c7, metalness: 0.75, roughness: 0.3 });
const darkSteel = new THREE.MeshStandardMaterial({ color: 0x303a3e, metalness: 0.68, roughness: 0.35 });
const belt = new THREE.MeshStandardMaterial({ color: 0x252c2e, metalness: 0.08, roughness: 0.82 });
const rubber = new THREE.MeshStandardMaterial({ color: 0x151a1c, roughness: 0.85 });
const cardboard = new THREE.MeshStandardMaterial({ color: 0xc6965b, roughness: 0.9 });
const cardboardEdge = new THREE.MeshStandardMaterial({ color: 0xa77743, roughness: 0.94 });
const screen = new THREE.MeshStandardMaterial({ color: 0x077bd0, metalness: 0.1, roughness: 0.3, emissive: 0x063759 });
const caution = new THREE.MeshStandardMaterial({ color: 0xf0bf2f, metalness: 0.15, roughness: 0.6 });
const paleSteel = new THREE.MeshStandardMaterial({ color: 0xd2dadd, metalness: 0.55, roughness: 0.4 });
const rackSteel = new THREE.MeshStandardMaterial({ color: 0xe1e6e5, metalness: 0.55, roughness: 0.44 });
const rackShade = new THREE.MeshStandardMaterial({ color: 0x919b9f, metalness: 0.55, roughness: 0.5 });
const worktop = new THREE.MeshStandardMaterial({ color: 0xe9ece9, metalness: 0.12, roughness: 0.52 });
const packingPaper = new THREE.MeshStandardMaterial({ color: 0xf6f5ee, roughness: 0.9 });
const toteRib = new THREE.MeshStandardMaterial({ color: 0x0e4a73, metalness: 0.08, roughness: 0.65 });

function box(parent: THREE.Group, material: THREE.Material, size: [number, number, number], position: [number, number, number], radius = 0.035) {
  const mesh = new THREE.Mesh(new RoundedBoxGeometry(...size, 2, radius), material);
  mesh.position.set(...position);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function wheel(parent: THREE.Group, x: number, y: number, z: number, radius: number) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, 0.15, 20), rubber);
  mesh.rotation.z = Math.PI / 2;
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  parent.add(mesh);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.38, radius * 0.38, 0.17, 18), steel);
  hub.rotation.z = Math.PI / 2;
  hub.position.set(x, y, z);
  parent.add(hub);
}

function palletJack(): THREE.Group {
  const group = new THREE.Group();
  for (const x of [-0.4, 0.4]) {
    box(group, red, [0.33, 0.19, 2.8], [x, 0.22, 0.46]);
    box(group, redDark, [0.34, 0.055, 2.7], [x, 0.32, 0.44], 0.015);
    wheel(group, x - 0.15, 0.13, 1.71, 0.13);
    wheel(group, x + 0.15, 0.13, 1.71, 0.13);
  }
  box(group, red, [1.18, 0.62, 0.55], [0, 0.47, -1.13], 0.11);
  box(group, redDark, [0.76, 0.15, 0.29], [0, 0.8, -1.23]);
  wheel(group, -0.64, 0.24, -1.22, 0.24);
  wheel(group, 0.64, 0.24, -1.22, 0.24);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.1, 1.52, 16), darkSteel);
  stem.position.set(0, 1.54, -1.31);
  stem.rotation.x = -0.14;
  stem.castShadow = true;
  group.add(stem);
  const handleShape = new THREE.Shape();
  handleShape.moveTo(-0.17, 2.25);
  handleShape.lineTo(-0.42, 2.40);
  handleShape.quadraticCurveTo(-0.53, 2.47, -0.48, 2.62);
  handleShape.lineTo(-0.40, 2.78);
  handleShape.quadraticCurveTo(-0.36, 2.85, -0.26, 2.85);
  handleShape.lineTo(0.26, 2.85);
  handleShape.quadraticCurveTo(0.36, 2.85, 0.40, 2.78);
  handleShape.lineTo(0.48, 2.62);
  handleShape.quadraticCurveTo(0.53, 2.47, 0.42, 2.40);
  handleShape.lineTo(0.17, 2.25);
  handleShape.closePath();
  const opening = new THREE.Path();
  opening.moveTo(-0.15, 2.40);
  opening.lineTo(0.15, 2.40);
  opening.lineTo(0.32, 2.51);
  opening.quadraticCurveTo(0.37, 2.55, 0.33, 2.61);
  opening.lineTo(0.27, 2.70);
  opening.quadraticCurveTo(0.25, 2.73, 0.19, 2.73);
  opening.lineTo(-0.19, 2.73);
  opening.quadraticCurveTo(-0.25, 2.73, -0.27, 2.70);
  opening.lineTo(-0.33, 2.61);
  opening.quadraticCurveTo(-0.37, 2.55, -0.32, 2.51);
  opening.closePath();
  handleShape.holes.push(opening);
  const grip = new THREE.Mesh(new THREE.ExtrudeGeometry(handleShape, {
    depth: 0.13, bevelEnabled: true, bevelSegments: 2, steps: 1,
    bevelSize: 0.018, bevelThickness: 0.018, curveSegments: 8,
  }), rubber);
  grip.name = "pallet-jack-grip";
  grip.position.z = -1.52;
  grip.castShadow = true;
  group.add(grip);
  box(group, rubber, [0.22, 0.22, 0.22], [0, 2.25, -1.44], 0.06);
  const releaseLever = box(group, darkSteel, [0.3, 0.045, 0.07], [0.15, 2.51, -1.43], 0.018);
  releaseLever.rotation.z = -0.22;
  group.position.y = -0.05;
  return group;
}

function sortingTable(): THREE.Group {
  const group = new THREE.Group();
  box(group, steel, [4.2, 0.18, 2.55], [0, 1.11, 0], 0.08);
  box(group, darkSteel, [4.15, 0.07, 2.5], [0, 0.98, 0], 0.02);
  for (const x of [-1.84, 1.84]) for (const z of [-1.02, 1.02]) {
    box(group, darkSteel, [0.13, 1, 0.13], [x, 0.51, z]);
    box(group, steel, [0.2, 0.09, 0.2], [x, 0.07, z]);
  }
  box(group, darkSteel, [3.5, 0.09, 0.08], [0, 0.34, -1.03]);
  box(group, darkSteel, [3.5, 0.09, 0.08], [0, 0.34, 1.03]);
  for (const z of [-0.57, 0.57]) for (const x of [-1.43, -0.48, 0.48, 1.43]) {
    box(group, cardboard, [0.75, 0.42, 0.82], [x, 1.45, z], 0.035);
    box(group, cardboardEdge, [0.79, 0.06, 0.86], [x, 1.69, z], 0.01);
    box(group, steel, [0.1, 0.015, 0.86], [x, 1.73, z], 0.005);
  }
  return group;
}

function conveyor(): THREE.Group {
  const group = new THREE.Group();
  const bend = (innerRadius: number, outerRadius: number, height: number, thickness: number, material: THREE.Material, name?: string) => {
    const shape = new THREE.Shape();
    const centerX = 0.1;
    const centerZ = -0.1;
    const steps = 24;
    for (let i = 0; i <= steps; i++) {
      const angle = Math.PI - (Math.PI / 2) * i / steps;
      const x = centerX + outerRadius * Math.cos(angle);
      const y = -(centerZ + outerRadius * Math.sin(angle));
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    for (let i = 0; i <= steps; i++) {
      const angle = Math.PI / 2 + (Math.PI / 2) * i / steps;
      shape.lineTo(centerX + innerRadius * Math.cos(angle), -(centerZ + innerRadius * Math.sin(angle)));
    }
    shape.closePath();
    const mesh = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: false }), material);
    mesh.name = name ?? "";
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.y = height;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
  };
  const rollers = (alongX: boolean, start: number, end: number, fixed: number) => {
    for (let point = start; point <= end; point += 0.27) {
      const roller = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.02, 16), steel);
      roller.name = "conveyor-roller";
      if (alongX) { roller.rotation.x = Math.PI / 2; roller.position.set(point, 1.02, fixed); }
      else { roller.rotation.z = Math.PI / 2; roller.position.set(fixed, 1.02, point); }
      roller.castShadow = true;
      group.add(roller);
    }
  };
  box(group, darkSteel, [1.18, 0.1, 1.58], [-0.75, 0.94, -0.88]);
  box(group, darkSteel, [1.65, 0.1, 1.12], [0.91, 0.94, 0.75]);
  rollers(false, -1.54, -0.18, -0.75);
  rollers(true, 0.27, 1.63, 0.75);
  bend(0.17, 1.53, 0.85, 0.12, darkSteel);
  bend(0.31, 1.39, 0.97, 0.12, belt, "conveyor-belt-bend");
  bend(1.39, 1.53, 0.97, 0.27, blue);
  bend(0.17, 0.31, 0.97, 0.27, blue);
  bend(1.43, 1.49, 1.24, 0.055, steel);
  bend(0.21, 0.27, 1.24, 0.055, steel);
  bend(1.38, 1.49, 0.71, 0.08, darkSteel, "conveyor-lower-outer-rail");
  bend(0.21, 0.32, 0.71, 0.08, darkSteel, "conveyor-lower-inner-rail");
  for (const x of [-1.36, -0.14]) {
    box(group, blue, [0.14, 0.27, 1.57], [x, 1.03, -0.885], 0.025);
    box(group, steel, [0.06, 0.055, 1.57], [x, 1.19, -0.885], 0.015);
  }
  for (const z of [0.14, 1.36]) {
    box(group, blue, [1.65, 0.27, 0.14], [0.925, 1.03, z], 0.025);
    box(group, steel, [1.65, 0.055, 0.06], [0.925, 1.19, z], 0.015);
  }
  for (const x of [-1.34, -0.16]) box(group, darkSteel, [0.11, 0.08, 1.5], [x, 0.75, -0.88]);
  for (const z of [0.17, 1.33]) box(group, darkSteel, [1.6, 0.08, 0.11], [0.92, 0.75, z]);
  for (const [x, z] of [[-1.34, -1.55], [-0.16, -1.55], [-1.08, 0.81], [1.63, 0.18], [1.63, 1.3]]) {
    box(group, darkSteel, [0.13, 0.89, 0.13], [x, 0.47, z]);
    box(group, steel, [0.2, 0.07, 0.2], [x, 0.045, z]);
  }
  box(group, blue, [0.68, 0.46, 0.35], [1.42, 0.64, 1.15], 0.06);
  box(group, darkSteel, [0.42, 0.25, 0.03], [1.42, 0.65, 1.34], 0.01);
  for (const x of [-1.32, -0.18]) box(group, redDark, [0.13, 0.06, 0.06], [x, 1.14, -1.67], 0.01);
  return group;
}

function receivingTable(): THREE.Group {
  const group = new THREE.Group();
  box(group, worktop, [3.9, 0.12, 1.72], [0, 1.04, 0], 0.025).name = "receiving-worktop";
  box(group, blue, [3.88, 0.055, 0.06], [0, 0.97, 0.84], 0.01);
  for (const x of [-1.79, 1.79]) for (const z of [-0.72, 0.72]) {
    box(group, rackSteel, [0.1, 0.95, 0.1], [x, 0.51, z], 0.01);
    box(group, darkSteel, [0.17, 0.045, 0.17], [x, 0.05, z], 0.005);
  }
  box(group, rackSteel, [3.56, 0.055, 1.23], [0, 0.3, -0.09], 0.012);
  for (const x of [-0.95, 0.19]) {
    box(group, blue, [0.88, 0.05, 0.6], [x, 0.37, -0.14], 0.01);
    box(group, blue, [0.88, 0.5, 0.05], [x, 0.63, -0.42], 0.01);
    box(group, blue, [0.88, 0.5, 0.05], [x, 0.63, 0.14], 0.01).name = "receiving-tote";
    for (const side of [-0.41, 0.41]) {
      box(group, blue, [0.06, 0.5, 0.6], [x + side, 0.63, -0.14], 0.01);
      for (const z of [-0.34, -0.14, 0.06]) {
        box(group, toteRib, [0.025, 0.42, 0.025], [x + side + Math.sign(side) * 0.04, 0.63, z], 0.005);
      }
    }
    for (const rib of [-0.31, 0.31]) {
      box(group, toteRib, [0.035, 0.44, 0.025], [x + rib, 0.62, 0.176], 0.005);
    }
    for (const z of [-0.43, 0.15]) box(group, toteRib, [0.92, 0.045, 0.07], [x, 0.89, z], 0.006);
    for (const side of [-0.43, 0.43]) box(group, toteRib, [0.07, 0.045, 0.64], [x + side, 0.89, -0.14], 0.006);
    box(group, darkSteel, [0.28, 0.07, 0.012], [x, 0.77, 0.173], 0.008);
    box(group, steel, [0.38, 0.018, 0.012], [x, 0.73, 0.18], 0.004);
  }

  // Open shelving behind the packing surface holds flattened cartons and supplies.
  for (const x of [-1.74, 1.74]) {
    box(group, rackSteel, [0.07, 1.78, 0.07], [x, 1.94, -0.74], 0.008);
  }
  for (const y of [2.03, 2.6]) {
    box(group, rackSteel, [3.57, 0.06, 0.49], [0, y, -0.74], 0.008);
    box(group, steel, [3.57, 0.045, 0.04], [0, y - 0.025, -0.49], 0.005);
  }
  for (const x of [-1.34, -0.78, 0.14, 0.75, 1.37]) {
    box(group, cardboard, [0.4, 0.19, 0.35], [x, 2.74, -0.74], 0.012).name = "receiving-flat-cartons";
    for (const y of [2.71, 2.77]) box(group, cardboardEdge, [0.41, 0.012, 0.36], [x, y, -0.74], 0.004);
  }
  for (const x of [-1.25, -0.74, 0.9]) {
    box(group, cardboard, [0.42, 0.27, 0.36], [x, 2.2, -0.74], 0.012);
    box(group, cardboardEdge, [0.43, 0.014, 0.37], [x, 2.34, -0.74], 0.004);
  }
  box(group, darkSteel, [0.9, 0.58, 0.095], [-1.13, 1.49, -0.36], 0.025).name = "receiving-monitor";
  box(group, screen, [0.79, 0.47, 0.012], [-1.13, 1.49, -0.302], 0.008);
  box(group, darkSteel, [0.07, 0.18, 0.07], [-1.13, 1.16, -0.39]);
  box(group, darkSteel, [0.4, 0.035, 0.25], [-1.13, 1.095, -0.39], 0.01);
  box(group, darkSteel, [0.7, 0.035, 0.24], [-1.16, 1.13, 0.22], 0.012);
  for (let row = 0; row < 3; row++) for (let key = 0; key < 7; key++) {
    box(group, paleSteel, [0.07, 0.009, 0.047], [-1.42 + key * 0.09, 1.153, 0.14 + row * 0.07], 0.003);
  }

  const mouse = new THREE.Group();
  mouse.name = "receiving-mouse";
  mouse.position.set(-0.73, 1.1, 0.5);
  group.add(mouse);
  const mouseBody = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), rubber);
  mouseBody.scale.set(0.105, 0.065, 0.15);
  mouseBody.position.y = 0.045;
  mouseBody.castShadow = true;
  mouse.add(mouseBody);
  const scrollWheel = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.021, 0.024, 12), rackShade);
  scrollWheel.rotation.z = Math.PI / 2;
  scrollWheel.position.set(0, 0.108, -0.047);
  mouse.add(scrollWheel);
  const mouseCable = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.73, 1.115, 0.355),
    new THREE.Vector3(-0.65, 1.114, -0.08),
    new THREE.Vector3(-0.76, 1.114, -0.2),
    new THREE.Vector3(-1.01, 1.114, -0.16),
    new THREE.Vector3(-1.13, 1.114, -0.35),
  ]), 32, 0.008, 6, false), rubber);
  mouseCable.name = "receiving-mouse-cable";
  mouseCable.castShadow = true;
  group.add(mouseCable);

  box(group, cardboard, [0.82, 0.46, 0.58], [0.09, 1.34, 0.08], 0.012).name = "receiving-parcel";
  box(group, packingPaper, [0.34, 0.007, 0.18], [0.1, 1.578, 0.08], 0.003);
  box(group, blue, [0.055, 0.008, 0.59], [0.1, 1.583, 0.08], 0.002);
  box(group, packingPaper, [0.5, 0.075, 0.36], [-0.35, 1.13, 0.53], 0.008);
  box(group, blue, [0.06, 0.009, 0.37], [-0.35, 1.174, 0.53], 0.003);

  const scanner = new THREE.Group();
  scanner.name = "receiving-scanner";
  scanner.position.set(1.1, 1.105, 0.17);
  scanner.scale.setScalar(0.5);
  scanner.rotation.y = -0.35;
  group.add(scanner);
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.085, 0.57, 16), rubber);
  grip.rotation.z = Math.PI / 2;
  grip.position.set(0.15, 0.17, 0);
  grip.castShadow = true;
  scanner.add(grip);
  const scannerProfile = new THREE.Shape();
  scannerProfile.moveTo(-0.43, 0.03);
  scannerProfile.lineTo(-0.38, 0.26);
  scannerProfile.lineTo(-0.3, 0.37);
  scannerProfile.lineTo(-0.16, 0.36);
  scannerProfile.lineTo(-0.1, 0.23);
  scannerProfile.lineTo(-0.19, 0.06);
  scannerProfile.closePath();
  const head = new THREE.Mesh(new THREE.ExtrudeGeometry(scannerProfile, {
    depth: 0.23, bevelEnabled: true, bevelSegments: 2, steps: 1,
    bevelSize: 0.012, bevelThickness: 0.012,
  }), darkSteel);
  head.position.z = -0.115;
  head.castShadow = true;
  scanner.add(head);
  const scanningWindow = box(scanner, rubber, [0.025, 0.18, 0.16], [-0.414, 0.15, 0], 0.006);
  scanningWindow.rotation.z = 0.22;
  box(scanner, rackShade, [0.045, 0.28, 0.27], [-0.15, 0.22, 0], 0.015);
  box(scanner, darkSteel, [0.08, 0.075, 0.11], [-0.01, 0.08, 0], 0.01);
  box(scanner, rackShade, [0.12, 0.17, 0.2], [0.45, 0.17, 0], 0.02);
  return group;
}

function receivingGate(): THREE.Group {
  const group = new THREE.Group();
  box(group, darkSteel, [3.35, 2.58, 0.12], [0, 1.34, -0.18], 0.015);
  for (let i = 0; i < 19; i++) {
    box(group, i % 2 === 0 ? steel : paleSteel, [3.12, 0.11, 0.08], [0, 0.23 + i * 0.116, -0.075], 0.005);
  }
  for (const x of [-1.68, 1.68]) {
    box(group, darkSteel, [0.17, 2.72, 0.27], [x, 1.38, 0], 0.01);
    box(group, steel, [0.055, 2.5, 0.11], [x > 0 ? x - 0.11 : x + 0.11, 1.31, 0.07], 0.005);
  }
  box(group, darkSteel, [3.58, 0.2, 0.34], [0, 2.77, 0], 0.02);
  box(group, darkSteel, [3.25, 0.09, 0.48], [0, 0.06, 0.14], 0.01);
  for (let i = 0; i < 11; i++) {
    const stripe = box(group, caution, [0.17, 0.01, 0.34], [-1.45 + i * 0.29, 0.115, 0.14], 0.002);
    stripe.rotation.y = -0.55;
  }
  box(group, darkSteel, [0.2, 0.37, 0.12], [1.92, 1.38, 0.07], 0.015);
  box(group, caution, [0.095, 0.09, 0.02], [1.92, 1.42, 0.14], 0.005);
  return group;
}

function storageRack(): THREE.Group {
  const group = new THREE.Group();
  for (const x of [-1.72, 1.72]) for (const z of [-0.54, 0.54]) {
    const upright = box(group, rackSteel, [0.09, 2.67, 0.09], [x, 1.35, z], 0.008);
    upright.name = "storage-upright";
    for (let i = 0; i < 15; i++) {
      box(group, darkSteel, [0.025, 0.055, 0.006], [x, 0.16 + i * 0.17, z + 0.049], 0.002);
    }
  }
  for (const height of [0.28, 0.78, 1.28, 1.78, 2.28]) {
    const shelf = box(group, rackSteel, [3.48, 0.055, 1.12], [0, height, 0], 0.008);
    shelf.name = "storage-shelf";
    box(group, rackShade, [3.49, 0.055, 0.05], [0, height - 0.006, 0.56], 0.005);
    box(group, rackShade, [3.49, 0.05, 0.05], [0, height - 0.006, -0.56], 0.005);
    for (const x of [-0.86, 0.86]) {
      box(group, steel, [1.56, 0.06, 0.05], [x, height - 0.055, 0], 0.005);
    }
  }
  return group;
}

function freightLift(): THREE.Group {
  const group = new THREE.Group();
  const floor = box(group, darkSteel, [2.35, 0.15, 2.25], [0.65, 0.15, -0.34], 0.015);
  floor.name = "lift-floor";
  box(group, steel, [2.17, 0.045, 2.1], [0.65, 0.25, -0.34]);
  for (const x of [-0.51, 1.81]) for (const z of [-1.41, 0.72]) {
    box(group, steel, [0.12, 2.16, 0.12], [x, 1.13, z], 0.01);
  }
  for (const x of [-0.48, 1.78]) {
    for (let j = 0; j < 15; j++) box(group, blue, [0.024, 1.6, 0.025], [x, 1.16, -1.3 + j * 0.14], 0.005);
    for (let j = 0; j < 7; j++) box(group, blue, [0.024, 0.025, 2.04], [x, 0.4 + j * 0.25, -0.32], 0.005);
  }
  for (let j = 0; j < 13; j++) {
    box(group, blue, [0.025, 1.6, 0.024], [-0.4 + j * 0.17, 1.16, -1.4], 0.005);
  }
  for (let j = 0; j < 7; j++) {
    box(group, blue, [2.12, 0.025, 0.024], [0.65, 0.4 + j * 0.25, -1.4], 0.005);
  }
  box(group, darkSteel, [2.17, 1.79, 0.11], [0.65, 1.17, 0.74], 0.008);
  for (let i = 0; i < 11; i++) {
    box(group, i % 2 ? paleSteel : steel, [1.95, 0.145, 0.04], [0.65, 0.4 + i * 0.15, 0.81], 0.005);
  }
  const mainDeck = box(group, darkSteel, [2.42, 0.14, 2.25], [0.65, 2.18, -0.34], 0.01);
  mainDeck.name = "lift-deck-main";
  box(group, steel, [2.34, 0.035, 2.17], [0.65, 2.27, -0.34], 0.005);
  const landing = box(group, darkSteel, [1.84, 0.14, 0.69], [-1.48, 2.18, -1.12], 0.01);
  landing.name = "lift-deck-landing";
  box(group, steel, [1.76, 0.035, 0.61], [-1.48, 2.27, -1.12], 0.005);
  for (const x of [-2.29, -1.2, -0.14, 0.94, 1.72]) {
    box(group, steel, [0.06, 0.56, 0.06], [x, 2.5, -1.37], 0.008);
  }
  for (const x of [-0.505, -0.14, 0.94, 1.72]) {
    box(group, steel, [0.06, 0.56, 0.06], [x, 2.5, 0.69], 0.008);
  }
  for (const height of [2.53, 2.8]) {
    box(group, steel, [4.09, 0.05, 0.06], [-0.32, height, -1.37]);
    box(group, steel, [2.31, 0.05, 0.06], [0.65, height, 0.69]);
    box(group, steel, [0.06, 0.05, 2.06], [1.72, height, -0.34]);
  }
  for (const x of [-2.29, -0.99]) {
    box(group, steel, [0.06, 0.56, 0.06], [x, 2.5, -0.81], 0.008);
    const stairRailX = x < -1.64 ? -2.2 : -1.08;
    box(group, steel, [0.09, 0.06, 0.06], [(x + stairRailX) / 2, 2.8, -0.81]);
  }
  box(group, steel, [0.06, 0.05, 0.56], [-2.29, 2.8, -1.09]);
  box(group, steel, [0.06, 0.05, 0.56], [-2.29, 2.53, -1.09]);
  for (let i = 0; i < 7; i++) {
    box(group, steel, [1.2, 0.07, 0.32], [-1.64, 0.26 + i * 0.31, 1.21 - i * 0.31], 0.01);
  }
  for (const x of [-2.2, -1.08]) {
    const stringer = box(group, darkSteel, [0.08, 0.13, 3.05], [x, 1.17, 0.09], 0.01);
    stringer.name = "lift-stair-stringer";
    stringer.rotation.x = 0.735;
    const handrail = box(group, steel, [0.06, 0.06, Math.hypot(2.18, 2.18)], [x, 1.71, 0.28]);
    handrail.name = "lift-stair-handrail";
    handrail.rotation.x = Math.PI / 4;
    for (const step of [0, 2, 4]) {
      box(group, steel, [0.05, 0.51, 0.05], [x, 0.525 + step * 0.31, 1.21 - step * 0.31], 0.006);
      box(group, steel, [0.07, 0.018, 0.09], [x, 0.304 + step * 0.31, 1.21 - step * 0.31], 0.004);
    }
  }
  box(group, caution, [1.93, 0.04, 0.16], [0.65, 0.28, 0.76], 0.004);
  box(group, darkSteel, [0.13, 0.25, 0.08], [1.73, 1.13, 0.84]);
  box(group, red, [0.055, 0.055, 0.02], [1.73, 1.1, 0.89], 0.005);
  return group;
}

function meshCart(): THREE.Group {
  const group = new THREE.Group();
  box(group, blue, [2.7, 0.12, 1.44], [0, 0.32, 0], 0.02);
  for (const x of [-1.29, 1.29]) for (const z of [-0.65, 0.65]) {
    box(group, blue, [0.09, 1.55, 0.09], [x, 1.09, z], 0.01);
    wheel(group, x + (x > 0 ? 0.06 : -0.06), 0.15, z, 0.13);
  }
  for (const height of [0.51, 1.03, 1.55, 1.85]) {
    for (const z of [-0.65, 0.65]) box(group, blue, [2.69, 0.05, 0.05], [0, height, z], 0.006);
    for (const x of [-1.29, 1.29]) box(group, blue, [0.05, 0.05, 1.36], [x, height, 0], 0.006);
  }
  for (let i = 0; i < 17; i++) {
    const x = -1.16 + i * 0.145;
    for (const z of [-0.65, 0.65]) box(group, blue, [0.018, 1.32, 0.018], [x, 1.18, z], 0.003);
  }
  for (let i = 0; i < 9; i++) {
    const z = -0.56 + i * 0.14;
    for (const x of [-1.29, 1.29]) box(group, blue, [0.018, 1.32, 0.018], [x, 1.18, z], 0.003);
  }
  return group;
}

export function createObjectModel(id: ObjectId): THREE.Group {
  switch (id) {
    case "pallet-jack": return palletJack();
    case "sorting-table": return sortingTable();
    case "conveyor": return conveyor();
    case "receiving-table": return receivingTable();
    case "receiving-gate": return receivingGate();
    case "storage-rack": return storageRack();
    case "freight-lift": return freightLift();
    case "mesh-cart": return meshCart();
  }
}
