import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Footprints, Forklift, Package, Pause, Play, RotateCcw } from "lucide-react";
import { site, type MovementMode, type PageCopy } from "@/config/site";
import { advancePreview, initialPreview, keyDirections, movementModes, spriteUrl, type Direction } from "./movement";
import styles from "./MovementDemo.module.css";

const modeIcons = { foot: Footprints, transporter: Forklift, "pallet-jack": Package };
const controls = [
  { direction: "up" as const, Icon: ArrowUp },
  { direction: "left" as const, Icon: ArrowLeft },
  { direction: "down" as const, Icon: ArrowDown },
  { direction: "right" as const, Icon: ArrowRight },
];

function subscribeMotionPreference(callback: () => void) {
  const query = window.matchMedia("(prefers-reduced-motion: reduce)");
  query.addEventListener("change", callback);
  return () => query.removeEventListener("change", callback);
}

function prefersReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function stageSize(stage: HTMLDivElement) {
  const style = getComputedStyle(stage);
  return { width: stage.clientWidth, height: stage.clientHeight, scale: Number(style.getPropertyValue("--actor-scale")), playbackRate: Number(style.getPropertyValue("--preview-rate")) || 1 };
}

export default function MovementDemo({ content }: { content: PageCopy }) {
  const stageRef = useRef<HTMLDivElement>(null);
  const pressed = useRef<Direction | null>(null);
  const previewRef = useRef(initialPreview());
  const [preview, setPreview] = useState(initialPreview);
  const [mode, setMode] = useState<MovementMode>("foot");
  const [autoplay, setAutoplay] = useState<boolean | null>(null);
  const reducedMotion = useSyncExternalStore(subscribeMotionPreference, prefersReducedMotion, () => false);
  const playing = autoplay ?? !reducedMotion;
  const selected = content.movement.modes[mode];

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    let visible = false;
    let size = stageSize(stage);
    let previousTime = 0;
    let accumulated = 0;
    let frameId = 0;
    const visibility = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; });
    const resize = new ResizeObserver(() => { size = stageSize(stage); });
    visibility.observe(stage);
    resize.observe(stage);

    function animate(time: number) {
      const delta = previousTime ? Math.min((time - previousTime) / 1000, 0.05) : 0;
      previousTime = time;
      accumulated += delta;
      if (accumulated >= 1 / 30) {
        if (visible && !document.hidden && size.width && size.height) {
          const next = advancePreview(previewRef.current, mode, pressed.current, playing, accumulated * (pressed.current ? 1 : size.playbackRate), size);
          if (next !== previewRef.current) {
            previewRef.current = next;
            setPreview(next);
          }
        }
        accumulated = 0;
      }
      frameId = requestAnimationFrame(animate);
    }

    frameId = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(frameId);
      visibility.disconnect();
      resize.disconnect();
    };
  }, [mode, playing]);

  function reset() {
    pressed.current = null;
    const next = initialPreview();
    previewRef.current = next;
    setPreview(next);
  }

  function stop() {
    pressed.current = null;
  }

  function move(direction: Direction) {
    setAutoplay(false);
    pressed.current = direction;
  }

  function changeMode(nextMode: MovementMode) {
    reset();
    setMode(nextMode);
    setAutoplay(null);
  }

  function onKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    const direction = keyDirections[event.key.toLowerCase()];
    if (!direction) return;
    event.preventDefault();
    move(direction);
  }

  function onKeyUp(event: React.KeyboardEvent<HTMLDivElement>) {
    const direction = keyDirections[event.key.toLowerCase()];
    if (!direction) return;
    event.preventDefault();
    if (pressed.current === direction) stop();
  }

  function tap(direction: Direction) {
    setAutoplay(false);
    const stage = stageRef.current;
    if (!stage) return;
    const next = advancePreview(previewRef.current, mode, direction, false, 0.12, stageSize(stage));
    previewRef.current = next;
    setPreview(next);
  }

  return (
    <div className={styles.demo}>
      <div className={styles.modeBar}>
        <div className={styles.modes} role="tablist" aria-label={content.movement.modesLabel}>
          {movementModes.map((id, index) => {
            const Icon = modeIcons[id];
            return (
              <button
                key={id}
                id={`movement-tab-${id}`}
                type="button"
                role="tab"
                aria-selected={mode === id}
                aria-controls="movement-panel"
                tabIndex={mode === id ? 0 : -1}
                onClick={() => changeMode(id)}
                onKeyDown={(event) => {
                  const offset = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
                  if (!offset && event.key !== "Home" && event.key !== "End") return;
                  event.preventDefault();
                  const next = event.key === "Home" ? 0 : event.key === "End" ? movementModes.length - 1 : (index + offset + movementModes.length) % movementModes.length;
                  changeMode(movementModes[next]);
                  document.getElementById(`movement-tab-${movementModes[next]}`)?.focus();
                }}
              ><Icon size={19} aria-hidden="true" /><span>{content.movement.modes[id].name}</span></button>
            );
          })}
        </div>
        <span className={styles.register}>DML / 0{movementModes.indexOf(mode) + 1}</span>
      </div>
      <div id="movement-panel" role="tabpanel" aria-labelledby={`movement-tab-${mode}`}>
        <div
          ref={stageRef}
          className={styles.stage}
          style={{ backgroundImage: `url(${site.media.movement})` }}
          tabIndex={0}
          role="application"
          aria-label={content.movement.aria}
          onKeyDown={onKeyDown}
          onKeyUp={onKeyUp}
          onBlur={stop}
        >
          <div className={styles.stageLabel}><span />{selected.name}</div>
          <div className={styles.character} data-testid="movement-actor" data-mode={mode} style={{ left: `${preview.position.x}%`, top: `${preview.position.y}%` }}>
            <span
              className={styles.sprite}
              data-testid="movement-sprite"
              aria-hidden="true"
              style={{ backgroundImage: `url(${spriteUrl(mode, preview)})`, backgroundPosition: `${-preview.frame * 256}px 0` }}
            />
          </div>
          <span className={styles.corner} aria-hidden="true" />
        </div>
        <div className={styles.toolbar}>
          <div className={styles.caption}>
            <h3>{selected.name}</h3>
            <p>{selected.description}</p>
          </div>
          <div className={styles.actions}>
            <button className={styles.play} type="button" title={playing ? content.movement.pause : content.movement.play} aria-label={playing ? content.movement.pause : content.movement.play} onClick={() => { stop(); setAutoplay(!playing); }}>
              {playing ? <Pause size={18} aria-hidden="true" /> : <Play size={18} aria-hidden="true" />}
            </button>
            <div className={styles.controls} role="group" aria-label={content.movement.controls}>
              {controls.map(({ direction, Icon }) => (
                <button
                  key={direction}
                  type="button"
                  title={content.movement.directions[direction]}
                  aria-label={content.movement.directions[direction]}
                  onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); move(direction); tap(direction); }}
                  onPointerUp={stop}
                  onPointerCancel={stop}
                  onLostPointerCapture={stop}
                  onKeyDown={(event) => { if (event.key === " " || event.key === "Enter") { event.preventDefault(); move(direction); } }}
                  onKeyUp={(event) => { if (event.key === " " || event.key === "Enter") { event.preventDefault(); stop(); } }}
                  onBlur={stop}
                  onClick={(event) => { if (event.detail === 0) tap(direction); }}
                ><Icon size={18} aria-hidden="true" /></button>
              ))}
            </div>
            <button type="button" title={content.movement.reset} aria-label={content.movement.reset} onClick={reset}><RotateCcw size={18} aria-hidden="true" /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
