import type { MovementMode } from "@/config/site";

export type Direction = "up" | "down" | "left" | "right";
type Position = { x: number; y: number };
export type PreviewState = {
  position: Position;
  direction: Direction;
  frame: number;
  moving: boolean;
  target: number;
  elapsed: number;
};

export const movementModes: MovementMode[] = ["foot", "transporter", "pallet-jack"];
export const keyDirections: Record<string, Direction> = {
  arrowup: "up", w: "up", arrowdown: "down", s: "down",
  arrowleft: "left", a: "left", arrowright: "right", d: "right",
};

const speeds: Record<MovementMode, number> = { foot: 120, transporter: 110, "pallet-jack": 85 };
type SpriteExtent = { left: number; top: number; right: number; bottom: number };

// Visible bounds across the eight native frames, relative to their 128px anchor.
const spriteExtents: Record<MovementMode, Record<Direction, SpriteExtent>> = {
  foot: {
    up: { left: 15, top: 18, right: 15, bottom: 31 },
    down: { left: 15, top: 19, right: 15, bottom: 31 },
    left: { left: 13, top: 18, right: 16, bottom: 30 },
    right: { left: 16, top: 18, right: 13, bottom: 30 },
  },
  "pallet-jack": {
    up: { left: 15, top: 13, right: 24, bottom: 95 },
    down: { left: 14, top: 78, right: 15, bottom: 31 },
    left: { left: -3, top: 9, right: 107, bottom: 45 },
    right: { left: 111, top: 9, right: -6, bottom: 45 },
  },
  transporter: {
    up: { left: 21, top: 56, right: 21, bottom: 55 },
    down: { left: 19, top: 45, right: 19, bottom: 44 },
    left: { left: 55, top: 36, right: 56, bottom: 36 },
    right: { left: 57, top: 36, right: 54, bottom: 36 },
  },
};

export function initialPreview(): PreviewState {
  return { position: { x: 50, y: 50 }, direction: "right", frame: 0, moving: false, target: 1, elapsed: 0 };
}

export function spriteUrl(mode: MovementMode, preview: PreviewState): string {
  const animation = mode === "foot" && !preview.moving ? "idle" : "move";
  return `/media/${mode}-${animation}-${preview.direction}.png`;
}

export function advancePreview(
  current: PreviewState,
  mode: MovementMode,
  manualDirection: Direction | null,
  autoplay: boolean,
  delta: number,
  size: { width: number; height: number; scale: number },
): PreviewState {
  if (!manualDirection && !autoplay) {
    return current.moving ? { ...current, moving: false, frame: 0 } : current;
  }

  const extents = Object.values(spriteExtents[mode]);
  const routeLeft = Math.max(30, (Math.max(...extents.map((extent) => extent.left)) * size.scale + 12) / size.width * 100 + 2);
  const routeRight = Math.min(70, 98 - (Math.max(...extents.map((extent) => extent.right)) * size.scale + 12) / size.width * 100);
  const destination = current.target === 1 ? routeRight : routeLeft;
  const direction = manualDirection ?? (destination > current.position.x ? "right" : "left");
  const horizontal = direction === "left" || direction === "right";
  const distance = speeds[mode] * delta * 100 / (horizontal ? size.width : size.height);
  const sign = direction === "left" || direction === "up" ? -1 : 1;
  const position = { ...current.position };
  let target = current.target;

  if (horizontal) position.x += sign * distance;
  else position.y += sign * distance;

  if (!manualDirection && Math.abs(destination - current.position.x) <= distance) {
    position.x = destination;
    target = 1 - target;
  }

  const extent = spriteExtents[mode][direction];
  const minX = Math.max(25, (extent.left * size.scale + 12) / size.width * 100);
  const maxX = Math.min(75, 100 - (extent.right * size.scale + 12) / size.width * 100);
  const minY = Math.max(25, (extent.top * size.scale + 12) / size.height * 100);
  const maxY = Math.min(75, 100 - (extent.bottom * size.scale + 12) / size.height * 100);
  position.x = Math.max(minX, Math.min(maxX, position.x));
  position.y = Math.max(minY, Math.min(maxY, position.y));
  const elapsed = current.elapsed + delta;
  return { position, direction, target, elapsed, moving: true, frame: Math.floor(elapsed * (mode === "foot" ? 10 : 6)) % 8 };
}
