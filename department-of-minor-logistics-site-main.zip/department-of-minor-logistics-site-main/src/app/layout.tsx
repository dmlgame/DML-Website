import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Department of Minor Logistics | Независимая игра о складе",
  description:
    "Department of Minor Logistics: небольшой пиксельный склад, где у каждой мелочи своё место. Независимая игра в разработке для ПК и мобильных устройств.",
  openGraph: {
    title: "Department of Minor Logistics",
    description: "Маленький склад. Удивительно важные дела.",
    type: "website",
    locale: "ru_RU",
    alternateLocale: "en_US",
  },
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
