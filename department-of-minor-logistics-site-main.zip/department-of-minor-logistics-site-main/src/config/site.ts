type GalleryImage = {
  src: string;
  width: number;
  height: number;
  crop?: { x: number; y: number; width: number; height: number };
};

export const site = {
  title: "Department of Minor Logistics",
  shortTitle: "DML",
  steamPageUrl: null as string | null,
  demoUrl: "/demo/index.html",
  media: {
    logo: { src: "/media/dml-logo.png", width: 1672, height: 941, symbolHeight: 662 },
    hero: "/media/hero-conveyor-3d-v2.png",
    heroMobile: "/media/hero-conveyor-3d-mobile.png",
    gallery: [
      { src: "/media/gallery-stockroom-lift.png", width: 1920, height: 1080, crop: { x: 384, y: 196, width: 1152, height: 648 } },
      { src: "/media/gallery-facilities.png", width: 1440, height: 810 },
      { src: "/media/gallery-charging-v2.png", width: 1156, height: 643 },
      { src: "/media/gallery-coworkers.png", width: 1440, height: 810 },
    ] as GalleryImage[],
    movement: "/media/animation-floor.png",
  },
} as const;

export type Locale = "en" | "ru";
export type ObjectId = "pallet-jack" | "sorting-table" | "conveyor" | "receiving-table" | "receiving-gate" | "storage-rack" | "freight-lift" | "mesh-cart";
export type MovementMode = "foot" | "transporter" | "pallet-jack";

type GameObjectCopy = {
  id: ObjectId;
  number: string;
  name: string;
  description: string;
  label: string;
  pixelImage: string;
  pixelCrop?: { x: number; y: number; width: number; height: number; scale?: number; sourceWidth?: number };
};

export type PageCopy = {
  nav: { overview: string; movement: string; objects: string; gallery: string; demo: string };
  status: string;
  hero: { eyebrow: string; lead: string; explore: string; movement: string; scroll: string };
  overview: {
    eyebrow: string;
    title: string;
    lead: string;
    body: string;
    facts: { label: string; value: string }[];
  };
  movement: {
    eyebrow: string;
    title: string;
    body: string;
    controls: string;
    reset: string;
    aria: string;
    play: string;
    pause: string;
    modesLabel: string;
    modes: Record<MovementMode, { name: string; description: string }>;
    directions: Record<"up" | "down" | "left" | "right", string>;
  };
  objects: {
    eyebrow: string;
    title: string;
    body: string;
    rotate: string;
    reference: string;
    conveyorVariants: { corner: string; horizontal: string; vertical: string };
    items: GameObjectCopy[];
  };
  gallery: { eyebrow: string; title: string; captions: string[] };
  ending: { eyebrow: string; title: string; body: string; status: string; earlyAccess: string; earlyAccessDescription: string; comingSoon: string };
  footer: { development: string; backToTop: string; demo: string };
};

export const copy: Record<Locale, PageCopy> = {
  en: {
    nav: { overview: "Info", movement: "Animations", objects: "Equipment", gallery: "Photo report", demo: "Demo" },
    status: "In development for PC and mobile",
    hero: {
      eyebrow: "An independent pixel-art game",
      lead: "A small warehouse. A surprisingly official amount of work.",
      explore: "Enter the department",
      movement: "See the animations",
      scroll: "Scroll down to learn more",
    },
    overview: {
      eyebrow: "Quick information / 01",
      title: "Every little thing has its place.",
      lead: "The Department is modest in size. Its sense of procedure is not.",
      body: "Take a shift among conveyors, pallet jacks, sorting desks and coworkers. Wander the warehouse on foot, or get behind the handle of its working equipment. The paperwork can wait a minute.",
      facts: [
        { label: "Setting", value: "A working warehouse" },
        { label: "Perspective", value: "Pixel-art, top-down" },
        { label: "Platforms", value: "PC and mobile devices" },
      ],
    },
    movement: {
      eyebrow: "Movement studies / 02",
      title: "Animations",
      body: "The game features different ways to get around.",
      controls: "Movement",
      reset: "Return to start",
      aria: "Game movement preview",
      play: "Play animation",
      pause: "Pause animation",
      modesLabel: "Movement mode",
      modes: {
        foot: { name: "On foot", description: "Every shift starts with a small step." },
        transporter: { name: "Transporter", description: "A little more machinery. A little less walking." },
        "pallet-jack": { name: "Pallet jack", description: "Hands on the handle. Business as usual." },
      },
      directions: { up: "Move up", down: "Move down", left: "Move left", right: "Move right" },
    },
    objects: {
      eyebrow: "Equipment register / 08",
      title: "Tools of a very serious trade.",
      body: "Familiar pieces from the pixel-art floor, reimagined as small 3D objects. Drag to turn them over.",
      rotate: "Drag to rotate",
      reference: "Original game sprite",
      conveyorVariants: { corner: "Corner", horizontal: "Horizontal", vertical: "Vertical" },
      items: [
        {
          id: "pallet-jack", number: "01", name: "Pallet jack", label: "Manual transport",
          description: "A dependable red workhorse for the jobs that absolutely could not wait until tomorrow.",
          pixelImage: "/media/pallet-jack-pixel.png",
        },
        {
          id: "sorting-table", number: "02", name: "Sorting table", label: "Station equipment",
          description: "Eight boxes, one steel table, and the quiet promise that everything will end up somewhere sensible.",
          pixelImage: "/media/sorting-table-pixel.png",
        },
        {
          id: "conveyor", number: "03", name: "Conveyor", label: "The long way around",
          description: "The warehouse has a route for everything. Sometimes that route takes a corner.",
          pixelImage: "/media/conveyor-pixel.png",
        },
        {
          id: "receiving-table", number: "04", name: "Receiving table", label: "Intake station",
          description: "A monitor and handheld scanner above two tall blue totes, ready for the next delivery.",
          pixelImage: "/media/warehouse-objects-atlas.png",
          pixelCrop: { x: 0, y: 208, width: 96, height: 80 },
        },
        {
          id: "receiving-gate", number: "05", name: "Receiving gate", label: "Goods arrive through this portal",
          description: "The rolling shutter marks where a new shift of boxes begins.",
          pixelImage: "/media/warehouse-front-wall-atlas.png",
          pixelCrop: { x: 128, y: 0, width: 128, height: 96 },
        },
        {
          id: "storage-rack", number: "06", name: "Storage rack", label: "Warehouse shelving",
          description: "A sturdy place for stock before it is sorted, moved, or needed somewhere else.",
          pixelImage: "/media/warehouse-racks-atlas.png",
          pixelCrop: { x: 0, y: 192, width: 134, height: 96, scale: 1.35, sourceWidth: 3328 },
        },
        {
          id: "freight-lift", number: "07", name: "Freight lift", label: "Mezzanine access",
          description: "A sturdy route between the warehouse floor and the level above.",
          pixelImage: "/media/freight-lift-pixel.png",
        },
        {
          id: "mesh-cart", number: "08", name: "Mesh cart", label: "Wheeled storage",
          description: "A blue rolling cage for keeping a small mountain of goods together.",
          pixelImage: "/media/warehouse-mesh-carts-atlas.png",
          pixelCrop: { x: 0, y: 0, width: 160, height: 128 },
        },
      ],
    },
    gallery: {
      eyebrow: "Field notes / 04", title: "A look around the shift.",
      captions: ["Stockroom aisles and mezzanine lift", "Restrooms by the emergency exit", "Transporter charging bays", "Shift supervisors' desk"],
    },
    ending: {
      eyebrow: "Notice board", title: "The department opens soon.",
      body: "Department of Minor Logistics is in development for PC and mobile devices. The Steam page is being prepared; there is no release date to file just yet.",
      status: "Steam page in preparation",
      earlyAccess: "Early access", comingSoon: "Soon",
      earlyAccessDescription: "Receive a special bonus when the game launches (after its release) at the email address you registered with.",
    },
    footer: { development: "An independent game in development", backToTop: "Back to top", demo: "Play the demo online" },
  },
  ru: {
    nav: { overview: "Инфо", movement: "Анимации", objects: "Оборудование", gallery: "Фотоотчет", demo: "Демо-версия" },
    status: "Разрабатывается для ПК и мобильных устройств",
    hero: {
      eyebrow: "Независимая пиксельная игра",
      lead: "Маленький склад. Удивительно важные дела.",
      explore: "Войти в отдел", movement: "Посмотреть анимации", scroll: "Листай вниз, чтоб узнать больше",
    },
    overview: {
      eyebrow: "Краткая информация / 01", title: "У каждой мелочи свое место.",
      lead: "Отдел невелик. А вот порядок здесь принимают всерьез.",
      body: "Проведи смену среди конвейеров, рохлей, сортировочных столов и коллег. Исследуй склад пешком или воспользуйся рабочей техникой. Бумаги пока подождут.",
      facts: [
        { label: "Место", value: "Действующий склад" },
        { label: "Вид", value: "Пиксель-арт, сверху" },
        { label: "Платформы", value: "ПК и мобильные устройства" },
      ],
    },
    movement: {
      eyebrow: "В движении / 02", title: "Анимации",
      body: "В игре есть различные способы передвижения",
      controls: "Передвижение", reset: "Вернуть в начало",
      aria: "Передвижение в игре",
      play: "Запустить анимацию", pause: "Приостановить анимацию",
      modesLabel: "Способ передвижения",
      modes: {
        foot: { name: "Пешком", description: "Каждая смена начинается с небольшого шага." },
        transporter: { name: "Транспорт", description: "Чуть больше техники. Чуть меньше ходьбы." },
        "pallet-jack": { name: "С рохлей", description: "Руки на рукоять. Работа идет своим чередом." },
      },
      directions: { up: "Вверх", down: "Вниз", left: "Влево", right: "Вправо" },
    },
    objects: {
      eyebrow: "Реестр оборудования / 08", title: "Инструменты серьезной работы.",
      body: "Знакомые предметы из пиксельного склада в виде небольших 3D-моделей. Потяни, чтобы повернуть.",
      rotate: "Потяни, чтобы повернуть", reference: "Спрайт из игры",
      conveyorVariants: { corner: "Поворот", horizontal: "Горизонтальный", vertical: "Вертикальный" },
      items: [
        {
          id: "pallet-jack", number: "01", name: "Рохля", label: "Ручная перевозка",
          description: "Надежная красная помощница для дел, которые никак нельзя отложить до завтра.",
          pixelImage: "/media/pallet-jack-pixel.png",
        },
        {
          id: "sorting-table", number: "02", name: "Сортировочный стол", label: "Рабочее место",
          description: "Восемь коробок, стальной стол и тихая надежда, что всему найдется свое место.",
          pixelImage: "/media/sorting-table-pixel.png",
        },
        {
          id: "conveyor", number: "03", name: "Конвейер", label: "Длинный маршрут",
          description: "На складе для всего есть путь. Иногда он проходит через поворот.",
          pixelImage: "/media/conveyor-pixel.png",
        },
        {
          id: "receiving-table", number: "04", name: "Стол приемки", label: "Место приемки",
          description: "Монитор и ручной сканер на столе, две высокие синие тары под ним. Можно принимать новую поставку.",
          pixelImage: "/media/warehouse-objects-atlas.png",
          pixelCrop: { x: 0, y: 208, width: 96, height: 80 },
        },
        {
          id: "receiving-gate", number: "05", name: "Ворота приемки", label: "Через этот портал прибывают товары",
          description: "Роллетные ворота, за которыми начинается путь новой партии коробок.",
          pixelImage: "/media/warehouse-front-wall-atlas.png",
          pixelCrop: { x: 128, y: 0, width: 128, height: 96 },
        },
        {
          id: "storage-rack", number: "06", name: "Стеллаж для хранения", label: "Складские полки",
          description: "На этих полках товары ждут сортировки, перевозки или своего места в другой части склада.",
          pixelImage: "/media/warehouse-racks-atlas.png",
          pixelCrop: { x: 0, y: 192, width: 134, height: 96, scale: 1.35, sourceWidth: 3328 },
        },
        {
          id: "freight-lift", number: "07", name: "Грузовой лифт", label: "Подъем на мезонин",
          description: "Прочный путь между складским полом и верхним ярусом.",
          pixelImage: "/media/freight-lift-pixel.png",
        },
        {
          id: "mesh-cart", number: "08", name: "Сетчатая тележка", label: "Хранение на колесах",
          description: "Синяя сетка на колесах удержит небольшую гору товаров вместе.",
          pixelImage: "/media/warehouse-mesh-carts-atlas.png",
          pixelCrop: { x: 0, y: 0, width: 160, height: 128 },
        },
      ],
    },
    gallery: {
      eyebrow: "Кадры со смены / 04", title: "Загляни на склад.",
      captions: ["Стеллажи и подъемник мезонина", "Санузел у аварийного выхода", "Зарядные места транспорта", "Стол старших смены"],
    },
    ending: {
      eyebrow: "Доска объявлений", title: "Отдел скоро откроется.",
      body: "Department of Minor Logistics разрабатывается для ПК и мобильных устройств. Страница в Steam готовится; дата выхода пока не назначена.",
      status: "Страница Steam готовится",
      earlyAccess: "Ранний доступ", comingSoon: "Скоро",
      earlyAccessDescription: "Получите приятный бонус при запуске игры (после ее выхода) по зарегистрированной вами почте",
    },
    footer: { development: "Независимая игра в разработке", backToTop: "Наверх", demo: "Играть в демоверсию онлайн" },
  },
};
